// OptiShade additions, GPL-3.0-or-later.
#pragma once
// When a DLSS feature created for render sizes above the mode's optimal size has
// its first frames rejected as invalid, it is rebuilt at the optimal size. Pure
// decisions; unit-tested in tests/reconstruction/dlss_create_size_tests.cpp.
#include <cstdint>
#include <mutex>
#include <unordered_set>

namespace optishade::dlss_size
{
// Frames rejected before any success that mean "this size is not accepted".
inline constexpr int RejectionsBeforeRebuild = 3;

// feature: 0 DLSS, 1 DLSS-D. Output sizes fit in 20 bits; quality in 8.
inline uint64_t Key(unsigned int width, unsigned int height, int quality, int feature = 0)
{
    return (uint64_t(width & 0xFFFFF) << 40) | (uint64_t(height & 0xFFFFF) << 20) | (uint64_t(uint32_t(feature) & 0xFFF) << 8) |
           uint64_t(uint32_t(quality) & 0xFF);
}

// Output size and quality modes whose feature must be created at the optimal
// render size, for the life of the game process.
inline std::mutex& OptimalOnlyLock()
{
    static std::mutex lock;
    return lock;
}
inline std::unordered_set<uint64_t>& OptimalOnlySet()
{
    static std::unordered_set<uint64_t> keys;
    return keys;
}
inline bool OptimalOnly(uint64_t key)
{
    std::lock_guard lock(OptimalOnlyLock());
    return OptimalOnlySet().count(key) != 0;
}
inline void MarkOptimalOnly(uint64_t key)
{
    std::lock_guard lock(OptimalOnlyLock());
    OptimalOnlySet().insert(key);
}

// rejectedAtStart counts invalid-parameter results before the first success;
// it becomes -1 once a frame succeeded or a rebuild was requested, so the
// feature is never rebuilt twice and never after it has worked.
inline bool ShouldRebuild(bool createdAboveOptimal, int& rejectedAtStart, bool success, bool invalidParameter)
{
    if (rejectedAtStart < 0)
        return false;
    if (success)
    {
        rejectedAtStart = -1;
        return false;
    }
    if (!createdAboveOptimal || !invalidParameter)
        return false;
    if (++rejectedAtStart < RejectionsBeforeRebuild)
        return false;
    rejectedAtStart = -1;
    return true;
}
} // namespace optishade::dlss_size
