#define VER_BUILD_COMMIT "8fb871c"
