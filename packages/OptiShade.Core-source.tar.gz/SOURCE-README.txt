OptiShade Core corresponding source for version 1.0.100

This archive contains the build-relevant OptiScaler-derived source, project files, shaders, and applicable notices corresponding to the Core package. Generated build outputs and vendor runtime/model binaries are excluded. Based on source commit bf5105981d91dbe9644d5f88d309eebefbf742cd.

The Core OptiScaler binary (winmm.dll) SHA-256 is EF6E7570FF12B886C09EBE2B2F642423FC94512224B695B6855E6362A4B37A88. OptiScaler-derived portions remain subject to the GNU GPL v3; this archive supplies the corresponding source for those portions. NVIDIA runtime/model binaries are not included.
