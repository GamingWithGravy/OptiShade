OptiShade Core corresponding source for version 1.0.94

This archive contains the build-relevant OptiScaler-derived source, project files, shaders, and applicable notices corresponding to the Core package. Generated build outputs and vendor runtime/model binaries are excluded. Based on source commit 8f99d912c9f792e5bcdd465d1f53d35ca2637c8c.

The Core OptiScaler binary (winmm.dll) SHA-256 is F984817C56155BD621800E8B4CF7D5D70DD709816E3D7330E718ABC89393588E. OptiScaler-derived portions remain subject to the GNU GPL v3; this archive supplies the corresponding source for those portions. NVIDIA runtime/model binaries are not included.
