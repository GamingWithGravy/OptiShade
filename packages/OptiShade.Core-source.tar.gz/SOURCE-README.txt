OptiShade Core corresponding source for version 1.0.77

This archive contains the build-relevant OptiScaler-derived source, project files, shaders, and applicable notices corresponding to the Core package. Generated build outputs and vendor runtime/model binaries are excluded. The source tree is identified by SHA-256 8A2E48EA3411D24017784C73E61F0F2307CECEF4DC037E1B4DFE5CBA262BAA0E, based on source commit e94315a6387c26c9731dea0ef5d3509fc48892ad.

The Core OptiScaler binary SHA-256 is 2B49119E092E547CE0A52128F9F11766291514BC5F3173EF298BF76001032AFC. OptiScaler-derived portions remain subject to the GNU GPL v3; this archive supplies the corresponding source for those portions. NVIDIA runtime/model binaries are not included.
