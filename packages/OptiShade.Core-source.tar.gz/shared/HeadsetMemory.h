// OptiShade additions, GPL-3.0-or-later.
#pragma once
// Video-memory decisions for image effects in a VR headset (OSD-8JYK: an RTX
// 4070 ran a full desktop preset at 4472x2432 in the headset, reached 8.4 of
// 10.6 GB on entering VR and crashed in the NVIDIA driver on the next entry).
//
// The decisions are pure so they can be tested without a GPU. Query() reads
// the game's own budget and usage from the kernel graphics interface by
// adapter LUID; it never creates a DXGI factory, which would re-enter the DXGI
// hooks of OptiScaler and ReShade.
#include <cstdint>

namespace optishade::headset_memory {
// Cards whose usable video-memory budget is at or below this (12 GB cards
// report about 11.2 GB) start VR with the headset's own light look instead of
// the desktop look. 16 GB cards report about 14.5 GB and keep the desktop look.
constexpr uint64_t kLightLookBudgetMB = 12500;
// Headset effects are released when usage stays at or above this share of the
// budget for kPauseChecks consecutive checks (one check every kCheckMs).
constexpr uint64_t kPausePercent = 92;
constexpr uint32_t kPauseChecks = 2;
constexpr uint64_t kCheckMs = 500;

inline bool UseLightLook(uint64_t budgetMB) { return budgetMB > 0 && budgetMB <= kLightLookBudgetMB; }

struct Guard {
    uint32_t over = 0;
    bool paused = false;
    // True exactly once: the check at which headset effects must be released.
    bool Observe(uint64_t usage, uint64_t budget) {
        if (paused || budget == 0) return false;
        if (usage * 100 >= budget * kPausePercent) {
            if (++over >= kPauseChecks) { paused = true; return true; }
        } else {
            over = 0;
        }
        return false;
    }
};
} // namespace optishade::headset_memory

#ifdef _WIN32
#include <windows.h>
#include <d3dkmthk.h>
#include <mutex>
namespace optishade::headset_memory {
// Budget and current usage of this process on one adapter, in bytes.
inline bool Query(LUID luid, uint64_t& usage, uint64_t& budget) {
    using OpenFn = NTSTATUS(APIENTRY*)(D3DKMT_OPENADAPTERFROMLUID*);
    using QueryFn = NTSTATUS(APIENTRY*)(D3DKMT_QUERYVIDEOMEMORYINFO*);
    using CloseFn = NTSTATUS(APIENTRY*)(const D3DKMT_CLOSEADAPTER*);
    static std::mutex lock;
    static OpenFn open = nullptr; static QueryFn query = nullptr; static CloseFn close = nullptr; static bool resolved = false;
    static LUID cachedLuid{}; static D3DKMT_HANDLE adapter = 0;
    std::lock_guard guard(lock);
    if (!resolved) {
        resolved = true;
        if (HMODULE gdi = LoadLibraryExW(L"gdi32.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32)) {
            open = reinterpret_cast<OpenFn>(GetProcAddress(gdi, "D3DKMTOpenAdapterFromLuid"));
            query = reinterpret_cast<QueryFn>(GetProcAddress(gdi, "D3DKMTQueryVideoMemoryInfo"));
            close = reinterpret_cast<CloseFn>(GetProcAddress(gdi, "D3DKMTCloseAdapter"));
        }
    }
    if (!open || !query || !close) return false;
    if (adapter && (cachedLuid.LowPart != luid.LowPart || cachedLuid.HighPart != luid.HighPart)) {
        D3DKMT_CLOSEADAPTER request{}; request.hAdapter = adapter; close(&request); adapter = 0;
    }
    if (!adapter) {
        D3DKMT_OPENADAPTERFROMLUID request{}; request.AdapterLuid = luid;
        if (open(&request) < 0) return false;
        adapter = request.hAdapter; cachedLuid = luid;
    }
    D3DKMT_QUERYVIDEOMEMORYINFO info{};
    info.hAdapter = adapter;
    info.MemorySegmentGroup = D3DKMT_MEMORY_SEGMENT_GROUP_LOCAL;
    if (query(&info) < 0) {
        D3DKMT_CLOSEADAPTER request{}; request.hAdapter = adapter; close(&request); adapter = 0;
        return false;
    }
    usage = info.CurrentUsage; budget = info.Budget;
    return true;
}
} // namespace optishade::headset_memory
#endif
