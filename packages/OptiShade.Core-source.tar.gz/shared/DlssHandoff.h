// OptiShade additions, GPL-3.0-or-later.
#pragma once
// "VR tool compatibility" (off by default). VR tools such as OFXR Bridge run
// their own NVIDIA DLSS and frame generation for the headset. With OptiShade
// standing in for NVIDIA's DLSS library, those tools got OptiShade's copy and
// MSFS 2024 crashed on entering VR (OSD-J8C7). When the player turns this on in
// the OptiShade app, the VR tool gets NVIDIA's DLSS and frame generation:
//  - DLLs an OpenXR layer (a VR tool) loads are passed straight to Windows, and
//    the DLSS features it creates go straight to NVIDIA;
//  - OptiShade's own frame generation is off and Streamline frame generation is
//    left to the game and the VR tool (the app also removes OptiMFG).
// The game's DLSS still runs through OptiShade, so Neural Rendering (DLSS 5),
// image effects and the Glass Cockpit correction keep working. Read once per process
// from <game>\OptiShadeData\Compatibility.ini, [DLSS] HandOffToVrTools.
#include <windows.h>

#include <string>
#include <string_view>

namespace optishade::dlss_handoff
{
// Only an explicit true/1/yes/on enables it; anything else keeps the default.
inline bool ParseEnabled(std::wstring_view value) noexcept
{
    while (!value.empty() && (value.front() == L' ' || value.front() == L'\t')) value.remove_prefix(1);
    while (!value.empty() && (value.back() == L' ' || value.back() == L'\t')) value.remove_suffix(1);
    for (const wchar_t* on : { L"true", L"1", L"yes", L"on" })
    {
        const std::wstring_view word(on);
        if (value.size() == word.size() && _wcsnicmp(value.data(), word.data(), word.size()) == 0)
            return true;
    }
    return false;
}

inline bool Enabled()
{
    static const bool enabled = []
    {
        wchar_t executable[32768] {};
        const DWORD length = GetModuleFileNameW(nullptr, executable, 32768);
        if (!length || length >= 32768)
            return false;
        std::wstring folder(executable, length);
        const auto slash = folder.find_last_of(L"\\/");
        if (slash == std::wstring::npos)
            return false;
        const std::wstring file = folder.substr(0, slash + 1) + L"OptiShadeData\\Compatibility.ini";
        wchar_t value[16] {};
        const DWORD count = GetPrivateProfileStringW(L"DLSS", L"HandOffToVrTools", L"false", value, 16, file.c_str());
        return count < 15 && ParseEnabled(std::wstring_view(value, count));
    }();
    return enabled;
}

inline constexpr const char* PlayerNotice =
    "VR tool compatibility is on for this game (OptiShade app): VR tools such as OFXR use NVIDIA DLSS and frame generation directly, so OptiMFG and OptiShade's frame generation are off. Neural Rendering and image effects keep working.";
} // namespace optishade::dlss_handoff
