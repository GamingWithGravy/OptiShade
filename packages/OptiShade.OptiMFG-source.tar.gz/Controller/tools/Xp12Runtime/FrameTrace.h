#pragma once
#include "FrameTiming.h"
#include <unordered_map>
#include <sstream>
#include <map>
#include <tuple>
namespace xpframe {
template<class T> uint64_t Key(T p){return (uint64_t)p;}
struct Image {uint64_t device;VkFormat format;VkExtent3D extent;VkImageUsageFlags usage;uint32_t layers,samples;};
struct Chain {uint64_t device,generation;uint32_t width,height;VkFormat format;Timing timing;uint64_t presents=0;std::string inventory;};
static std::mutex mutex;
static std::unordered_map<uint64_t,Image> images;
static std::unordered_map<uint64_t,Chain> chains;
static uint64_t generation=0,submissions=0;
static bool overflow=false;
static PFN_vkCreateImage imageCreate{};
static PFN_vkDestroyImage imageDestroy{};
static PFN_vkAcquireNextImageKHR acquire{};
static PFN_vkAcquireNextImage2KHR acquire2{};
static PFN_vkDestroySwapchainKHR destroyChain{};
static PFN_vkQueueSubmit submit{};
static PFN_vkQueueSubmit2 submit2{};
struct Signal {uint64_t queue=0,serial=0;};
static std::unordered_map<uint64_t,Signal> signals;
static void Swapchain(VkDevice device,const VkSwapchainCreateInfoKHR* ci,VkSwapchainKHR chain){
 std::lock_guard lock(mutex);if(chains.size()>=16){overflow=true;return;}
 auto& c=chains[Key(chain)];c={Key(device),++generation,ci->imageExtent.width,ci->imageExtent.height,ci->imageFormat};c.timing.Reset(c.generation);
}
static VkResult VKAPI_CALL CreateImage(VkDevice d,const VkImageCreateInfo* ci,const VkAllocationCallbacks* a,VkImage* out){
 auto result=imageCreate(d,ci,a,out);if(result==VK_SUCCESS){std::lock_guard lock(mutex);if(images.size()<32768)images[Key(*out)]={Key(d),ci->format,ci->extent,ci->usage,ci->arrayLayers,(uint32_t)ci->samples};else overflow=true;}return result;
}
static void VKAPI_CALL DestroyImage(VkDevice d,VkImage i,const VkAllocationCallbacks* a){
 {std::lock_guard lock(mutex);images.erase(Key(i));}imageDestroy(d,i,a);
}
static void Acquired(VkSwapchainKHR chain,VkResult result,uint32_t image,VkSemaphore semaphore,VkFence fence){
 if(result!=VK_SUCCESS&&result!=VK_SUBOPTIMAL_KHR)return;
 std::lock_guard lock(mutex);auto c=chains.find(Key(chain));if(c==chains.end())return;
 c->second.timing.Acquire(image,GetTickCount64(),Key(semaphore),Key(fence));
}
static VkResult VKAPI_CALL Acquire(VkDevice d,VkSwapchainKHR c,uint64_t timeout,VkSemaphore s,VkFence f,uint32_t* image){
 auto result=acquire(d,c,timeout,s,f,image);if(result==VK_SUCCESS||result==VK_SUBOPTIMAL_KHR)Acquired(c,result,*image,s,f);return result;
}
static VkResult VKAPI_CALL Acquire2(VkDevice d,const VkAcquireNextImageInfoKHR* ci,uint32_t* image){
 auto result=acquire2(d,ci,image);if(result==VK_SUCCESS||result==VK_SUBOPTIMAL_KHR)Acquired(ci->swapchain,result,*image,ci->semaphore,ci->fence);return result;
}
static void VKAPI_CALL DestroyChain(VkDevice d,VkSwapchainKHR c,const VkAllocationCallbacks* a){
 {std::lock_guard lock(mutex);chains.erase(Key(c));}destroyChain(d,c,a);
}
static VkResult VKAPI_CALL Submit(VkQueue q,uint32_t count,const VkSubmitInfo* info,VkFence fence){
 auto result=submit(q,count,info,fence);if(result==VK_SUCCESS){std::lock_guard lock(mutex);auto serial=++submissions;
  for(uint32_t i=0;i<count;++i)for(uint32_t j=0;j<info[i].signalSemaphoreCount;++j){if(signals.size()<4096)signals[Key(info[i].pSignalSemaphores[j])]={Key(q),serial};else overflow=true;}}
 return result;
}
static VkResult VKAPI_CALL Submit2(VkQueue q,uint32_t count,const VkSubmitInfo2* info,VkFence fence){
 auto result=submit2(q,count,info,fence);if(result==VK_SUCCESS){std::lock_guard lock(mutex);auto serial=++submissions;
  for(uint32_t i=0;i<count;++i)for(uint32_t j=0;j<info[i].signalSemaphoreInfoCount;++j){if(signals.size()<4096)signals[Key(info[i].pSignalSemaphoreInfos[j].semaphore)]={Key(q),serial};else overflow=true;}}
 return result;
}
static void BeforePresent(VkQueue q,const VkPresentInfoKHR* info){
 std::string output;
 {std::lock_guard lock(mutex);
  for(uint32_t i=0;i<info->swapchainCount;++i){auto found=chains.find(Key(info->pSwapchains[i]));if(found==chains.end())continue;auto& c=found->second;
   auto identity=c.timing.Present(info->pImageIndices[i]);auto count=++c.presents;
   if(count!=1&&count%300!=0)continue;
   uint32_t linked=0;for(uint32_t w=0;w<info->waitSemaphoreCount;++w){auto s=signals.find(Key(info->pWaitSemaphores[w]));if(s!=signals.end()&&s->second.queue==Key(q))++linked;}
   std::ostringstream text;text<<"frame_inputs chain="<<Key(info->pSwapchains[i])<<" generation="<<c.generation<<" image="<<info->pImageIndices[i]<<" acquire_frame="<<identity.frame<<" acquire_age_ms="<<(identity.frame?GetTickCount64()-identity.tick:0)<<" identity_valid="<<(identity.frame&&!c.timing.invalid&&!overflow)<<" present_waits="<<info->waitSemaphoreCount<<" observed_signal_links="<<linked<<" format="<<c.format<<" extent="<<c.width<<"x"<<c.height<<" input_lease=NONE constants=NONE motion_semantics=UNVALIDATED candidates=";
   unsigned candidates=0;
   for(const auto& [handle,image]:images){if(image.device!=c.device||image.extent.width!=c.width||image.extent.height!=c.height||image.layers!=1||image.samples!=1)continue;
    bool depth=(image.usage&VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT)!=0;
    bool vector=image.format==VK_FORMAT_R16G16_SFLOAT||image.format==VK_FORMAT_R32G32_SFLOAT;
    if(!depth&&!vector)continue;++candidates;if(candidates<=12)text<<"["<<handle<<",format:"<<image.format<<",usage:"<<image.usage<<",kind:"<<(depth?"depth-format":"two-channel-format")<<"]";
   }
   text<<" candidate_count="<<candidates<<" inventory_overflow="<<overflow<<" (formats do not establish semantic meaning or frame lifetime)";
   output+=text.str()+"\n";
   // Inventory by metadata, not presumed semantics. Include packed, scaled,
   // array and multisampled resources; no GPU reads or resource mutations.
   using Shape=std::tuple<uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t>;
   std::map<Shape,uint32_t> shapes;
   for(const auto& [handle,image]:images){
    if(image.device!=c.device)continue;
    ++shapes[{(uint32_t)image.format,image.extent.width,image.extent.height,image.extent.depth,image.usage,image.layers,image.samples}];
   }
   std::ostringstream inventory;
   for(const auto& [shape,number]:shapes){
    const auto& [format,width,height,depth,usage,layers,samples]=shape;
    inventory<<" [format="<<format<<" extent="<<width<<"x"<<height<<"x"<<depth<<" usage="<<usage<<" layers="<<layers<<" samples="<<samples<<" count="<<number<<"]";
   }
   auto current=inventory.str();
   if(current!=c.inventory){
    output+="image_inventory generation="+std::to_string(c.generation)+" acquire_frame="+std::to_string(identity.frame)+" shapes="+std::to_string(shapes.size())+" semantics=UNVALIDATED"+current+"\n";
    c.inventory=std::move(current);
   }
  }
  // Signal provenance is only a bounded observation, not a dependency proof.
  for(uint32_t w=0;w<info->waitSemaphoreCount;++w)signals.erase(Key(info->pWaitSemaphores[w]));
 }
 if(!output.empty())Log(output);
}
static PFN_vkVoidFunction Wrap(const char* name,PFN_vkVoidFunction value){
#define TRACE_VK(n,storage,hook) if(!strcmp(name,n)){if(value==(PFN_vkVoidFunction)hook)return value;storage=(decltype(storage))value;return (PFN_vkVoidFunction)hook;}
 TRACE_VK("vkCreateImage",imageCreate,CreateImage)
 TRACE_VK("vkDestroyImage",imageDestroy,DestroyImage)
 TRACE_VK("vkAcquireNextImageKHR",acquire,Acquire)
 TRACE_VK("vkAcquireNextImage2KHR",acquire2,Acquire2)
 TRACE_VK("vkDestroySwapchainKHR",destroyChain,DestroyChain)
 TRACE_VK("vkQueueSubmit",submit,Submit)
 TRACE_VK("vkQueueSubmit2",submit2,Submit2)
 TRACE_VK("vkQueueSubmit2KHR",submit2,Submit2)
#undef TRACE_VK
 return value;
}
}
