#pragma once
#include <array>
#include <cstdint>
namespace xpframe {
// CPU-observed acquire/present identity only. This is not a GPU completion
// fence, a simulation tick, or proof that any temporal input is valid.
struct Timing {
 struct Slot {uint64_t frame=0,tick=0,semaphore=0,fence=0;bool pending=false;};
 std::array<Slot,16> slots{};
 uint64_t generation=0,next=0;
 bool invalid=false;
 void Reset(uint64_t g){slots={};generation=g;invalid=false;}
 bool Acquire(uint32_t image,uint64_t tick,uint64_t semaphore,uint64_t fence){
  if(image>=slots.size()||slots[image].pending){invalid=true;return false;}
  slots[image]={++next,tick,semaphore,fence,true};return true;
 }
 Slot Present(uint32_t image){
  if(image>=slots.size()||!slots[image].pending){invalid=true;return {};}
  auto out=slots[image];slots[image].pending=false;return out;
 }
};
}
