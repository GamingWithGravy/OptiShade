#pragma once
#include "ShaderInputs.h"
#include <unordered_set>
namespace xpframe {
// Metadata observations at command-recording time only. Never used for tagging
// or FG admission: descriptor mutation, copies/templates, submission/lifetime,
// layouts, vector conventions and camera constants still require validation.
static PFN_vkCreateShaderModule createShader{};
static PFN_vkDestroyShaderModule destroyShader{};
static PFN_vkCreateComputePipelines createCompute{};
static PFN_vkDestroyPipeline destroyPipeline{};
static PFN_vkCreateImageView createView{};
static PFN_vkDestroyImageView destroyView{};
static PFN_vkUpdateDescriptorSets updateSets{};
static PFN_vkCmdBindPipeline bindPipeline{};
static PFN_vkCmdBindDescriptorSets bindSets{};
static PFN_vkBeginCommandBuffer beginCommand{};
static PFN_vkCmdDispatch dispatch{};
static std::unordered_set<uint64_t> velocityShaders,velocityPipelines;
struct ViewRecord {uint64_t image,device;};
static std::unordered_map<uint64_t,ViewRecord> views;
struct BindingRecord {uint64_t view;VkImageLayout layout;uint64_t setLayout=0,sourceTemplate=0;size_t sourceOffset=0;};
static std::unordered_map<uint64_t,BindingRecord> descriptorImages;
struct CommandRecord {uint64_t pipeline=0,set=0,bindLayout=0;};
static std::unordered_map<uint64_t,CommandRecord> commands;
static std::unordered_set<uint64_t> reportedImages;
static bool shaderTraceOverflow=false;
static uint64_t computeBatches=0,matchedPipelines=0,dispatchCalls=0,matchedDispatches=0,templateUpdates=0;
static PFN_vkCmdDispatchIndirect dispatchIndirect{};
static PFN_vkCreateDescriptorUpdateTemplate createTemplate{};
static PFN_vkDestroyDescriptorUpdateTemplate destroyTemplate{};
static PFN_vkUpdateDescriptorSetWithTemplate updateTemplate{};
static PFN_vkCreatePipelineLayout createPipelineLayout{};
static PFN_vkDestroyPipelineLayout destroyPipelineLayout{};
static std::unordered_map<uint64_t,uint64_t> pipelineSetLayouts,computeLayouts;
static std::unordered_set<uint64_t> reportedMismatches;
static VkResult VKAPI_CALL CreatePipelineLayout(VkDevice d,const VkPipelineLayoutCreateInfo* ci,const VkAllocationCallbacks* a,VkPipelineLayout* out){
 auto result=createPipelineLayout(d,ci,a,out);if(result==VK_SUCCESS){std::lock_guard lock(mutex);if(pipelineSetLayouts.size()<8192)pipelineSetLayouts[Key(*out)]=ci->setLayoutCount?Key(ci->pSetLayouts[0]):0;else shaderTraceOverflow=true;}return result;
}
static void VKAPI_CALL DestroyPipelineLayout(VkDevice d,VkPipelineLayout layout,const VkAllocationCallbacks* a){
 {std::lock_guard lock(mutex);pipelineSetLayouts.erase(Key(layout));}destroyPipelineLayout(d,layout,a);
}
struct TemplateRecord {size_t offset;bool supported;uint64_t setLayout=0;};
static std::unordered_map<uint64_t,TemplateRecord> templates;
static VkResult VKAPI_CALL CreateTemplate(VkDevice d,const VkDescriptorUpdateTemplateCreateInfo* ci,const VkAllocationCallbacks* a,VkDescriptorUpdateTemplate* out){
 auto result=createTemplate(d,ci,a,out);
 if(result==VK_SUCCESS){
  TemplateRecord record{};
  if(ci->templateType==VK_DESCRIPTOR_UPDATE_TEMPLATE_TYPE_DESCRIPTOR_SET){
   for(uint32_t i=0;i<ci->descriptorUpdateEntryCount;++i){const auto& e=ci->pDescriptorUpdateEntries[i];
    if(e.dstBinding==4&&e.dstArrayElement==0&&e.descriptorCount==1&&(e.descriptorType==VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER||e.descriptorType==VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE))record={e.offset,true,Key(ci->descriptorSetLayout)};
   }
  }
  std::lock_guard lock(mutex);if(templates.size()<8192)templates[Key(*out)]=record;else shaderTraceOverflow=true;
 }return result;
}
static void VKAPI_CALL DestroyTemplate(VkDevice d,VkDescriptorUpdateTemplate t,const VkAllocationCallbacks* a){
 {std::lock_guard lock(mutex);templates.erase(Key(t));}destroyTemplate(d,t,a);
}
static void VKAPI_CALL UpdateTemplate(VkDevice d,VkDescriptorSet set,VkDescriptorUpdateTemplate t,const void* data){
 updateTemplate(d,set,t,data);
 std::lock_guard lock(mutex);++templateUpdates;descriptorImages.erase(Key(set));
 auto found=templates.find(Key(t));
 if(found!=templates.end()&&found->second.supported&&data){
  VkDescriptorImageInfo info{};std::memcpy(&info,static_cast<const unsigned char*>(data)+found->second.offset,sizeof(info));
  if(descriptorImages.size()<65536)descriptorImages[Key(set)]={Key(info.imageView),info.imageLayout,found->second.setLayout,Key(t),found->second.offset};else shaderTraceOverflow=true;
 }
}
static void ShaderCoverage(){
 std::string message;
 {std::lock_guard lock(mutex);message="velocity_trace_coverage compute_batches="+std::to_string(computeBatches)+" matched_pipelines="+std::to_string(matchedPipelines)+" dispatches="+std::to_string(dispatchCalls)+" matched_dispatches="+std::to_string(matchedDispatches)+" template_updates="+std::to_string(templateUpdates)+" descriptor_records="+std::to_string(descriptorImages.size())+" observed_images="+std::to_string(reportedImages.size())+" overflow="+std::to_string(shaderTraceOverflow);}
 Log(message);
}
static VkResult VKAPI_CALL CreateShader(VkDevice d,const VkShaderModuleCreateInfo* ci,const VkAllocationCallbacks* a,VkShaderModule* out){
 auto result=createShader(d,ci,a,out);
 if(result==VK_SUCCESS&&ClassifyVelocityInput(ci->pCode,ci->codeSize)==VelocityInputKind::IntegerImage)
  Log("velocity_shader rejected=integer_sampled_image module="+std::to_string(Key(*out))+" not_a_validated_motion_vector");
 if(result==VK_SUCCESS&&HasVelocityBinding(ci->pCode,ci->codeSize)){
  {std::lock_guard lock(mutex);if(velocityShaders.size()<4096)velocityShaders.insert(Key(*out));else shaderTraceOverflow=true;}
  Log("velocity_shader observed=1 module="+std::to_string(Key(*out))+" binding=4 set=0 semantics=UNVALIDATED");
 }
 return result;
}
static void VKAPI_CALL DestroyShader(VkDevice d,VkShaderModule s,const VkAllocationCallbacks* a){
 {std::lock_guard lock(mutex);velocityShaders.erase(Key(s));}destroyShader(d,s,a);
}
static VkResult VKAPI_CALL CreateCompute(VkDevice d,VkPipelineCache cache,uint32_t count,const VkComputePipelineCreateInfo* ci,const VkAllocationCallbacks* a,VkPipeline* out){
 auto result=createCompute(d,cache,count,ci,a,out);
 // Only successful batches are observed. Failed partial batches are ignored.
 if(result==VK_SUCCESS){std::lock_guard lock(mutex);++computeBatches;for(uint32_t i=0;i<count;++i){
  velocityPipelines.erase(Key(out[i]));computeLayouts.erase(Key(out[i]));
  if(velocityShaders.count(Key(ci[i].stage.module))){++matchedPipelines;if(velocityPipelines.size()<4096){velocityPipelines.insert(Key(out[i]));computeLayouts[Key(out[i])]=Key(ci[i].layout);}else shaderTraceOverflow=true;}
 }}return result;
}
static void VKAPI_CALL DestroyPipeline(VkDevice d,VkPipeline p,const VkAllocationCallbacks* a){
 {std::lock_guard lock(mutex);velocityPipelines.erase(Key(p));computeLayouts.erase(Key(p));}destroyPipeline(d,p,a);
}
static VkResult VKAPI_CALL CreateView(VkDevice d,const VkImageViewCreateInfo* ci,const VkAllocationCallbacks* a,VkImageView* out){
 auto result=createView(d,ci,a,out);if(result==VK_SUCCESS){std::lock_guard lock(mutex);if(views.size()<65536)views[Key(*out)]={Key(ci->image),Key(d)};else shaderTraceOverflow=true;}return result;
}
static void VKAPI_CALL DestroyView(VkDevice d,VkImageView v,const VkAllocationCallbacks* a){
 {std::lock_guard lock(mutex);views.erase(Key(v));}destroyView(d,v,a);
}
static void VKAPI_CALL UpdateSets(VkDevice d,uint32_t count,const VkWriteDescriptorSet* writes,uint32_t copies,const VkCopyDescriptorSet* copy){
 updateSets(d,count,writes,copies,copy);
 std::lock_guard lock(mutex);
 // Copies may overwrite earlier observations; conservatively discard them.
 if(copies)descriptorImages.clear();
 for(uint32_t i=0;i<count;++i){auto& w=writes[i];if(w.dstBinding!=4)continue;
  descriptorImages.erase(Key(w.dstSet));
  if(w.dstArrayElement||w.descriptorCount!=1||!w.pImageInfo)continue;
  if(w.descriptorType!=VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER&&w.descriptorType!=VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE)continue;
  if(descriptorImages.size()<65536)descriptorImages[Key(w.dstSet)]={Key(w.pImageInfo[0].imageView),w.pImageInfo[0].imageLayout};else shaderTraceOverflow=true;
 }
}
static void VKAPI_CALL BindPipeline(VkCommandBuffer cb,VkPipelineBindPoint point,VkPipeline p){
 bindPipeline(cb,point,p);if(point!=VK_PIPELINE_BIND_POINT_COMPUTE)return;
 std::lock_guard lock(mutex);if(commands.size()<8192)commands[Key(cb)].pipeline=Key(p);else shaderTraceOverflow=true;
}
static void VKAPI_CALL BindSets(VkCommandBuffer cb,VkPipelineBindPoint point,VkPipelineLayout layout,uint32_t first,uint32_t count,const VkDescriptorSet* sets,uint32_t dynCount,const uint32_t* offsets){
 bindSets(cb,point,layout,first,count,sets,dynCount,offsets);if(point!=VK_PIPELINE_BIND_POINT_COMPUTE||first||!count)return;
 std::lock_guard lock(mutex);if(commands.size()<8192){commands[Key(cb)].set=Key(sets[0]);commands[Key(cb)].bindLayout=Key(layout);}else shaderTraceOverflow=true;
}
static VkResult VKAPI_CALL BeginCommand(VkCommandBuffer cb,const VkCommandBufferBeginInfo* info){
 auto result=beginCommand(cb,info);if(result==VK_SUCCESS){std::lock_guard lock(mutex);commands.erase(Key(cb));}return result;
}
static void ObserveDispatch(VkCommandBuffer cb){
 std::string observation;
 {std::lock_guard lock(mutex);++dispatchCalls;auto c=commands.find(Key(cb));
  if(c!=commands.end()&&velocityPipelines.count(c->second.pipeline)){++matchedDispatches;
   auto binding=descriptorImages.find(c->second.set);
   if(binding!=descriptorImages.end()){
    const auto pl=computeLayouts.find(c->second.pipeline);
    const auto expected=pl==computeLayouts.end()?pipelineSetLayouts.end():pipelineSetLayouts.find(pl->second);
    const bool provenance=expected!=pipelineSetLayouts.end()&&expected->second&&binding->second.setLayout==expected->second&&c->second.bindLayout==pl->second;
    if(!provenance){
     if(reportedMismatches.size()<128&&reportedMismatches.insert(c->second.pipeline).second)
      Log("velocity_binding_unqualified pipeline="+std::to_string(c->second.pipeline)+" reason=layout_provenance_unverified template_set_layout="+std::to_string(binding->second.setLayout)+" expected_set_layout="+std::to_string(expected==pipelineSetLayouts.end()?0:expected->second)+" bound_layout="+std::to_string(c->second.bindLayout));
     return;
    }
    auto view=views.find(binding->second.view);
    if(view!=views.end()){
     auto image=images.find(view->second.image);
     if(image!=images.end()&&image->second.device==view->second.device&&!reportedImages.count(view->second.image)&&reportedImages.size()<4096){
      reportedImages.insert(view->second.image);const auto& im=image->second;
      observation="velocity_binding_observation image="+std::to_string(view->second.image)+" format="+std::to_string(im.format)+" extent="+std::to_string(im.extent.width)+"x"+std::to_string(im.extent.height)+" samples="+std::to_string(im.samples)+" descriptor_layout="+std::to_string(binding->second.layout)+" command="+std::to_string(Key(cb))+" pipeline="+std::to_string(c->second.pipeline)+" trace_overflow="+std::to_string(shaderTraceOverflow)+" template="+std::to_string(binding->second.sourceTemplate)+" template_offset="+std::to_string(binding->second.sourceOffset)+" layout_provenance=MATCHED shape_compatible="+std::to_string(im.samples==1&&(im.format==VK_FORMAT_R16G16_SFLOAT||im.format==VK_FORMAT_R32G32_SFLOAT))+" stage=RECORDED_ONLY semantics=UNVALIDATED lifetime=UNVALIDATED";
     }
    }
   }
  }
 }
 if(!observation.empty())Log(observation);
}
static void VKAPI_CALL Dispatch(VkCommandBuffer cb,uint32_t x,uint32_t y,uint32_t z){
 ObserveDispatch(cb);dispatch(cb,x,y,z);
}
static void VKAPI_CALL DispatchIndirect(VkCommandBuffer cb,VkBuffer buffer,VkDeviceSize offset){
 ObserveDispatch(cb);dispatchIndirect(cb,buffer,offset);
}
static PFN_vkVoidFunction WrapShader(const char* name,PFN_vkVoidFunction value){
 if(!value)return value;
#define TRACE_SHADER(n,storage,hook) if(!strcmp(name,n)){if(value==(PFN_vkVoidFunction)hook)return value;storage=(decltype(storage))value;return (PFN_vkVoidFunction)hook;}
 TRACE_SHADER("vkCreatePipelineLayout",createPipelineLayout,CreatePipelineLayout)
 TRACE_SHADER("vkDestroyPipelineLayout",destroyPipelineLayout,DestroyPipelineLayout)
 TRACE_SHADER("vkCreateShaderModule",createShader,CreateShader)
 TRACE_SHADER("vkDestroyShaderModule",destroyShader,DestroyShader)
 TRACE_SHADER("vkCreateComputePipelines",createCompute,CreateCompute)
 TRACE_SHADER("vkDestroyPipeline",destroyPipeline,DestroyPipeline)
 TRACE_SHADER("vkCreateImageView",createView,CreateView)
 TRACE_SHADER("vkDestroyImageView",destroyView,DestroyView)
 TRACE_SHADER("vkUpdateDescriptorSets",updateSets,UpdateSets)
 TRACE_SHADER("vkCmdBindPipeline",bindPipeline,BindPipeline)
 TRACE_SHADER("vkCmdBindDescriptorSets",bindSets,BindSets)
 TRACE_SHADER("vkBeginCommandBuffer",beginCommand,BeginCommand)
 TRACE_SHADER("vkCmdDispatch",dispatch,Dispatch)
 TRACE_SHADER("vkCmdDispatchIndirect",dispatchIndirect,DispatchIndirect)
 TRACE_SHADER("vkCreateDescriptorUpdateTemplate",createTemplate,CreateTemplate)
 TRACE_SHADER("vkCreateDescriptorUpdateTemplateKHR",createTemplate,CreateTemplate)
 TRACE_SHADER("vkDestroyDescriptorUpdateTemplate",destroyTemplate,DestroyTemplate)
 TRACE_SHADER("vkDestroyDescriptorUpdateTemplateKHR",destroyTemplate,DestroyTemplate)
 TRACE_SHADER("vkUpdateDescriptorSetWithTemplate",updateTemplate,UpdateTemplate)
 TRACE_SHADER("vkUpdateDescriptorSetWithTemplateKHR",updateTemplate,UpdateTemplate)
#undef TRACE_SHADER
 return value;
}
}
