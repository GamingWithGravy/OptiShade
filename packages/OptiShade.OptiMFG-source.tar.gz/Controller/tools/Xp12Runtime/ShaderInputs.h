#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <unordered_map>
namespace xpframe {
enum class VelocityInputKind { Missing, Unknown, IntegerImage, FloatImage };
inline VelocityInputKind ClassifyVelocityInput(const uint32_t* words,size_t bytes){
 if(!words||bytes%4||bytes<20||bytes>16*1024*1024||words[0]!=0x07230203)return VelocityInputKind::Missing;
 struct Decorations {uint32_t set=~0u,binding=~0u;};
 std::unordered_map<uint32_t,Decorations> decorations;
 struct Type {uint32_t op=0,child=0,width=0;};
 std::unordered_map<uint32_t,Type> types;
 std::unordered_map<uint32_t,uint32_t> variables;
 uint32_t target=0;
 for(size_t i=5;i<bytes/4;){
  auto count=words[i]>>16,op=words[i]&65535;
  if(!count||count>bytes/4-i)return VelocityInputKind::Missing;
  if(op==5&&count>=3){
   const char* name=reinterpret_cast<const char*>(words+i+2);size_t capacity=(count-2)*4;
   const void* end=std::memchr(name,0,capacity);
   if(end&&static_cast<const char*>(end)-name==11&&!std::memcmp(name,"gbuffer_vel",11))target=words[i+1];
  }
  if(op==71&&count==4){
   if(words[i+2]==34)decorations[words[i+1]].set=words[i+3];
   if(words[i+2]==33)decorations[words[i+1]].binding=words[i+3];
  }
  if(op==59&&count>=4)variables[words[i+2]]=words[i+1];
  if(op==32&&count==4)types[words[i+1]]={op,words[i+3],0};
  if((op==27&&count==3)||(op==25&&count>=9))types[words[i+1]]={op,words[i+2],0};
  if((op==22&&count==3)||(op==21&&count==4))types[words[i+1]]={op,0,words[i+2]};
  i+=count;
 }
 auto found=decorations.find(target);
 if(!target||found==decorations.end()||found->second.set!=0||found->second.binding!=4)return VelocityInputKind::Missing;
 auto var=variables.find(target);if(var==variables.end())return VelocityInputKind::Unknown;
 auto ptr=types.find(var->second);if(ptr==types.end()||ptr->second.op!=32)return VelocityInputKind::Unknown;
 auto sampled=types.find(ptr->second.child);if(sampled==types.end()||sampled->second.op!=27)return VelocityInputKind::Unknown;
 auto image=types.find(sampled->second.child);if(image==types.end()||image->second.op!=25)return VelocityInputKind::Unknown;
 auto scalar=types.find(image->second.child);if(scalar==types.end())return VelocityInputKind::Unknown;
 if(scalar->second.op==21)return VelocityInputKind::IntegerImage;
 if(scalar->second.op==22&&scalar->second.width==32)return VelocityInputKind::FloatImage;
 return VelocityInputKind::Unknown;
}
inline bool HasVelocityBinding(const uint32_t* words,size_t bytes){return ClassifyVelocityInput(words,bytes)==VelocityInputKind::FloatImage;}
}
