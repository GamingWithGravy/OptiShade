#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define VK_USE_PLATFORM_WIN32_KHR
#include <windows.h>
#include <tlhelp32.h>
#include <detours/detours.h>
#include <vulkan/vulkan.h>
#include <sl.h>
#include <sl_dlss_g.h>
#include <sl_security.h>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>
#include <atomic>
static HMODULE selfModule{},slModule{};
static decltype(&GetProcAddress) originalGet{};
static PFN_vkGetInstanceProcAddr slGipa{};
static PFN_vkGetDeviceProcAddr slGdpa{};
static PFun_slGetFeatureFunction* feature{};
static PFun_slShutdown* shutdownSl{};
static PFN_vkCreateDevice createDevice{};
static PFN_vkCreateSwapchainKHR createSwapchain{};
static PFN_vkQueuePresentKHR present{};
static PFN_vkDestroyDevice destroyDevice{};
static std::once_flag initOnce;
static std::mutex logLock;
static std::ofstream logFile;
static std::atomic<bool> initialized=false;
static std::atomic<unsigned long long> presents=0;
static void Log(const std::string& message){std::lock_guard l(logLock);if(logFile){logFile<<GetTickCount64()<<" "<<message<<"\n";logFile.flush();}}
// Trace only this private Streamline plugin's imports. Forward every result
// unchanged; do not intercept the simulator or OptiShade NR loader calls.
static decltype(&LoadLibraryW) commonLoadW{};
static decltype(&LoadLibraryExW) commonLoadExW{};
static decltype(&LoadLibraryA) commonLoadA{};
static decltype(&LoadLibraryExA) commonLoadExA{};
static decltype(&GetProcAddress) commonGet{};
static std::string ModulePath(HMODULE m){wchar_t p[32768]{};if(!m||!GetModuleFileNameW(m,p,32768))return "unavailable";return std::filesystem::path(p).string();}
static void TraceLoad(const std::string& requested,HMODULE actual){if(requested.find("ngx")!=std::string::npos)Log("provider_load requested="+requested+" actual="+ModulePath(actual));}
// A game loader shim can return itself for an NGX driver request. For this
// private Streamline caller only, reuse the exact signed driver image already
// loaded by Windows. Never invent a path, capability or replacement provider.
static bool VerifyDriverImage(LPCWSTR file){
 wchar_t windows[32768]{};if(!GetWindowsDirectoryW(windows,32768))return false;
 auto root=(std::filesystem::path(windows)/L"System32"/L"DriverStore"/L"FileRepository").wstring()+L"\\";
 if(_wcsnicmp(file,root.c_str(),root.size()))return false;
 WINTRUST_FILE_INFO fi{};fi.cbStruct=sizeof(fi);fi.pcwszFilePath=file;
 WINTRUST_DATA data{};data.cbStruct=sizeof(data);data.dwUIChoice=WTD_UI_NONE;data.fdwRevocationChecks=WTD_REVOKE_NONE;data.dwUnionChoice=WTD_CHOICE_FILE;data.pFile=&fi;data.dwStateAction=WTD_STATEACTION_VERIFY;
 GUID policy=WINTRUST_ACTION_GENERIC_VERIFY_V2;bool valid=WinVerifyTrust(nullptr,&policy,&data)==ERROR_SUCCESS;
 if(valid){auto provider=WTHelperProvDataFromStateData(data.hWVTStateData);auto signer=provider?WTHelperGetProvSignerFromChain(provider,0,FALSE,0):nullptr;wchar_t name[512]{};
 if(signer&&signer->csCertChain)CertGetNameStringW(signer->pasCertChain[0].pCert,CERT_NAME_SIMPLE_DISPLAY_TYPE,0,nullptr,name,512);
 valid=!wcscmp(name,L"Microsoft Windows Hardware Compatibility Publisher")||!wcscmp(name,L"NVIDIA Corporation");
 }
 data.dwStateAction=WTD_STATEACTION_CLOSE;WinVerifyTrust(nullptr,&policy,&data);return valid;
}
static HMODULE RetainExactNgx(LPCWSTR requested){
 if(!requested)return nullptr;
 try{
 auto path=std::filesystem::path(requested);if(!path.is_absolute()||_wcsicmp(path.filename().c_str(),L"_nvngx.dll"))return nullptr;
 HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId());if(snapshot==INVALID_HANDLE_VALUE)return nullptr;
 MODULEENTRY32W e{};e.dwSize=sizeof(e);HMODULE found{};
 if(Module32FirstW(snapshot,&e))do{if(!_wcsicmp(e.szExePath,requested)){found=e.hModule;break;}}while(Module32NextW(snapshot,&e));CloseHandle(snapshot);
 if(!found){Log("provider_exact_ngx_not_loaded");return nullptr;}if(!VerifyDriverImage(requested)){Log("provider_exact_ngx_signature_rejected");return nullptr;}
 HMODULE retained{};if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,(LPCWSTR)found,&retained)||retained!=found)return nullptr;
 Log("provider_exact_signed_ngx="+ModulePath(retained));return retained;
 }catch(...){return nullptr;}
}
static bool NormalLoadFlags(DWORD flags){return !(flags & ~(LOAD_WITH_ALTERED_SEARCH_PATH|LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_APPLICATION_DIR|LOAD_LIBRARY_SEARCH_USER_DIRS|LOAD_LIBRARY_SEARCH_SYSTEM32|LOAD_LIBRARY_SEARCH_DEFAULT_DIRS));}
static HMODULE WINAPI CommonLoadW(LPCWSTR p){auto m=RetainExactNgx(p);if(!m)m=commonLoadW(p);if(p)TraceLoad(std::filesystem::path(p).string(),m);return m;}
static HMODULE WINAPI CommonLoadExW(LPCWSTR p,HANDLE f,DWORD flags){auto m=(!f&&NormalLoadFlags(flags))?RetainExactNgx(p):nullptr;if(!m)m=commonLoadExW(p,f,flags);if(p)TraceLoad(std::filesystem::path(p).string(),m);return m;}
static HMODULE WINAPI CommonLoadA(LPCSTR p){auto wide=p?std::filesystem::path(p).wstring():std::wstring{};auto m=p?RetainExactNgx(wide.c_str()):nullptr;if(!m)m=commonLoadA(p);if(p)TraceLoad(p,m);return m;}
static HMODULE WINAPI CommonLoadExA(LPCSTR p,HANDLE f,DWORD flags){auto wide=p?std::filesystem::path(p).wstring():std::wstring{};auto m=(p&&!f&&NormalLoadFlags(flags))?RetainExactNgx(wide.c_str()):nullptr;if(!m)m=commonLoadExA(p,f,flags);if(p)TraceLoad(p,m);return m;}
static FARPROC WINAPI CommonGet(HMODULE m,LPCSTR n){auto p=commonGet(m,n);if((uintptr_t)n>65535&&!strncmp(n,"NVSDK_NGX_VULKAN_",17)){HMODULE owner{};if(p)GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(p),&owner);Log(std::string("provider_export name=")+n+" requested_module="+ModulePath(m)+" owner="+ModulePath(owner));}return p;}
static void TracePluginImports(HMODULE m){
 auto base=(BYTE*)m;auto nt=(IMAGE_NT_HEADERS64*)(base+((IMAGE_DOS_HEADER*)base)->e_lfanew);auto directory=nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];if(!directory.VirtualAddress)return;
 for(auto desc=(IMAGE_IMPORT_DESCRIPTOR*)(base+directory.VirtualAddress);desc->Name;++desc){if(!desc->OriginalFirstThunk)continue;auto names=(IMAGE_THUNK_DATA64*)(base+desc->OriginalFirstThunk);auto slots=(IMAGE_THUNK_DATA64*)(base+desc->FirstThunk);
 for(;names->u1.AddressOfData;++names,++slots){if(IMAGE_SNAP_BY_ORDINAL64(names->u1.Ordinal))continue;auto name=(char*)((IMAGE_IMPORT_BY_NAME*)(base+names->u1.AddressOfData))->Name;void* replacement{};
#define TRACE_IMPORT(symbol,storage,wrapper) if(!strcmp(name,#symbol)){storage=(decltype(storage))slots->u1.Function;replacement=(void*)wrapper;}
 TRACE_IMPORT(LoadLibraryW,commonLoadW,CommonLoadW)
 TRACE_IMPORT(LoadLibraryExW,commonLoadExW,CommonLoadExW)
 TRACE_IMPORT(LoadLibraryA,commonLoadA,CommonLoadA)
 TRACE_IMPORT(LoadLibraryExA,commonLoadExA,CommonLoadExA)
 TRACE_IMPORT(GetProcAddress,commonGet,CommonGet)
#undef TRACE_IMPORT
 if(!replacement)continue;DWORD old{};if(!VirtualProtect(&slots->u1.Function,sizeof(void*),PAGE_READWRITE,&old))continue;InterlockedExchangePointer((PVOID*)&slots->u1.Function,replacement);DWORD ignored{};VirtualProtect(&slots->u1.Function,sizeof(void*),old,&ignored);Log(std::string("provider_trace_import=")+name);
 }}
}
#include "FrameTrace.h"
#include "ShaderTrace.h"
static void Init(){
 wchar_t local[32768]{};GetEnvironmentVariableW(L"LOCALAPPDATA",local,32768);auto logs=std::filesystem::path(local)/L"OptiMFG"/L"XP12";std::error_code ec;std::filesystem::create_directories(logs,ec);logFile.open(logs/(L"connection-"+std::to_wstring(GetCurrentProcessId())+L".log"));
 Log("XP12 import bridge invoked; connection-only experiment; generation OFF");
 wchar_t file[32768]{};GetModuleFileNameW(selfModule,file,32768);auto runtime=std::filesystem::path(file).parent_path()/L"Runtime";auto interposer=runtime/L"sl.interposer.dll";
 if(!sl::security::verifyEmbeddedSignature(interposer.c_str())){Log("blocked: NVIDIA interposer signature validation failed");return;}
 slModule=LoadLibraryExW(interposer.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);if(!slModule){Log("blocked: interposer load failed "+std::to_string(GetLastError()));return;}
 auto init=(PFun_slInit*)originalGet(slModule,"slInit");shutdownSl=(PFun_slShutdown*)originalGet(slModule,"slShutdown");feature=(PFun_slGetFeatureFunction*)originalGet(slModule,"slGetFeatureFunction");
 slGipa=(PFN_vkGetInstanceProcAddr)originalGet(slModule,"vkGetInstanceProcAddr");slGdpa=(PFN_vkGetDeviceProcAddr)originalGet(slModule,"vkGetDeviceProcAddr");
 if(!init||!shutdownSl||!feature||!slGipa||!slGdpa){Log("blocked: SDK exports missing");return;}
 auto path=runtime.wstring();const wchar_t* paths[]={path.c_str()};const sl::Feature features[]={sl::kFeatureDLSS_G,sl::kFeatureReflex};sl::Preferences pref{};
 pref.renderAPI=sl::RenderAPI::eVulkan;pref.pathsToPlugins=paths;pref.numPathsToPlugins=1;pref.featuresToLoad=features;pref.numFeaturesToLoad=2;
 pref.flags=sl::PreferenceFlags::eDisableCLStateTracking;pref.engineVersion="OptiMFG-XP12-experiment-0.1";pref.projectId="65a9e6df-204c-4f03-baa9-d1fcc40896f6";
 pref.logMessageCallback=[](sl::LogType,const char* message){Log(message?message:"");};
 auto commonPath=runtime/L"sl.common.dll";
 if(sl::security::verifyEmbeddedSignature(commonPath.c_str())){auto common=LoadLibraryExW(commonPath.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);if(common)TracePluginImports(common);}
 auto result=init(pref,sl::kSDKVersion);Log("sl_init="+std::to_string(int(result)));initialized=result==sl::Result::eOk;
}
static VkResult VKAPI_CALL CreateDevice(VkPhysicalDevice p,const VkDeviceCreateInfo* ci,const VkAllocationCallbacks* a,VkDevice* d){
 auto result=createDevice(p,ci,a,d);Log("xp12_create_device="+std::to_string(result));
 if(result==VK_SUCCESS){void* set{};auto sr=feature(sl::kFeatureDLSS_G,"slDLSSGSetOptions",set);if(sr==sl::Result::eOk&&set){sl::DLSSGOptions options{};options.mode=sl::DLSSGMode::eOff;Log("connection_test_force_off="+std::to_string(int(((PFun_slDLSSGSetOptions*)set)(sl::ViewportHandle(0),options))));}
 Log("xp12_state_deferred_to_present");}

 return result;
}
static VkResult VKAPI_CALL CreateSwapchain(VkDevice d,const VkSwapchainCreateInfoKHR* ci,const VkAllocationCallbacks* a,VkSwapchainKHR* c){auto result=createSwapchain(d,ci,a,c);if(result==VK_SUCCESS)xpframe::Swapchain(d,ci,*c);Log("xp12_create_swapchain="+std::to_string(result)+" extent="+std::to_string(ci->imageExtent.width)+"x"+std::to_string(ci->imageExtent.height));return result;}
static VkResult VKAPI_CALL Present(VkQueue q,const VkPresentInfoKHR* info){xpframe::BeforePresent(q,info);auto result=present(q,info);auto n=++presents;if(n==1||n%300==0||result<0){xpframe::ShaderCoverage();Log("xp12_present="+std::to_string(result)+" count="+std::to_string(n)+" generated_output=not_tested");void* get{};auto lookup=feature(sl::kFeatureDLSS_G,"slDLSSGGetState",get);if(lookup==sl::Result::eOk&&get){sl::DLSSGState state{};auto status=((PFun_slDLSSGGetState*)get)(sl::ViewportHandle(0),state,nullptr);Log("xp12_present_state="+std::to_string(int(status))+" maximum_generated="+std::to_string(state.numFramesToGenerateMax)+" activation=OFF input_contract=missing");}}return result;}
static void VKAPI_CALL DestroyDevice(VkDevice d,const VkAllocationCallbacks* a){if(initialized.exchange(false)){Log("xp12_shutdown_before_device_destroy");shutdownSl();}destroyDevice(d,a);}
static PFN_vkVoidFunction VKAPI_CALL Gdpa(VkDevice d,const char* n);
static PFN_vkVoidFunction Wrap(const char* name,PFN_vkVoidFunction value){
 if(!value||!name)return value;
 auto traced=xpframe::Wrap(name,value);if(traced!=value)return traced;
 traced=xpframe::WrapShader(name,value);if(traced!=value)return traced;
 if(!strcmp(name,"vkGetDeviceProcAddr"))return (PFN_vkVoidFunction)Gdpa;
 if(!strcmp(name,"vkCreateDevice")){createDevice=(PFN_vkCreateDevice)value;return (PFN_vkVoidFunction)CreateDevice;}
 if(!strcmp(name,"vkCreateSwapchainKHR")){createSwapchain=(PFN_vkCreateSwapchainKHR)value;return (PFN_vkVoidFunction)CreateSwapchain;}
 if(!strcmp(name,"vkQueuePresentKHR")){present=(PFN_vkQueuePresentKHR)value;return (PFN_vkVoidFunction)Present;}
 if(!strcmp(name,"vkDestroyDevice")){destroyDevice=(PFN_vkDestroyDevice)value;return (PFN_vkVoidFunction)DestroyDevice;}
 return value;
}
static PFN_vkVoidFunction VKAPI_CALL Gipa(VkInstance i,const char* n){return Wrap(n,slGipa(i,n));}
static PFN_vkVoidFunction VKAPI_CALL Gdpa(VkDevice d,const char* n){return Wrap(n,slGdpa(d,n));}
static FARPROC WINAPI Get(HMODULE module,LPCSTR name){
 auto value=originalGet(module,name);if((uintptr_t)name<=65535||!value)return value;
 if(strcmp(name,"vkGetInstanceProcAddr")&&strcmp(name,"vkGetDeviceProcAddr"))return value;
 wchar_t file[32768]{};GetModuleFileNameW(module,file,32768);if(_wcsicmp(std::filesystem::path(file).filename().c_str(),L"vulkan-1.dll"))return value;
 try{std::call_once(initOnce,Init);}catch(...){initialized=false;}if(!initialized)return value;
 Log(std::string("XP12 requested ")+name);
 return !strcmp(name,"vkGetInstanceProcAddr")?(FARPROC)Gipa:(FARPROC)Gdpa;
}
static DWORD Bind(){
 wchar_t name[32768]{};GetModuleFileNameW(nullptr,name,32768);auto leaf=wcsrchr(name,L'\\');if(_wcsicmp(leaf?leaf+1:name,L"X-Plane.exe"))return 10;
 auto base=(BYTE*)GetModuleHandleW(nullptr);auto dos=(IMAGE_DOS_HEADER*)base;auto nt=(IMAGE_NT_HEADERS64*)(base+dos->e_lfanew);auto directory=nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];if(!directory.VirtualAddress)return 11;
 for(auto desc=(IMAGE_IMPORT_DESCRIPTOR*)(base+directory.VirtualAddress);desc->Name;++desc){if(!desc->OriginalFirstThunk)continue;auto names=(IMAGE_THUNK_DATA64*)(base+desc->OriginalFirstThunk);auto slots=(IMAGE_THUNK_DATA64*)(base+desc->FirstThunk);
 for(;names->u1.AddressOfData;++names,++slots){if(IMAGE_SNAP_BY_ORDINAL64(names->u1.Ordinal))continue;auto imp=(IMAGE_IMPORT_BY_NAME*)(base+names->u1.AddressOfData);if(strcmp((char*)imp->Name,"GetProcAddress"))continue;
 DWORD old=0;if(!VirtualProtect(&slots->u1.Function,sizeof(void*),PAGE_READWRITE,&old))return 12;originalGet=(decltype(originalGet))slots->u1.Function;InterlockedExchangePointer((PVOID*)&slots->u1.Function,(PVOID)Get);DWORD ignored=0;VirtualProtect(&slots->u1.Function,sizeof(void*),old,&ignored);return 0;}}
 return 13;
}
// Versioned, loader-safe ownership handshake: only modules beside this helper
// in its private Runtime directory. Normal game/NR modules are never claimed.
extern "C" __declspec(dllexport) BOOL WINAPI OptiMFGXp12OwnsModuleV1(HMODULE module){
 wchar_t own[32768]{},candidate[32768]{};
 if(!module||!GetModuleFileNameW(selfModule,own,32768)||!GetModuleFileNameW(module,candidate,32768))return FALSE;
 auto slash=wcsrchr(own,L'\\');if(!slash)return FALSE;slash[1]=0;
 if(wcslen(own)+8>=32768)return FALSE;wcscat_s(own,L"Runtime\\");
 auto length=wcslen(own);if(_wcsnicmp(own,candidate,length))return FALSE;
 auto leaf=candidate+length;if(wcschr(leaf,L'\\')||wcschr(leaf,L'/'))return FALSE;
 for(auto name:{L"OptiMFG_VulkanRuntime.dll",L"sl.interposer.dll",L"sl.common.dll",L"sl.dlss_g.dll",L"sl.reflex.dll",L"sl.pcl.dll"})if(!_wcsicmp(leaf,name))return TRUE;
 return FALSE;
}
extern "C" __declspec(dllexport) DWORD WINAPI OptiMFGXp12Start(void*){return 0;}
BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){selfModule=h;DisableThreadLibraryCalls(h);if(DetourIsHelperProcess())return TRUE;DetourRestoreAfterWith();Bind();}
 return TRUE;
}
