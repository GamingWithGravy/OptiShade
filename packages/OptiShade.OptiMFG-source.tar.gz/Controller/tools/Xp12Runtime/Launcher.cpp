#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <detours/detours.h>
#include <filesystem>
#include <iostream>
int wmain(int argc,wchar_t** argv){
 if(argc!=2){std::cerr<<"Usage: OptiMFG_XP12Launch.exe <absolute path to X-Plane.exe>\n";return 2;}
 auto exe=std::filesystem::absolute(argv[1]);if(_wcsicmp(exe.filename().c_str(),L"X-Plane.exe")||!std::filesystem::is_regular_file(exe))return 3;
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snap==INVALID_HANDLE_VALUE)return 4;PROCESSENTRY32W pe{};pe.dwSize=sizeof(pe);bool running=false;
 if(Process32FirstW(snap,&pe))do{if(!_wcsicmp(pe.szExeFile,L"X-Plane.exe"))running=true;}while(Process32NextW(snap,&pe));CloseHandle(snap);
 if(running){std::cerr<<"Close X-Plane before this early-start connection test.\n";return 5;}
 wchar_t own[32768]{};GetModuleFileNameW(nullptr,own,32768);auto dll=std::filesystem::path(own).parent_path()/L"OptiMFG_XP12Connection.dll";
 if(!std::filesystem::is_regular_file(dll))return 6;
 auto bytes=dll.string();if(std::filesystem::path(bytes)!=dll){std::cerr<<"Experiment folder requires an ANSI-representable path.\n";return 7;}
 std::wstring args=L"\""+exe.wstring()+L"\" --allow_reshade";STARTUPINFOW si{};si.cb=sizeof(si);PROCESS_INFORMATION pi{};
 if(!DetourCreateProcessWithDllExW(exe.c_str(),args.data(),nullptr,nullptr,FALSE,0,nullptr,exe.parent_path().c_str(),&si,&pi,bytes.c_str(),nullptr)){std::cerr<<"Early startup failed: "<<GetLastError()<<"\n";return 8;}
 std::cout<<"XP12 connection experiment launched, PID "<<pi.dwProcessId<<". Frame generation remains OFF.\n";
 CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return 0;
}
