#define VK_USE_PLATFORM_WIN32_KHR
#include <windows.h>
#include <vulkan/vulkan.h>
#include <sl.h>
#include <sl_dlss_g.h>
#include <iostream>
#include <filesystem>
#include <vector>
int wmain(int argc,wchar_t** argv){
 if(argc!=2)return 2;auto folder=std::filesystem::absolute(argv[1]);auto dll=folder/L"sl.interposer.dll";
 auto mod=LoadLibraryExW(dll.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);if(!mod){std::cout<<"load_error="<<GetLastError()<<"\n";return 3;}
 auto init=(PFun_slInit*)GetProcAddress(mod,"slInit");auto shutdown=(PFun_slShutdown*)GetProcAddress(mod,"slShutdown");auto requirements=(PFun_slGetFeatureRequirements*)GetProcAddress(mod,"slGetFeatureRequirements");auto support=(PFun_slIsFeatureSupported*)GetProcAddress(mod,"slIsFeatureSupported");
 if(!init||!shutdown||!requirements||!support)return 4;
 auto path=folder.wstring();const wchar_t* paths[]={path.c_str()};const sl::Feature features[]={sl::kFeatureDLSS_G,sl::kFeatureReflex};
 sl::Preferences pref{};pref.renderAPI=sl::RenderAPI::eVulkan;pref.featuresToLoad=features;pref.numFeaturesToLoad=2;pref.pathsToPlugins=paths;pref.numPathsToPlugins=1;pref.flags=sl::PreferenceFlags::eDisableCLStateTracking;pref.engineVersion="OptiMFG-XP12-experiment-0.1";pref.projectId="65a9e6df-204c-4f03-baa9-d1fcc40896f6";
 pref.logMessageCallback=[](sl::LogType,const char* s){std::cout<<s<<"\n";};
 const auto result=init(pref,sl::kSDKVersion);std::cout<<"sl_init="<<int(result)<<"\n";if(result!=sl::Result::eOk)return 5;
 sl::FeatureRequirements req{};auto res=requirements(sl::kFeatureDLSS_G,req);std::cout<<"requirements="<<int(res)<<" flags="<<uint32_t(req.flags)<<" graphics_queues="<<req.vkNumGraphicsQueuesRequired<<" compute_queues="<<req.vkNumComputeQueuesRequired<<" optical_flow_queues="<<req.vkNumOpticalFlowQueuesRequired<<"\n";
 for(unsigned i=0;i<req.vkNumInstanceExtensions;i++)std::cout<<"instance_extension="<<req.vkInstanceExtensions[i]<<"\n";
 for(unsigned i=0;i<req.vkNumDeviceExtensions;i++)std::cout<<"device_extension="<<req.vkDeviceExtensions[i]<<"\n";
 VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};app.apiVersion=VK_API_VERSION_1_3;VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};ci.pApplicationInfo=&app;VkInstance instance{};
 auto proxyGipa=(PFN_vkGetInstanceProcAddr)GetProcAddress(mod,"vkGetInstanceProcAddr");
 auto createInstance=proxyGipa?(PFN_vkCreateInstance)proxyGipa(nullptr,"vkCreateInstance"):nullptr;
 if(createInstance && createInstance(&ci,nullptr,&instance)==VK_SUCCESS){auto enumerate=(PFN_vkEnumeratePhysicalDevices)proxyGipa(instance,"vkEnumeratePhysicalDevices");uint32_t n=0;enumerate(instance,&n,nullptr);std::vector<VkPhysicalDevice> ds(n);enumerate(instance,&n,ds.data());for(auto pd:ds){VkPhysicalDeviceProperties p{};vkGetPhysicalDeviceProperties(pd,&p);sl::AdapterInfo info{};info.vkPhysicalDevice=pd;std::cout<<"adapter="<<p.deviceName<<" dlssg_support="<<int(support(sl::kFeatureDLSS_G,info))<<"\n";
 if(p.vendorID!=0x10de)continue;
 uint32_t qn=0;vkGetPhysicalDeviceQueueFamilyProperties(pd,&qn,nullptr);std::vector<VkQueueFamilyProperties> queues(qn);vkGetPhysicalDeviceQueueFamilyProperties(pd,&qn,queues.data());uint32_t family=UINT32_MAX;for(uint32_t i=0;i<qn;i++)if(queues[i].queueFlags&VK_QUEUE_GRAPHICS_BIT){family=i;break;}if(family==UINT32_MAX)continue;
 float priority=1;VkDeviceQueueCreateInfo qi{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};qi.queueFamilyIndex=family;qi.queueCount=1;qi.pQueuePriorities=&priority;VkDeviceCreateInfo di{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};di.queueCreateInfoCount=1;di.pQueueCreateInfos=&qi;const char* ext[]={VK_KHR_SWAPCHAIN_EXTENSION_NAME};di.enabledExtensionCount=1;di.ppEnabledExtensionNames=ext;
 auto createDevice=(PFN_vkCreateDevice)proxyGipa(instance,"vkCreateDevice");VkDevice device{};auto dr=createDevice(pd,&di,nullptr,&device);std::cout<<"proxy_create_device="<<dr<<"\n";
 if(dr==VK_SUCCESS){bool deviceReady=false;auto getFunction=(PFun_slGetFeatureFunction*)GetProcAddress(mod,"slGetFeatureFunction");void* state{};auto lookup=getFunction(sl::kFeatureDLSS_G,"slDLSSGGetState",state);std::cout<<"state_lookup="<<int(lookup)<<"\n";if(lookup==sl::Result::eOk&&state){sl::DLSSGState gs{};auto sr=((PFun_slDLSSGGetState*)state)(sl::ViewportHandle(0),gs,nullptr);std::cout<<"state_result="<<int(sr)<<" max_generated="<<gs.numFramesToGenerateMax<<"\n";deviceReady=sr==sl::Result::eOk&&gs.numFramesToGenerateMax>0;}shutdown();vkDestroyDevice(device,nullptr);vkDestroyInstance(instance,nullptr);std::cout<<"Device initialized only; no swapchain, inference or generated frames.\n";return deviceReady?0:7;}}shutdown();vkDestroyInstance(instance,nullptr);}else shutdown();
 std::cout<<"No game attached; device initialization not completed.\n";return 8;
}
