#define VK_USE_PLATFORM_WIN32_KHR
#include <windows.h>
#include <vulkan/vulkan.h>
#include <iostream>
#include <vector>
#include <cstring>
int main(){
 VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};app.pApplicationName="OptiMFG XP12 hardware probe";app.apiVersion=VK_API_VERSION_1_1;
 VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};ci.pApplicationInfo=&app;
 VkInstance instance{};auto rc=vkCreateInstance(&ci,nullptr,&instance);if(rc){std::cout<<"create_instance="<<rc<<"\n";return 1;}
 uint32_t count=0;vkEnumeratePhysicalDevices(instance,&count,nullptr);std::vector<VkPhysicalDevice> devices(count);vkEnumeratePhysicalDevices(instance,&count,devices.data());
 for(auto pd:devices){
  VkPhysicalDeviceIDProperties id{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ID_PROPERTIES};VkPhysicalDeviceProperties2 prop{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2};prop.pNext=&id;vkGetPhysicalDeviceProperties2(pd,&prop);
  std::cout<<"adapter="<<prop.properties.deviceName<<" vendor="<<prop.properties.vendorID<<" luid_valid="<<id.deviceLUIDValid<<"\n";
  uint32_t n=0;vkEnumerateDeviceExtensionProperties(pd,nullptr,&n,nullptr);std::vector<VkExtensionProperties> ex(n);vkEnumerateDeviceExtensionProperties(pd,nullptr,&n,ex.data());
  for(const auto& e:ex)if(strstr(e.extensionName,"external_memory_win32")||strstr(e.extensionName,"external_semaphore_win32")||strstr(e.extensionName,"optical_flow"))std::cout<<"extension="<<e.extensionName<<"\n";
  vkGetPhysicalDeviceQueueFamilyProperties(pd,&n,nullptr);std::vector<VkQueueFamilyProperties> qs(n);vkGetPhysicalDeviceQueueFamilyProperties(pd,&n,qs.data());for(uint32_t i=0;i<n;++i)std::cout<<"queue="<<i<<" flags="<<qs[i].queueFlags<<" count="<<qs[i].queueCount<<"\n";
  for(auto format:{VK_FORMAT_B8G8R8A8_UNORM,VK_FORMAT_R32_SFLOAT,VK_FORMAT_R16G16_SFLOAT}){
   VkPhysicalDeviceExternalImageFormatInfo ext{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_IMAGE_FORMAT_INFO};ext.handleType=VK_EXTERNAL_MEMORY_HANDLE_TYPE_D3D12_RESOURCE_BIT;
   VkPhysicalDeviceImageFormatInfo2 query{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_IMAGE_FORMAT_INFO_2};query.pNext=&ext;query.format=format;query.type=VK_IMAGE_TYPE_2D;query.tiling=VK_IMAGE_TILING_OPTIMAL;query.usage=VK_IMAGE_USAGE_TRANSFER_SRC_BIT|VK_IMAGE_USAGE_TRANSFER_DST_BIT;
   VkExternalImageFormatProperties ep{VK_STRUCTURE_TYPE_EXTERNAL_IMAGE_FORMAT_PROPERTIES};VkImageFormatProperties2 result{VK_STRUCTURE_TYPE_IMAGE_FORMAT_PROPERTIES_2};result.pNext=&ep;
   auto status=vkGetPhysicalDeviceImageFormatProperties2(pd,&query,&result);
   std::cout<<"format="<<format<<" result="<<status<<" external_features="<<ep.externalMemoryProperties.externalMemoryFeatures<<" compatible_handles="<<ep.externalMemoryProperties.compatibleHandleTypes<<" max_extent="<<result.imageFormatProperties.maxExtent.width<<"x"<<result.imageFormatProperties.maxExtent.height<<"\n";
  }
  VkPhysicalDeviceExternalSemaphoreInfo sem{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_SEMAPHORE_INFO};sem.handleType=VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_D3D12_FENCE_BIT;VkExternalSemaphoreProperties sp{VK_STRUCTURE_TYPE_EXTERNAL_SEMAPHORE_PROPERTIES};vkGetPhysicalDeviceExternalSemaphoreProperties(pd,&sem,&sp);std::cout<<"d3d12_fence_features="<<sp.externalSemaphoreFeatures<<"\n";
 }
 vkDestroyInstance(instance,nullptr);std::cout<<"No game attached; no inference or generated frames tested.\n";
}
