param(
 [Parameter(Mandatory=$true)][string]$OptiShadeRoot,
 [Parameter(Mandatory=$true)][string]$StreamlineSdk,
 [string]$OutputDirectory='',
 [switch]$Run
)
$ErrorActionPreference='Stop'
if(-not $OutputDirectory){$OutputDirectory=Join-Path $PSScriptRoot '../../artifacts/xp12-experiment'}
$OptiShadeRoot=[IO.Path]::GetFullPath($OptiShadeRoot)
$StreamlineSdk=[IO.Path]::GetFullPath($StreamlineSdk)
$OutputDirectory=[IO.Path]::GetFullPath($OutputDirectory)
$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$vs=& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if(-not $vs){throw 'MSVC x64 tools are required.'}
$vcvars=Join-Path $vs 'VC/Auxiliary/Build/vcvars64.bat'
$headers=Join-Path $OptiShadeRoot 'Beta/optiscaler/external/vulkan/include'
$lib=Join-Path $OptiShadeRoot 'Beta/optiscaler/OptiScaler/library/vulkan/vulkan-1.lib'
$runtime=Join-Path $StreamlineSdk 'bin/x64'
foreach($name in @('sl.interposer.dll','sl.common.dll','sl.dlss_g.dll','sl.reflex.dll','sl.pcl.dll','nvngx_dlssg.dll')){
 $signature=Get-AuthenticodeSignature -LiteralPath (Join-Path $runtime $name)
 if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'NVIDIA Corporation'){throw "Unverified NVIDIA runtime: $name"}
}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
foreach($value in @($vcvars,$headers,$lib,$StreamlineSdk,$PSScriptRoot,$OutputDirectory)){if($value -match '["%\r\n]'){throw 'Unsupported command-file path character.'}}
$script=@"
@echo off
call "$vcvars" >nul
if errorlevel 1 exit /b 1
cd /d "$OutputDirectory"
cl /nologo /std:c++20 /EHsc /MD /I"$headers" "$PSScriptRoot\Main.cpp" /Fe:OptiMFG_Xp12Probe.exe /link "$lib"
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /EHsc /MD /I"$headers" /I"$StreamlineSdk\include" "$PSScriptRoot\StreamlineProbe.cpp" /Fe:OptiMFG_Xp12StreamlineProbe.exe /link "$lib"
exit /b %errorlevel%
"@
$cmdPath=Join-Path $OutputDirectory 'build-probes.cmd'
[IO.File]::WriteAllText($cmdPath,$script,[Text.Encoding]::Default)
& cmd.exe /d /c $cmdPath
if($LASTEXITCODE){throw "Probe compilation failed: $LASTEXITCODE"}
if($Run){
 & (Join-Path $OutputDirectory 'OptiMFG_Xp12Probe.exe') *> (Join-Path $OutputDirectory 'hardware.txt')
 if($LASTEXITCODE){throw "Hardware query failed: $LASTEXITCODE"}
 & (Join-Path $OutputDirectory 'OptiMFG_Xp12StreamlineProbe.exe') $runtime *> (Join-Path $OutputDirectory 'streamline.txt')
 if($LASTEXITCODE){throw "Streamline device experiment failed: $LASTEXITCODE"}
}
Write-Output "Probes built at $OutputDirectory. These do not attach to a game or generate frames."
