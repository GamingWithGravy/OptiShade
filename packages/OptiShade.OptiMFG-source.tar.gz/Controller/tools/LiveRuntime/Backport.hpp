﻿#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <filesystem>
#include <fstream>
#include <chrono>
#include <stdexcept>
#include <array>
#include <initializer_list>
#include <iomanip>
#include <mutex>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <bcrypt.h>
#include "../../third_party/nlohmann/json.hpp"
#include "AutoConnectPolicy.hpp"

#pragma comment(lib, "bcrypt.lib")

namespace omfg::live {
// File transport used by MFG Unlocker 1.7.0 itself. No Streamline hooks are
// installed by this adapter: there must be exactly one frame-generation owner.
struct Backport {
    using Json=nlohmann::json;
    using Route=ProviderRoute;
    static constexpr char MfgUnlocker170Sha256[]="E6B6E6B70A6ED3AF839C9647A32FC22660AE6B2D655062C5C072246C91FC10C7";
    std::filesystem::path folder;
    DWORD pid{}; uint64_t birth{}; HANDLE writer{};
    Json snapshot; bool fresh=false; int requested=-1;
    std::filesystem::path executable;
    bool ownsRequest=false;
    bool headless=false;
    std::filesystem::path ConfigPath() const {return folder/(headless?L"RTX40MFG-Universal.json":L"RTXMFG-Universal.json");}
    std::filesystem::path StatusPath() const {return folder/(headless?L"RTX40MFG-Universal.status.json":L"RTXMFG-Universal.status.json");}
    ~Backport(){Close();}
    void Close(){if(writer)CloseHandle(writer);writer=nullptr;pid=0;fresh=false;requested=-1;ownsRequest=false;}
    static uint64_t Now(){return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count());}
    static Json ReadFile(std::filesystem::path const& path,size_t limit=1024*1024){
        const bool liveStatus=path.filename().wstring().find(L".status.json")!=std::wstring::npos;
        // The provider rewrites its live status while the controller polls it.
        // A read that overlaps that write can otherwise look like a corrupt or
        // truncated JSON document and incorrectly flip the UI to "waiting".
        constexpr unsigned maxStatusReadAttempts=4;
        for(unsigned attempt=0;;++attempt){
            std::error_code ec;const auto size=std::filesystem::file_size(path,ec);
            if(ec){
                if(liveStatus&&ec==std::errc::no_such_file_or_directory)
                    throw std::runtime_error("Backend status is not ready; waiting for the game");
                throw std::runtime_error("Cannot inspect backend JSON");
            }
            if(size>limit)throw std::runtime_error("Backend JSON exceeds size limit");
            std::ifstream in(path,std::ios::binary);if(!in)throw std::runtime_error("Cannot read backend JSON");
            std::string bytes(static_cast<size_t>(size),'\0');
            in.read(bytes.data(),static_cast<std::streamsize>(bytes.size()));
            const bool complete=static_cast<size_t>(in.gcount())==bytes.size()&&!in.bad();
            if(!complete){
                if(liveStatus&&attempt+1<maxStatusReadAttempts){Sleep(8);continue;}
                throw std::runtime_error(liveStatus?"Backend status changed while being read; retrying":"Cannot read complete backend JSON");
            }
            try{
                auto j=Json::parse(bytes);
                if(!j.is_object())throw std::runtime_error("Backend JSON is not an object");
                return j;
            }catch(Json::parse_error const&){
                if(liveStatus&&attempt+1<maxStatusReadAttempts){Sleep(8);continue;}
                throw;
            }
        }
    }
    static void Save(std::filesystem::path const& path,Json const& value){
        auto bytes=value.dump();if(bytes.size()>4096)throw std::runtime_error("Backend settings exceed provider's 4096-byte limit");
        auto temp=path;temp+=L".optimfg-"+std::to_wstring(GetCurrentProcessId())+L".tmp";
        HANDLE file=CreateFileW(temp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
        if(file==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot create backend settings temporary file");
        DWORD count{};bool ok=WriteFile(file,bytes.data(),static_cast<DWORD>(bytes.size()),&count,nullptr)&&count==bytes.size()&&FlushFileBuffers(file);CloseHandle(file);
        if(!ok||!MoveFileExW(temp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){DeleteFileW(temp.c_str());throw std::runtime_error("Cannot atomically save backend settings");}
    }
    static std::filesystem::path ProcessExecutable(DWORD id){
        HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,id);if(!p)throw std::runtime_error("Cannot inspect game process");
        wchar_t name[32768]{};DWORD size=32768;bool ok=QueryFullProcessImageNameW(p,0,name,&size)!=FALSE;CloseHandle(p);
        if(!ok)throw std::runtime_error("Cannot locate game executable");return std::filesystem::path(name);
    }
    static std::filesystem::path ProcessFolder(DWORD id){return ProcessExecutable(id).parent_path();}
    static std::string Sha256(std::filesystem::path const& path){
        struct CachedHash{uintmax_t size{};std::filesystem::file_time_type modified{};std::string hash;};
        static std::mutex lock;static std::unordered_map<std::wstring,CachedHash> cache;
        std::error_code ec;auto size=std::filesystem::file_size(path,ec);if(ec)throw std::runtime_error("Cannot inspect MFG provider file");
        auto modified=std::filesystem::last_write_time(path,ec);if(ec)throw std::runtime_error("Cannot inspect MFG provider file timestamp");
        auto key=std::filesystem::absolute(path,ec).lexically_normal().wstring();if(ec)key=path.lexically_normal().wstring();
        {std::lock_guard<std::mutex> guard(lock);auto it=cache.find(key);if(it!=cache.end()&&it->second.size==size&&it->second.modified==modified)return it->second.hash;}
        BCRYPT_ALG_HANDLE algorithm{};BCRYPT_HASH_HANDLE hash{};std::vector<UCHAR> object,digest;
        auto close=[&]{if(hash)BCryptDestroyHash(hash);if(algorithm)BCryptCloseAlgorithmProvider(algorithm,0);};
        if(!BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0))){throw std::runtime_error("Cannot verify MFG provider file identity");}
        DWORD objectBytes=0,digestBytes=0,resultBytes=0;
        if(!BCRYPT_SUCCESS(BCryptGetProperty(algorithm,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&objectBytes),sizeof(objectBytes),&resultBytes,0))||
           !BCRYPT_SUCCESS(BCryptGetProperty(algorithm,BCRYPT_HASH_LENGTH,reinterpret_cast<PUCHAR>(&digestBytes),sizeof(digestBytes),&resultBytes,0))){close();throw std::runtime_error("Cannot initialize MFG provider verification");}
        object.resize(objectBytes);digest.resize(digestBytes);
        if(!BCRYPT_SUCCESS(BCryptCreateHash(algorithm,&hash,object.data(),objectBytes,nullptr,0,0))){close();throw std::runtime_error("Cannot initialize MFG provider verification");}
        std::ifstream input(path,std::ios::binary);if(!input){close();throw std::runtime_error("Cannot read MFG provider file");}
        std::array<char,65536> buffer{};
        while(input){input.read(buffer.data(),static_cast<std::streamsize>(buffer.size()));auto count=input.gcount();if(count>0&&!BCRYPT_SUCCESS(BCryptHashData(hash,reinterpret_cast<PUCHAR>(buffer.data()),static_cast<ULONG>(count),0))){close();throw std::runtime_error("Cannot verify MFG provider file identity");}}
        if(input.bad()||!BCRYPT_SUCCESS(BCryptFinishHash(hash,digest.data(),digestBytes,0))){close();throw std::runtime_error("Cannot verify MFG provider file identity");}
        close();std::ostringstream out;out<<std::uppercase<<std::hex<<std::setfill('0');for(auto value:digest)out<<std::setw(2)<<static_cast<unsigned>(value);auto value=out.str();
        {std::lock_guard<std::mutex> guard(lock);cache[key]=CachedHash{size,modified,value};}
        return value;
    }
    static bool IsPinnedMfgUnlockerProxy(std::filesystem::path const& proxy,std::string_view expectedHash=MfgUnlocker170Sha256){
        try{return Sha256(proxy)==expectedHash;}catch(...){return false;}
    }
    static bool UnlockerUiHidden(Json const& manifest,std::filesystem::path const& folder){
        if(manifest.value("optiScalerUi",std::string{})!="optiscaler")return false;
        try{auto settings=ReadFile(folder/L"RTXMFG-Universal.json",4096);return settings.value("optiScalerUi",std::string{})=="optiscaler";}
        catch(...){return false;}
    }
    static bool HasAnyArtifact(std::filesystem::path const& folder,std::initializer_list<wchar_t const*> names){
        for(auto name:names)if(std::filesystem::exists(folder/name))return true;
        return false;
    }
    static Route DetectRoute(std::filesystem::path const& folder,std::string_view expectedMfgHash=MfgUnlocker170Sha256){
        auto marker=folder/L"OptiMFGTest-backend.json";
        if(std::filesystem::exists(marker)){
            auto manifest=ReadFile(marker,4096);
            auto version=manifest.value("providerVersion",std::string{});
            auto proxy=manifest.value("proxy",std::string{});
            auto route=SelectProviderRoute(true,version,proxy);
            if(route==Route::Unsupported)throw std::runtime_error("Unsupported OptiMFG backend manifest; no route was selected");
            if(route==Route::MfgUnlocker&&HasAnyArtifact(folder,{L"version.ini",L"RTX40MFG.asi",L"RTX40MFGCore.dll",L"RTX40MFG-Universal.json",L"RTX40MFG-Universal.status.json",L"RTX40MFG-UI.ini",L"RTX40MFG-UI.addon64",L"RTXMFG.dll",L"RTXMFGCore.dll"}))
                throw std::runtime_error("Conflicting menu-free MFG backend files are present beside MFG Unlocker. Remove or repair the other provider before attaching OptiMFG.");
            if(route==Route::Headless&&HasAnyArtifact(folder,{L"RTXMFG-Universal.json",L"RTXMFG-Universal.status.json",L"RTX40MFG-UI.ini",L"RTX40MFG-UI.addon64",L"MFGUnlocker.dll",L"RTXMFG.dll",L"RTXMFGCore.dll"}))
                throw std::runtime_error("Conflicting MFG Unlocker files/settings are present beside the menu-free backend. Remove or repair the other provider before attaching OptiMFG.");
            if(route==Route::MfgUnlocker&&!IsPinnedMfgUnlockerProxy(folder/L"version.dll",expectedMfgHash))
                throw std::runtime_error("Installed MFG Unlocker file does not match the bundled version. Repair or reinstall the OptiMFG component, then restart the simulator.");
            // OptiShade's own MFG Unlocker runs with its UI hidden ("optiScalerUi":"optiscaler"):
            // no menu, no hint, no window/swapchain/input hooks. It then raises the frame count the
            // game's DLSS-G call asks for instead of reading its settings file, so OptiShade's
            // controls set that count through the native Streamline route, as on RTX 50.
            if(route==Route::MfgUnlocker&&UnlockerUiHidden(manifest,folder))return Route::Native;
            return route;
        }
        // MFG Unlocker can predate OptiMFG's ownership marker. Recognize its
        // documented settings plus its version proxy so native Streamline
        // does not win by default and silently cap RTX 40 at 2x.
        auto proxy=folder/L"version.dll",config=folder/L"RTXMFG-Universal.json";
        const bool hasProxy=std::filesystem::is_regular_file(proxy);
        const bool hasConfig=std::filesystem::is_regular_file(config);
        if(!hasProxy&&!hasConfig){
            if(HasAnyArtifact(folder,{L"version.ini",L"RTX40MFGCore.dll",L"RTX40MFG.asi",L"RTX40MFG-Universal.json",L"RTX40MFG-Universal.status.json",L"RTX40MFG-UI.ini",L"RTX40MFG-UI.addon64",L"RTXMFG.dll",L"RTXMFGCore.dll",L"MFGUnlocker.dll"}))
                throw std::runtime_error("Unowned MFG backend files/settings are present. Refusing to attach native controls beside an unknown provider; remove or repair it with its owner first.");
            return Route::Native;
        }
        if(!hasProxy||!hasConfig)
            throw std::runtime_error("An unowned MFG proxy or settings file is present without its matching pair. Refusing to attach the native helper; remove or repair the existing provider first.");
        Json settings;try{settings=ReadFile(config,4096);}catch(...){
            throw std::runtime_error("An unowned version.dll is paired with unreadable MFG settings. Refusing to attach the native helper; verify the provider with its owner first.");
        }
        bool recognized=settings.value("version",0)==13&&settings.contains("followGame")&&settings.at("followGame").is_boolean()&&
            settings.contains("mode")&&settings.at("mode").is_string()&&settings.contains("multiplier")&&
            settings.at("multiplier").is_number_integer()&&settings.contains("intervalLogging")&&settings.at("intervalLogging").is_boolean();
        if(!recognized)
            throw std::runtime_error("An unrecognized version.dll or MFG settings file is present. Refusing to attach the native helper beside an unknown provider.");
        if(!IsPinnedMfgUnlockerProxy(proxy,expectedMfgHash))
            throw std::runtime_error("An older or unrecognized version.dll is paired with MFG Unlocker settings. Repair or reinstall the OptiMFG component, then restart the simulator.");
        if(HasAnyArtifact(folder,{L"version.ini",L"RTX40MFGCore.dll",L"RTX40MFG.asi",L"RTX40MFG-Universal.json",L"RTX40MFG-Universal.status.json",L"RTX40MFG-UI.ini",L"RTX40MFG-UI.addon64",L"RTXMFG.dll",L"RTXMFGCore.dll"}))
            throw std::runtime_error("Conflicting menu-free MFG backend files/settings are present beside MFG Unlocker. Remove or repair the other provider before attaching OptiMFG.");
        return Route::MfgUnlocker;
    }
    static bool RouteModuleLoaded(DWORD id,Route route){
        if(route==Route::Native)return HasModule(id,L"sl.interposer.dll");
        if(route==Route::Headless)return HasModule(id,L"version.dll")&&HasModule(id,L"RTX40MFGCore.dll");
        if(route==Route::MfgUnlocker)return HasModule(id,L"version.dll");
        return false;
    }
    static bool HasModule(DWORD id,wchar_t const* name){
        HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,id);
        if(modules==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot inspect game modules");
        MODULEENTRY32W m{};m.dwSize=sizeof(m);bool found=false;
        if(Module32FirstW(modules,&m))do{if(!_wcsicmp(m.szModule,name)){found=true;break;}}while(Module32NextW(modules,&m));
        CloseHandle(modules);return found;
    }
    static void Validate(Json const& j,DWORD id,uint64_t created,uint64_t now){
        if(j.at("version").get<unsigned>()!=41||j.at("pid").get<DWORD>()!=id||j.at("processBirth").get<uint64_t>()!=created)
            throw std::runtime_error("Backend status belongs to another process or unsupported protocol");
        auto beat=j.at("heartbeat").get<uint64_t>();if(beat>now||now-beat>5)throw std::runtime_error("Backend status is stale; waiting for the game");
        auto max=j.at("safeMaximumMultiplier").get<int>();if(max<2||max>6)throw std::runtime_error("Invalid backend multiplier limit");
        auto family=j.at("gpuFamily").get<int>();if(family!=1&&family!=2&&family!=4&&family!=5)throw std::runtime_error("Backend GPU selection is unavailable or ambiguous");
        for(auto key:{"bridgeReady","gameFrameGenerationOn","appliedFrameGenerationOn","followGame","setOptionsAccepted","pending"})
            if(!j.at(key).is_boolean())throw std::runtime_error("Invalid backend status field");
    }
    static void ValidateHeadless(Json const& j,DWORD id,uint64_t created,uint64_t now){
        if(j.at("version").get<unsigned>()!=1801||!j.at("externalUiOnly").get<bool>())throw std::runtime_error("Unsupported menu-free backend protocol");
        if(j.at("pid").get<DWORD>()!=id||j.at("processBirth").get<uint64_t>()!=created)throw std::runtime_error("Backend status belongs to an earlier game session; waiting for the game");
        auto beat=j.at("heartbeat").get<uint64_t>();if(beat>now||now-beat>5)throw std::runtime_error("Menu-free backend status is stale");
        auto maximum=j.at("safeMaximumMultiplier").get<int>();if(maximum<2||maximum>6)throw std::runtime_error("Invalid backend multiplier limit");
        for(auto key:{"bridgeReady","gameFrameGenerationOn","followGame","setOptionsAccepted","pending"})if(!j.at(key).is_boolean())throw std::runtime_error("Invalid backend status field");
    }
    static void ValidateRouteFamily(Route route,Json const& j){
        // MFG Unlocker 1.7.0 is OptiShade's backend for RTX 40 (1), RTX 30 (2) and
        // RTX 20 (4). RTX 50 keeps the native route; AMD uses OptiScaler's XeFG count.
        if(route==Route::MfgUnlocker){
            auto family=j.value("gpuFamily",0);
            if(family!=1&&family!=2&&family!=4)
                throw std::runtime_error("MFG Unlocker reported a GPU outside its RTX 20/30/40 route; refusing that provider status");
        }
        if(route==Route::Headless&&j.contains("gpuFamily")){
            auto family=j.at("gpuFamily").get<int>();
            if(family!=2&&family!=4)throw std::runtime_error("The older-card backend reported a GPU family outside its RTX 20/30 route");
        }
    }
    // Read-only proof for disambiguating launcher/helper processes. Never
    // acquire a writer or inject a helper merely to choose an auto-connect PID.
    static bool HasFreshRenderingStatus(DWORD id) {
        try {
            auto folder=ProcessFolder(id);auto route=DetectRoute(folder);
            if(route!=Route::Headless&&route!=Route::MfgUnlocker)return false;
            if(!RouteModuleLoaded(id,route))return false;
            HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,id);
            FILETIME created{},exit{},kernel{},user{};
            bool alive=process&&WaitForSingleObject(process,0)==WAIT_TIMEOUT&&GetProcessTimes(process,&created,&exit,&kernel,&user);
            if(process)CloseHandle(process);if(!alive)return false;
            uint64_t birth=(uint64_t(created.dwHighDateTime)<<32)|created.dwLowDateTime;
            auto status=ReadFile(folder/(route==Route::Headless?L"RTX40MFG-Universal.status.json":L"RTXMFG-Universal.status.json"));
            if(route==Route::Headless)ValidateHeadless(status,id,birth,Now());else Validate(status,id,birth,Now());
            ValidateRouteFamily(route,status);
            return status.value("bridgeReady",false)&&status.value("setOptionsAccepted",false)&&
                   status.value("ngxEvaluateCalls",uint64_t{0})>0;
        } catch(...) {return false;}
    }
    void Poll(){fresh=false;auto j=ReadFile(StatusPath());if(headless)ValidateHeadless(j,pid,birth,Now());else Validate(j,pid,birth,Now());ValidateRouteFamily(headless?Route::Headless:Route::MfgUnlocker,j);snapshot=std::move(j);fresh=true;}
    void Open(DWORD id){
        Close();executable=ProcessExecutable(id);folder=executable.parent_path();
        if(HasModule(id,L"OptiMFG_LiveHelper_v4.dll"))throw std::runtime_error("Native helper is already loaded. Restart game before using the experimental backend");
        auto marker=folder/L"OptiMFGTest-backend.json";
        if(std::filesystem::exists(marker)){
            auto manifest=ReadFile(marker,4096);
            headless=manifest.value("providerVersion",std::string{})=="1.2.2-optimfg.1";
            if((!headless&&manifest.at("providerVersion")!="1.7.0")||manifest.at("proxy")!="version.dll")throw std::runtime_error("Unsupported OptiMFG backend installation");
            if(!headless&&!IsPinnedMfgUnlockerProxy(folder/L"version.dll"))throw std::runtime_error("Installed MFG Unlocker file does not match the bundled version. Repair or reinstall the OptiMFG component, then restart the simulator.");
        }else{
            if(DetectRoute(folder)!=Route::MfgUnlocker)throw std::runtime_error("No recognized MFG Unlocker installation was found; native Streamline remains selected");
            headless=false;
        }
        if(headless&&!HasModule(id,L"RTX40MFGCore.dll"))throw std::runtime_error("Waiting for menu-free backend to load");
        if(!HasModule(id,L"version.dll"))throw std::runtime_error("Experimental loader was not loaded by this game");
        HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,id);FILETIME c{},e{},k{},u{};
        bool ok=p&&GetProcessTimes(p,&c,&e,&k,&u);if(p)CloseHandle(p);if(!ok)throw std::runtime_error("Cannot verify game process lifetime");
        birth=(uint64_t(c.dwHighDateTime)<<32)|c.dwLowDateTime;pid=id;
        writer=CreateMutexW(nullptr,FALSE,(L"Local\\OptiMFG.Live.Writer."+std::to_wstring(id)).c_str());
        if(!writer||GetLastError()==ERROR_ALREADY_EXISTS){Close();throw std::runtime_error("Another OptiMFG controller owns this game");}
        try{Poll();}catch(...){Close();throw;}
    }
    void Request(int value){
        if(!pid)throw std::runtime_error("Connect the experimental backend first");
        if(value!=-1&&value!=0&&(value<2||value>6))throw std::runtime_error("Invalid multiplier");
        if(value!=-1){Poll();if(!snapshot.at("bridgeReady").get<bool>())throw std::runtime_error("Backend not ready: "+snapshot.value("universalRouteFailureReason",std::string("waiting for provider")));
            if(value>snapshot.at("safeMaximumMultiplier").get<int>())throw std::runtime_error("Backend has not enabled this multiplier on this game/GPU");
            if(value==0&&(headless||(snapshot.at("gpuFamily").get<int>()!=2&&snapshot.at("gpuFamily").get<int>()!=4)))
                throw std::runtime_error("Use the game's FG Off setting on RTX 40/50 with this experimental backend");}
        auto path=ConfigPath();
        auto j=ReadFile(path,4096); // Preserve every unrelated provider setting.
        if(j.at("version").get<int>()!=13)throw std::runtime_error("Unsupported backend settings version");
        j["followGame"]=value==-1;j["mode"]=value==-1?"follow":"fixed";j["multiplier"]=value<0?2:value==0?1:value;
        j["dynamicTargetFrameRate"]=0;j["dynamicExperimental56"]=false;j["generatedOnlyDebug"]=false;
        Save(path,j);requested=value;ownsRequest=value!=-1;
    }
    void ExportFiles(std::filesystem::path const& dest) const {
        if(folder.empty())return;
        if(headless){
            for(auto path:{ConfigPath(),StatusPath(),folder/L"OptiMFGTest-backend.json"})if(std::filesystem::exists(path))std::filesystem::copy_file(path,dest/path.filename(),std::filesystem::copy_options::overwrite_existing);
            for(auto prefix:{L"MfgUnlock-",L"MfgUnlock-intervals-"})for(auto ext:{L".log",L".csv"}){auto path=std::filesystem::temp_directory_path()/(std::wstring(prefix)+std::to_wstring(pid)+ext);if(std::filesystem::exists(path))std::filesystem::copy_file(path,dest/path.filename(),std::filesystem::copy_options::overwrite_existing);}
            return;
        }
        for(auto name:{L"RTXMFG-Universal.json",L"RTXMFG-Universal.status.json",L"OptiMFGTest-backend.json"}){
            auto path=folder/name;if(std::filesystem::exists(path))std::filesystem::copy_file(path,dest/name,std::filesystem::copy_options::overwrite_existing);
        }
        // Match this executable's upstream log identity, including its previous
        // launch and PID-suffixed fallback. Never collect other games' logs.
        auto normalized=executable.wstring();uint64_t hash=14695981039346656037ull;
        for(auto ch:normalized){if(ch==L'/')ch=L'\\';if(ch>=L'A'&&ch<=L'Z')ch+=L'a'-L'A';hash^=static_cast<uint16_t>(ch);hash*=1099511628211ull;}
        auto stem=executable.stem().wstring().substr(0,40);for(auto& ch:stem){if(ch>=L'A'&&ch<=L'Z')ch+=L'a'-L'A';if(!((ch>=L'a'&&ch<=L'z')||(ch>=L'0'&&ch<=L'9')||ch==L'-'||ch==L'_'))ch=L'_';}
        wchar_t suffix[24]{};swprintf_s(suffix,L"-%016llX",static_cast<unsigned long long>(hash));auto prefix=L"RTXMFG-"+stem+suffix;
        for(auto const& root:{folder,std::filesystem::temp_directory_path()}){
            for(auto const& entry:std::filesystem::directory_iterator(root)){
                auto name=entry.path().filename().wstring();
                if(entry.is_regular_file()&&name.rfind(prefix+L".",0)==0&&entry.path().extension()==L".log")
                    std::filesystem::copy_file(entry.path(),dest/entry.path().filename(),std::filesystem::copy_options::overwrite_existing);
            }
        }
    }
};
}
