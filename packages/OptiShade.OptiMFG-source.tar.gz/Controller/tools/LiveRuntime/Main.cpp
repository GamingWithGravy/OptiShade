﻿#include "Client.hpp"
#include "AutoConnectPolicy.hpp"
#include <shellapi.h>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <memory>
#include <optional>
#include <algorithm>
#include <future>
#include <OptiMFG/DriverController.hpp>
#include "Fps.hpp"
#include "DiagnosticsZip.hpp"
#include "Backport.hpp"
#include <OptiMFG/ControllerProtocol.hpp>
#include <d3d11.h>
#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>
#include <PanelUi.h>
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
using namespace omfg::live;
namespace fs=std::filesystem;
static constexpr UINT OptiMfgTrayMessage=WM_APP+42;
static constexpr UINT OptiMfgTrayIconId=1;
static constexpr UINT OptiMfgTrayShow=51001;
static constexpr UINT OptiMfgTrayPanel=51002;
static constexpr UINT OptiMfgTrayExport=51003;
static constexpr UINT OptiMfgTrayExit=51004;
static HBRUSH OptiMfgBackgroundBrush{};
static HBRUSH OptiMfgSurfaceBrush{};
struct App {
    omfg::controller::Channel controller; LONG controllerHelperSequence{};
#include "ControllerService.inl"
    HWND window{},list{},mode{},status{},driverText{},fpsText{},viewportEdit{},hotkey{},overlay{};Channel channel;std::vector<Process> processes;DWORD pid{};
    HWND panelKey{},returnButton{},returnWindow{};bool panelOpen=false;RECT desktopRect{};LONG_PTR desktopStyle{},desktopExStyle{};
    HWND autoConnect{};ULONGLONG nextAutoScan{};DWORD autoAttemptedPid{};bool connecting=false;std::wstring autoMessage;
    DWORD autoCandidatePid{};ULONGLONG providerSeenSince{};
    Backport backport;std::string backportError,lastFpsError;bool backportSupportsOff{};
    LONG listedMaximum{-1};int listedFamily{-1};bool listedSupportsOff{};std::future<void> zipTask;fs::path zipPath;bool openExportFolder=false;
    HANDLE launchGame{};DWORD launchPid{};
    HANDLE game{};FpsCapture capture;bool showOverlay=false;LONG lastOptions{};ULONGLONG optionsAt{},lastLog{};
    NOTIFYICONDATAW trayData{};bool trayReady=false,exitRequested=false,startHidden=false;
    std::unique_ptr<omfg::driver::Controller> driver;std::optional<omfg::driver::Snapshot> profile;fs::path backup;
    std::wstring targetExe=L"FlightSimulator2024.exe",fpsLabel=L"FPS (PresentMon): waiting",errorText;
    ~App(){if(game)CloseHandle(game);if(launchGame)CloseHandle(launchGame);}
    fs::path directory,helper,logPath;std::ofstream log;LONG previousStatus=-1,previousApplied=-1;
    bool AddTray(){
        if(trayReady)return true;
        trayData={};trayData.cbSize=sizeof(trayData);trayData.hWnd=window;trayData.uID=OptiMfgTrayIconId;
        trayData.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;trayData.uCallbackMessage=OptiMfgTrayMessage;
        trayData.hIcon=LoadIconW(nullptr,IDI_APPLICATION);wcscpy_s(trayData.szTip,L"OptiMFG — waiting for a game");
        trayReady=Shell_NotifyIconW(NIM_ADD,&trayData)!=FALSE;
        if(trayReady){trayData.uVersion=NOTIFYICON_VERSION_4;Shell_NotifyIconW(NIM_SETVERSION,&trayData);Log("tray_icon_added");}
        return trayReady;
    }
    void RemoveTray(){if(trayReady){Shell_NotifyIconW(NIM_DELETE,&trayData);trayReady=false;Log("tray_icon_removed");}}
    void ShowMain(){if(IsIconic(window)||!IsWindowVisible(window))ShowWindow(window,SW_RESTORE);ShowWindow(window,SW_SHOW);SetForegroundWindow(window);}
    void HideToTray(){if(!AddTray())throw std::runtime_error("Windows could not create the OptiMFG tray icon");ShowWindow(window,SW_HIDE);Log("window_hidden_to_tray");}
    void Exit(){exitRequested=true;RemoveTray();DestroyWindow(window);}
    void ShowTrayMenu(){POINT p{};GetCursorPos(&p);HMENU menu=CreatePopupMenu();
        AppendMenuW(menu,MF_STRING,OptiMfgTrayShow,L"Open desktop backup controls");
        
        AppendMenuW(menu,MF_STRING,OptiMfgTrayExport,L"Send diagnostics report...");AppendMenuW(menu,MF_SEPARATOR,0,nullptr);
        AppendMenuW(menu,MF_STRING,OptiMfgTrayExit,L"Exit OptiMFG");SetForegroundWindow(window);
        UINT command=TrackPopupMenu(menu,TPM_RETURNCMD|TPM_NONOTIFY|TPM_RIGHTBUTTON,p.x,p.y,0,window,nullptr);DestroyMenu(menu);
        if(command)PostMessageW(window,WM_COMMAND,command,0);
    }
    void Text(std::wstring const& text){SetWindowTextW(status,text.c_str());}
    void Log(char const* event,std::string const& detail=""){
        log<<"{\"event\":\""<<event<<"\",\"tick_ms\":"<<GetTickCount64()<<",\"pid\":"<<pid;
        DWORD foregroundPid{};GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);log<<",\"foreground_pid\":"<<foregroundPid;
        log<<",\"detail\":"<<omfg::driver::Json(detail)<<",\"presentation_fps\":"<<capture.fps;
        if(channel.shared){auto& s=*channel.shared;log<<",\"status\":"<<Read(s.status)<<",\"requested_multiplier\":"<<Read(s.request)<<",\"request_sequence\":"<<Read(s.commandSequence)<<",\"applied_sequence\":"<<Read(s.appliedSequence)<<",\"option_calls\":"<<Read(s.optionCalls)<<",\"state_calls\":"<<Read(s.stateCalls)<<",\"maximum_generated\":"<<Read(s.maximum)<<",\"effective_mode\":"<<Read(s.effectiveMode)<<",\"effective_generated\":"<<Read(s.effectiveCount)<<",\"runtime_status\":"<<Read(s.runtimeStatus)<<",\"presented_count_from_game_query\":"<<Read(s.presented);}
        if(backport.pid)log<<",\"backend\":\"OptiMFG RTX backend\",\"backend_fresh\":"<<(backport.fresh?"true":"false")<<",\"backend_requested\":"<<backport.requested<<",\"backend_snapshot\":"<<backport.snapshot.dump();
        log<<"}\n";log.flush();
    }
    void Refresh(){processes=Processes();SendMessageW(list,CB_RESETCONTENT,0,0);for(auto const& p:processes){auto text=p.name+L" (PID "+std::to_wstring(p.pid)+L")";SendMessageW(list,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(text.c_str()));}SendMessageW(list,CB_SETCURSEL,0,0);if(!channel.shared)Text(processes.empty()?L"Start MSFS and click Refresh.":L"Select MSFS and click Attach observer. No override is enabled by attaching.");}
    void CheckDriver(){profile.reset();try{if(!driver)driver=std::make_unique<omfg::driver::Controller>(directory/L"backups",[this](auto const& event,auto const& fields){log<<"{\"event\":"<<omfg::driver::Json(event)<<fields<<"}\n";log.flush();});
        profile=driver->Read(targetExe);auto value=profile->values[0].value;
        std::wstring message=driver->Hardware()+L"\r\n"+(value==1?L"BLOCKER: NVIDIA profile forces FG OFF. Close the game, then use Application controlled.":value==0?L"Driver profile: application controlled.":L"Driver profile has an FG override. It may take priority over live requests.");SetWindowTextW(driverText,message.c_str());
        }catch(std::exception const& e){Log("driver_check_failed",e.what());SetWindowTextW(driverText,omfg::driver::Wide(e.what()).c_str());}}
    void FixDriver(){if(!profile)throw std::runtime_error("Check the driver profile first");backup=driver->Apply(targetExe,omfg::driver::Mode::Application,*profile);CheckDriver();Log("application_control_set",backup.string());errorText=L"Profile saved and verified. Restart the game. Backup saved for Undo.";}
    void UndoDriver(){if(backup.empty())throw std::runtime_error("No profile change to undo in this session");driver->Restore(targetExe,backup);backup.clear();CheckDriver();}
    void Connect(){auto n=SendMessageW(list,CB_GETCURSEL,0,0);if(n<0||static_cast<size_t>(n)>=processes.size())throw std::runtime_error("Select a running simulator");
        auto route=Backport::DetectRoute(Backport::ProcessFolder(processes[n].pid));
        if(route!=ProviderRoute::Native){ConnectBackport();return;}
        if(Backport::HasModule(processes[n].pid,L"RTX40MFGCore.dll"))throw std::runtime_error("Older-card backend remains loaded. Restart the game before attaching native control");
        if(backport.pid){if(backport.ownsRequest)backport.Request(-1);backport.Close();}backport.folder.clear();if(channel.shared)Command(*channel.shared,-1);channel.Close();capture.Stop();if(game){CloseHandle(game);game=nullptr;}listedMaximum=-1;pid=processes[n].pid;targetExe=processes[n].name;CheckDriver();Attach(pid,helper);if(!channel.Open(pid))throw std::runtime_error("Cannot connect to helper");
        game=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!game){channel.Close();throw std::runtime_error("Cannot monitor game process");}
        Command(*channel.shared,-1);optionsAt=GetTickCount64();lastOptions=Read(channel.shared->optionCalls);Log("observer_connected");
        try{capture.Start(pid,helper.parent_path()/L"PresentMon.exe",directory/(L"fps-"+std::to_wstring(GetCurrentProcessId())+L".log"));}catch(std::exception const& e){capture.error=e.what();Log("fps_start_failed",e.what());}}
    void ConnectBackport(){
        auto n=SendMessageW(list,CB_GETCURSEL,0,0);if(n<0||static_cast<size_t>(n)>=processes.size())throw std::runtime_error("Select a running simulator");
        if(channel.shared)throw std::runtime_error("Restart game without the native helper before using experimental mode");
        if(backport.ownsRequest)backport.Request(-1);backport.Close();capture.Stop();if(game){CloseHandle(game);game=nullptr;}
        backport.Open(processes[n].pid);pid=processes[n].pid;targetExe=processes[n].name;
        game=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!game){backport.Close();throw std::runtime_error("Cannot monitor game");}
        listedMaximum=-1;CheckDriver();Log("backend_connected");
        try{capture.Start(pid,helper.parent_path()/L"PresentMon.exe",directory/(L"fps-"+std::to_wstring(GetCurrentProcessId())+L".log"));}catch(std::exception const& e){capture.error=e.what();Log("fps_start_failed",e.what());}
    }
    LONG BackportIndexForRequest(int value)const{
        try{return static_cast<LONG>(ModeIndexForRequest(value,backportSupportsOff));}
        catch(std::exception const&){throw std::runtime_error(value==0?"This provider/GPU uses the game's frame-generation setting for Off":"Invalid in-game OptiMFG multiplier request");}
    }
    int BackportRequestForIndex(LONG index)const{
        try{return RequestForModeIndex(static_cast<int>(index),backportSupportsOff);}
        catch(std::exception const&){throw std::runtime_error("Selected OptiMFG multiplier is unavailable for this provider/GPU");}
    }
    void TickBackport(){
        try{backport.Poll();backportError.clear();}catch(std::exception const& e){backportError=e.what();}
        if(!backport.fresh){Text(L"Experimental backend waiting: "+omfg::driver::Wide(backportError));if(GetTickCount64()-lastLog>2000){Log("backend_status_unavailable",backportError);lastLog=GetTickCount64();}return;}
        auto const& b=backport.snapshot;auto maximum=b.at("safeMaximumMultiplier").get<int>();auto family=b.value("gpuFamily",0);
        backportSupportsOff=!backport.headless&&(family==2||family==4);
        if(listedMaximum!=maximum||listedFamily!=family||listedSupportsOff!=backportSupportsOff){SendMessageW(mode,CB_RESETCONTENT,0,0);
            SendMessageW(mode,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(L"Game controlled / release override"));
            if(backportSupportsOff)SendMessageW(mode,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(L"FG off"));
            for(int n=2;n<=maximum;++n){auto label=std::to_wstring(n)+L"x";SendMessageW(mode,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label.c_str()));}
            auto count=maximum-(backportSupportsOff?0:1);int selected=0;try{selected=ModeIndexForRequest(backport.requested,backportSupportsOff);}catch(...){}SendMessageW(mode,CB_SETCURSEL,selected>=0&&selected<=count?selected:0,0);listedMaximum=maximum;listedFamily=family;listedSupportsOff=backportSupportsOff;}
        std::wstringstream t;t<<L"EXPERIMENTAL — OptiMFG RTX backend | GPU family "<<b.value("gpuFamily",0)<<L" (0=unreported, 1=RTX40, 2=RTX30, 4=RTX20, 5=RTX50)\r\n";
        t<<L"Reported ceiling "<<maximum<<L"x (requires ready bridge) | OptiMFG request: "<<backport.requested<<L" (-1=game, 0=off)\r\n";
        t<<L"API-accepted multiplier: "<<b.value("appliedMultiplier",0)<<L" | Frames since last provider query: "<<b.value("actualFramesPresented",0)<<L"\r\n";
        t<<L"Bridge ready: "<<b.at("bridgeReady").get<bool>()<<L" | API accepted: "<<b.at("setOptionsAccepted").get<bool>()<<L" | Pending: "<<b.at("pending").get<bool>()<<L"\r\n";
        t<<L"Provider failure: "<<omfg::driver::Wide(b.value("universalRouteFailureReason",std::string{}))<<L" | Kernel failure: "<<b.value("ampereFailure",0)<<L"\r\n";
        t<<L"Provider state is separate from measured FPS. RTX 20/30/40 validation pending.\r\n";
        t<<L"Requests wait for the game's next settings call. Acceptance does not verify smooth output.\r\n"<<errorText;Text(t.str());
        if(GetTickCount64()-lastLog>2000){Log("backend_status");lastLog=GetTickCount64();}
    }
    void Release(){if(backport.pid){backport.Request(-1);Log("backend_release_requested");}if(channel.shared){Command(*channel.shared,-1);Log("release_requested");}}
    void UpdateModes(){if(!channel.shared)return;auto& s=*channel.shared;auto maximum=Read(s.maximum);if(maximum<1||maximum==listedMaximum)return;listedMaximum=maximum;
        auto selected=SendMessageW(mode,CB_GETCURSEL,0,0);SendMessageW(mode,CB_RESETCONTENT,0,0);
        for(auto label:{L"Game controlled / release override",L"FG off"})SendMessageW(mode,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label));
        LONG total=std::min<LONG>(6,maximum+1);for(LONG n=2;n<=total;++n){auto label=std::to_wstring(n)+L"x";SendMessageW(mode,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label.c_str()));}
        if(selected>total){auto request=Read(s.request);selected=request==-1?0:request==0?1:request;}
        SendMessageW(mode,CB_SETCURSEL,selected>=0&&selected<=total?selected:0,0);}
    void Request(){if(backport.pid){LONG index=static_cast<LONG>(SendMessageW(mode,CB_GETCURSEL,0,0));if(index<0)throw std::runtime_error("Select a multiplier");backport.Request(BackportRequestForIndex(index));Log("backend_request_written");return;}if(!channel.shared)throw std::runtime_error("Attach the observer first");auto& s=*channel.shared;
        LONG index=static_cast<LONG>(SendMessageW(mode,CB_GETCURSEL,0,0));LONG request=index==0?-1:index==1?0:index;
        if(request==-1){Release();return;}if(!Read(s.optionCalls)||GetTickCount64()-optionsAt>3000)throw std::runtime_error("Waiting for fresh game options; enter a flight first");
        if(request>1&&request-1>Read(s.maximum))throw std::runtime_error("Requested multiplier exceeds this runtime's reported capability");
        if(request>1&&profile&&profile->values[0].value==1)throw std::runtime_error("NVIDIA profile forces FG Off. Close the game and select Application controlled first");
        wchar_t value[32]{};GetWindowTextW(viewportEdit,value,32);wchar_t* end{};auto vp=wcstoul(value,&end,10);if(!*value||*end||vp>0x7fffffffUL)throw std::runtime_error("Enter a valid viewport number");
        if(static_cast<LONG>(vp)!=Read(s.viewport))throw std::runtime_error("Selected viewport does not match the currently observed game viewport");
        Write(s.selectedViewport,static_cast<LONG>(vp));Command(s,request);Log("request_sent");}
    void BindHotkey(){UnregisterHotKey(window,1);auto n=SendMessageW(hotkey,CB_GETCURSEL,0,0);if(!RegisterHotKey(window,1,MOD_CONTROL|MOD_ALT|MOD_NOREPEAT,VK_F8+static_cast<UINT>(n)))throw std::runtime_error("Hotkey is in use; choose a different key");WritePrivateProfileStringW(L"Overlay",L"HotkeyIndex",std::to_wstring(n).c_str(),(directory/L"settings.ini").c_str());}
    void ToggleOverlay(){showOverlay=!showOverlay;Log(showOverlay?"overlay_enabled":"overlay_disabled");}
    void OpenDiagnostics(){auto dest=directory;fs::create_directories(dest);
        // Drop the interactive panel's topmost state before opening Explorer.
        if(panelOpen)ClosePanel();
        auto result=reinterpret_cast<INT_PTR>(ShellExecuteW(window,L"open",dest.c_str(),nullptr,nullptr,SW_SHOWNORMAL));
        if(result<=32)throw std::runtime_error("Cannot open diagnostics folder (ShellExecute error "+std::to_string(result)+")");
        Log("diagnostics_folder_opened");}
    void ReturnToGame(){
        if(!pid)return;
        struct Find{DWORD pid;HWND window;};Find found{pid,nullptr};
        EnumWindows([](HWND h,LPARAM value)->BOOL{auto& f=*reinterpret_cast<Find*>(value);DWORD p{};GetWindowThreadProcessId(h,&p);if(p==f.pid&&IsWindowVisible(h)&&!GetWindow(h,GW_OWNER)){f.window=h;return FALSE;}return TRUE;},reinterpret_cast<LPARAM>(&found));
        if(!found.window){Log("return_to_game_failed","No visible game window");return;}
        returnWindow=found.window;if(panelOpen)ClosePanel();else ShowWindow(window,SW_MINIMIZE);
        if(IsIconic(found.window))ShowWindow(found.window,SW_RESTORE);
        SetForegroundWindow(found.window);DWORD foreground{};GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
        Log(foreground==pid?"returned_to_game":"return_to_game_failed",foreground==pid?"":"Windows did not grant foreground focus; switch to the game manually");
    }
    void BindPanelKey(){auto n=SendMessageW(panelKey,CB_GETCURSEL,0,0);UINT keys[]={VK_F6,VK_F7,VK_F11};if(n<0||n>2)throw std::runtime_error("Select a control-panel shortcut");
        UnregisterHotKey(window,2);if(!RegisterHotKey(window,2,MOD_CONTROL|MOD_ALT|MOD_NOREPEAT,keys[n])){
            Log("panel_hotkey_conflict",std::to_string(keys[n]));bool bound=false;
            for(int fallback=0;fallback<3;++fallback){if(fallback==n)continue;if(RegisterHotKey(window,2,MOD_CONTROL|MOD_ALT|MOD_NOREPEAT,keys[fallback])){n=fallback;bound=true;SendMessageW(panelKey,CB_SETCURSEL,n,0);break;}}
            if(!bound)throw std::runtime_error("All control-panel shortcuts are in use. Use Open control overlay in the app.");
        }
        Log("panel_hotkey_registered",std::to_string(keys[n]));
        WritePrivateProfileStringW(L"Overlay",L"PanelHotkeyIndex",std::to_wstring(n).c_str(),(directory/L"settings.ini").c_str());}
    void ClosePanel(){if(!panelOpen)return;panelOpen=false;ShowWindow(returnButton,SW_HIDE);
        SetWindowLongPtrW(window,GWL_STYLE,desktopStyle);SetWindowLongPtrW(window,GWL_EXSTYLE,desktopExStyle);
        SetWindowPos(window,HWND_NOTOPMOST,desktopRect.left,desktopRect.top,desktopRect.right-desktopRect.left,desktopRect.bottom-desktopRect.top,SWP_FRAMECHANGED|SWP_NOACTIVATE);
        ShowWindow(window,SW_MINIMIZE);if(IsWindow(returnWindow))SetForegroundWindow(returnWindow);Log("control_panel_closed");}
    void TogglePanel(){if(panelOpen){ClosePanel();return;}
        auto foreground=GetForegroundWindow();DWORD foregroundPid{};GetWindowThreadProcessId(foreground,&foregroundPid);
        if(foregroundPid!=GetCurrentProcessId()){returnWindow=foreground;}else{
            struct Find{DWORD pid;HWND window;};Find find{pid,nullptr};
            if(!find.pid){auto games=Processes();if(games.size()==1)find.pid=games[0].pid;}
            EnumWindows([](HWND h,LPARAM value)->BOOL{auto& f=*reinterpret_cast<Find*>(value);DWORD p{};GetWindowThreadProcessId(h,&p);if(p==f.pid&&IsWindowVisible(h)&&!GetWindow(h,GW_OWNER)){f.window=h;return FALSE;}return TRUE;},reinterpret_cast<LPARAM>(&find));returnWindow=find.window;
        }
        if(IsIconic(window))ShowWindow(window,SW_RESTORE);GetWindowRect(window,&desktopRect);desktopStyle=GetWindowLongPtrW(window,GWL_STYLE);desktopExStyle=GetWindowLongPtrW(window,GWL_EXSTYLE);
        MONITORINFO mi{sizeof(mi)};GetMonitorInfoW(MonitorFromWindow(returnWindow?returnWindow:foreground,MONITOR_DEFAULTTONEAREST),&mi);
        int width=desktopRect.right-desktopRect.left,height=desktopRect.bottom-desktopRect.top;
        panelOpen=true;SetWindowLongPtrW(window,GWL_STYLE,WS_POPUP|WS_BORDER|WS_CLIPCHILDREN);SetWindowLongPtrW(window,GWL_EXSTYLE,desktopExStyle|WS_EX_TOPMOST);
        SetWindowPos(window,HWND_TOPMOST,mi.rcWork.left+std::max<LONG>(0,(mi.rcWork.right-mi.rcWork.left-width)/2),mi.rcWork.top+std::max<LONG>(0,(mi.rcWork.bottom-mi.rcWork.top-height)/2),width,height,SWP_FRAMECHANGED|SWP_SHOWWINDOW);
        ShowWindow(returnButton,SW_SHOW);SetForegroundWindow(window);SetFocus(mode);Log("control_panel_opened");}
    void AutoConnect(){
        if(connecting||channel.shared||backport.pid)return;
        if(SendMessageW(autoConnect,BM_GETCHECK,0,0)!=BST_CHECKED){autoCandidatePid=0;providerSeenSince=0;return;}
        if(GetTickCount64()<nextAutoScan)return;
        nextAutoScan=GetTickCount64()+2000;
        auto report=[&](std::wstring const& message){if(message!=autoMessage){autoMessage=message;Text(message);Log("auto_connect_wait",omfg::driver::Utf8(message));}};
        try{
            auto found=Processes();if(launchPid)found.erase(std::remove_if(found.begin(),found.end(),[&](auto const& p){return p.pid!=launchPid;}),found.end());if(found.empty()){autoAttemptedPid=0;autoCandidatePid=0;providerSeenSince=0;report(L"Auto-connect: waiting for MSFS...");return;}
            if(found.size()!=1){
                std::vector<uint32_t> qualified;
                for(auto const& candidate:found)if(Backport::HasFreshRenderingStatus(candidate.pid))qualified.push_back(candidate.pid);
                auto selected=UniqueRenderingProcess(qualified);
                if(!selected){autoCandidatePid=0;providerSeenSince=0;report(L"Auto-connect: multiple simulators found; waiting for one verified rendering session or manual selection.");return;}
                auto chosen=*std::find_if(found.begin(),found.end(),[&](auto const& candidate){return candidate.pid==selected;});
                found={chosen};Log("auto_connect_unique_rendering_session",std::to_string(selected));
            }
            auto id=found[0].pid;auto folder=Backport::ProcessFolder(id);
            if(autoAttemptedPid==id)return;
            if(autoCandidatePid!=id){autoCandidatePid=id;providerSeenSince=0;}
            auto route=Backport::DetectRoute(folder);
            if(route!=ProviderRoute::Native){
                if(Backport::HasModule(id,L"OptiMFG_LiveHelper_v4.dll")){autoAttemptedPid=id;report(L"Native OptiMFG helper is already loaded. Close and restart MSFS to use the installed RTX backend.");Log("backend_route_conflict");return;}
                if(!Backport::RouteModuleLoaded(id,route)){auto label=route==ProviderRoute::Headless?L"menu-free RTX provider":L"MFG provider";report(std::wstring(L"Auto-connect: waiting for the installed ")+label+L" to load...");return;}
            }else{
                if(!Backport::HasModule(id,L"sl.interposer.dll")){providerSeenSince=0;report(L"Auto-connect: waiting for the native Streamline provider...");return;}
                if(!providerSeenSince)providerSeenSince=GetTickCount64();
                if(GetTickCount64()-providerSeenSince<5000){report(L"Auto-connect: native provider is loading; waiting for it to settle...");return;}
            }
            if(autoAttemptedPid==id){return;}
            processes=std::move(found);SendMessageW(list,CB_RESETCONTENT,0,0);auto label=processes[0].name+L" (PID "+std::to_wstring(id)+L")";SendMessageW(list,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label.c_str()));SendMessageW(list,CB_SETCURSEL,0,0);
            connecting=true;
            try{Connect();connecting=false;autoAttemptedPid=id;autoMessage.clear();errorText.clear();Log(route==ProviderRoute::Native?"auto_connected_native":"auto_connected_backend");}
            catch(std::exception const& e){connecting=false;if(omfg::live::RetryAutoConnect(e.what())){autoAttemptedPid=0;nextAutoScan=GetTickCount64()+2000;Log("auto_connect_retry",e.what());}else autoAttemptedPid=id;throw;}
        }catch(std::exception const& e){report(L"Auto-connect waiting: "+omfg::driver::Wide(e.what()));}
    }
    void Tick(){if(launchGame&&WaitForSingleObject(launchGame,0)==WAIT_OBJECT_0){Log("launch_game_exited");Exit();return;}AutoConnect();capture.Poll();if(capture.error!=lastFpsError){lastFpsError=capture.error;if(!lastFpsError.empty())Log("fps_capture_failed",lastFpsError);}if(zipTask.valid()&&zipTask.wait_for(std::chrono::seconds(0))==std::future_status::ready){try{zipTask.get();errorText=L"Ready to send: "+zipPath.wstring();Text(errorText);Log("diagnostics_zip_created",zipPath.string());if(openExportFolder&&!panelOpen)ShellExecuteW(window,L"open",zipPath.parent_path().c_str(),nullptr,nullptr,SW_SHOWNORMAL);}catch(std::exception const& e){errorText=L"ZIP failed; saved diagnostics folder remains available. "+omfg::driver::Wide(e.what());Text(errorText);Log("diagnostics_zip_failed",e.what());}}
        if(game&&WaitForSingleObject(game,0)==WAIT_OBJECT_0){Log("game_exited");try{Release();}catch(std::exception const& e){Log("release_failed_after_game_exit",e.what());}controller.Close();backport.Close();channel.Close();capture.Stop();CloseHandle(game);game=nullptr;
            Log("controller_autostop_after_game_exit");Exit();return;}
        bool fresh=channel.shared&&GetTickCount64()-optionsAt<3000;
        std::wstringstream f;f<<std::fixed<<std::setprecision(0);if(capture.fps>0){f<<L"Application FPS: "<<capture.fps;
            if(backport.pid&&backport.fresh)f<<L"  |  Backend frames: "<<backport.snapshot.value("actualFramesPresented",0);else if(fresh&&Read(channel.shared->presented)>0)f<<L"  |  Runtime frames: "<<Read(channel.shared->presented);else f<<L"  |  Runtime frames: unavailable";
        }else f<<L"Application FPS: waiting / unavailable";
        if(!capture.error.empty())f<<L"\r\n"<<omfg::driver::Wide(capture.error);fpsLabel=f.str();SetWindowTextW(fpsText,fpsLabel.c_str());
        DWORD foreground{};GetWindowThreadProcessId(GetForegroundWindow(),&foreground);bool visible=showOverlay&&game&&(foreground==pid||foreground==GetCurrentProcessId());
        if(visible){MONITORINFO mi{sizeof(mi)};GetMonitorInfoW(MonitorFromWindow(GetForegroundWindow(),MONITOR_DEFAULTTONEAREST),&mi);SetWindowPos(overlay,HWND_TOPMOST,mi.rcMonitor.left+24,mi.rcMonitor.top+24,520,94,SWP_NOACTIVATE|SWP_SHOWWINDOW);InvalidateRect(overlay,nullptr,TRUE);}else ShowWindow(overlay,SW_HIDE);
        if(backport.pid){TickBackport();ServiceController();return;}if(!channel.shared){ServiceController();return;}channel.Heartbeat();UpdateModes();auto& s=*channel.shared;if(Read(s.optionCalls)!=lastOptions){lastOptions=Read(s.optionCalls);optionsAt=GetTickCount64();}
        auto state=Read(s.status),applied=Read(s.appliedSequence),requested=Read(s.commandSequence);
        std::wstringstream text;text<<L"Native Streamline control | PID "<<pid<<L" | "<<StatusText(state)<<L"\r\n";
        if(applied!=requested)text<<L"Request pending / not accepted. ";
        text<<L"Supported total multiplier: up to "<<Read(s.maximum)+1<<L"x | Active controller request: "<<Read(s.request)<<L" (-1=game, 0=off)\r\n";text<<L"Options calls: "<<Read(s.optionCalls)<<L" | State calls: "<<Read(s.stateCalls)<<L"\r\nRuntime max generated: "<<Read(s.maximum)<<L" | Effective generated request: "<<Read(s.effectiveCount)<<L"\r\nGame mode: "<<Read(s.originalMode)<<L" | Runtime status: "<<Read(s.runtimeStatus)<<L" | Last API result: "<<Read(s.lastResult)<<L"\r\nViewport: "<<Read(s.viewport)<<L" | Options ABI: "<<Read(s.optionsVersion)<<L" | Callback thread: "<<Read(s.callbackThread)<<L"\r\nDisplayed FPS and actual multiplier are not measured by this panel.";
        text<<L"\r\nRuntime presented count: "<<Read(s.presented)<<L" | Successful queries: "<<Read(s.validStates)<<L" | Failed queries: "<<Read(s.failedStates);
        if(GetTickCount64()-optionsAt>3000)text<<L"\r\nWaiting for fresh game activity; displayed runtime values may be stale.";
        if(!errorText.empty())text<<L"\r\n"<<errorText;
        Text(text.str());ServiceController();if(state!=previousStatus||applied!=previousApplied||GetTickCount64()-lastLog>2000){Log("status_changed");previousStatus=state;previousApplied=applied;lastLog=GetTickCount64();}}
    // Diagnostics go through the OptiShade Troubleshooter's private upload: game,
    // OptiShade and OptiMFG logs in one report with a report ID. This app no
    // longer writes its own ZIP, which carried no game logs (owner, 1 Nov 2026).
    void Export(){Log("report_requested");if(panelOpen)ClosePanel();wchar_t self[32768]{};const DWORD n=GetModuleFileNameW(nullptr,self,static_cast<DWORD>(std::size(self)));if(!n||n>=std::size(self))throw std::runtime_error("Cannot locate OptiMFG");const auto gameRoot=fs::path(self).parent_path().parent_path().parent_path().parent_path();const auto tool=gameRoot/L"OptiShadeData"/L"Tools"/L"OptiShade-Troubleshooter.exe";if(!fs::exists(tool))throw std::runtime_error("OptiShade Troubleshooter not found next to this game. Open it from the OptiShade manager to send a report.");const std::wstring args=L"--game \""+gameRoot.wstring()+L"\" --mfg";auto result=reinterpret_cast<INT_PTR>(ShellExecuteW(window,L"open",tool.c_str(),args.c_str(),tool.parent_path().c_str(),SW_SHOWNORMAL));if(result<=32)throw std::runtime_error("Cannot open the OptiShade Troubleshooter (ShellExecute error "+std::to_string(result)+")");errorText=L"OptiShade Troubleshooter opened. Describe what happened and press Collect and send report.";Text(errorText);}
};
#include "DesktopUi.inl"
static App* app{};
static LRESULT CALLBACK OverlayProc(HWND w,UINT msg,WPARAM wp,LPARAM lp){
    if(msg==WM_NCHITTEST)return HTTRANSPARENT;
    if(msg==WM_PAINT){PAINTSTRUCT ps;auto dc=BeginPaint(w,&ps);RECT r;GetClientRect(w,&r);FillRect(dc,&r,reinterpret_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(100,255,160));auto font=CreateFontW(20,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");auto old=SelectObject(dc,font);r.left+=12;r.top+=10;auto text=L"OptiMFG\r\n"+app->fpsLabel;DrawTextW(dc,text.c_str(),-1,&r,DT_LEFT|DT_NOPREFIX);SelectObject(dc,old);DeleteObject(font);EndPaint(w,&ps);return 0;}return DefWindowProcW(w,msg,wp,lp);
}
static LRESULT CALLBACK Proc(HWND w,UINT msg,WPARAM wp,LPARAM lp){try{
    if(desktopReady&&ImGui_ImplWin32_WndProcHandler(w,msg,wp,lp))return 1;
    if(msg==WM_CTLCOLORSTATIC||msg==WM_CTLCOLORBTN){auto dc=reinterpret_cast<HDC>(wp);SetTextColor(dc,RGB(229,218,245));SetBkMode(dc,TRANSPARENT);return reinterpret_cast<LRESULT>(OptiMfgBackgroundBrush);}
    if(msg==WM_CTLCOLOREDIT||msg==WM_CTLCOLORLISTBOX){auto dc=reinterpret_cast<HDC>(wp);SetTextColor(dc,RGB(239,232,250));SetBkColor(dc,RGB(34,28,45));return reinterpret_cast<LRESULT>(OptiMfgSurfaceBrush);}
    if(msg==WM_DRAWITEM){auto item=reinterpret_cast<DRAWITEMSTRUCT*>(lp);if(item&&item->CtlType==ODT_BUTTON){const bool disabled=(item->itemState&ODS_DISABLED)!=0;const bool selected=(item->itemState&ODS_SELECTED)!=0;const bool primary=item->CtlID==3||item->CtlID==5||item->CtlID==13;const COLORREF fill=disabled?RGB(47,40,59):primary?RGB(125,57,214):selected?RGB(82,54,112):RGB(43,35,56);const COLORREF edge=primary?RGB(177,129,239):RGB(105,78,134);HBRUSH brush=CreateSolidBrush(fill);FillRect(item->hDC,&item->rcItem,brush);DeleteObject(brush);HPEN pen=CreatePen(PS_SOLID,1,edge);auto oldPen=SelectObject(item->hDC,pen);auto oldBrush=SelectObject(item->hDC,GetStockObject(HOLLOW_BRUSH));RoundRect(item->hDC,item->rcItem.left+1,item->rcItem.top+1,item->rcItem.right-1,item->rcItem.bottom-1,8,8);SelectObject(item->hDC,oldBrush);SelectObject(item->hDC,oldPen);DeleteObject(pen);wchar_t label[256]{};GetWindowTextW(item->hwndItem,label,ARRAYSIZE(label));SetBkMode(item->hDC,TRANSPARENT);SetTextColor(item->hDC,disabled?RGB(143,132,159):RGB(248,242,255));DrawTextW(item->hDC,label,-1,&item->rcItem,DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);return TRUE;}}
    if(msg==WM_COMMAND){auto command=LOWORD(wp);app->errorText.clear();switch(command){case 1:app->Refresh();break;case 2:app->Connect();break;case 3:app->Request();app->ReturnToGame();break;case 4:app->Release();break;case 5:app->Export();break;case 6:app->CheckDriver();break;case 7:app->FixDriver();break;case 8:app->UndoDriver();break;case 9:app->ToggleOverlay();break;case 10:app->BindHotkey();break;case 13:app->ClosePanel();break;case 14:app->OpenDiagnostics();break;case 15:app->ConnectBackport();break;case 16:app->nextAutoScan=0;app->autoAttemptedPid=0;app->autoMessage.clear();WritePrivateProfileStringW(L"Connection",L"Automatic",SendMessageW(app->autoConnect,BM_GETCHECK,0,0)==BST_CHECKED?L"1":L"0",(app->directory/L"settings.ini").c_str());break;case OptiMfgTrayShow:app->ShowMain();break;case OptiMfgTrayExport:app->Export();break;case OptiMfgTrayExit:app->Exit();break;}return 0;}
    if(msg==OptiMfgTrayMessage){
        // NOTIFYICON_VERSION_4 packs the event in LOWORD(lParam) and the
        // icon identifier/coordinates in the remaining bits. Comparing the
        // complete lParam made right-click appear to do nothing.
        const auto event=LOWORD(lp);
        if(event==WM_LBUTTONDBLCLK||event==NIN_SELECT||event==NIN_KEYSELECT)app->ShowMain();
        else if(event==WM_RBUTTONUP||event==WM_CONTEXTMENU)app->ShowTrayMenu();
        return 0;
    }
    if(msg==WM_HOTKEY){app->Log("hotkey_received",std::to_string(wp));if(wp==1)app->ToggleOverlay();return 0;}
    if(msg==WM_CLOSE){if(app->panelOpen){app->ClosePanel();return 0;}app->HideToTray();return 0;}
    if(msg==WM_TIMER){if(wp==1)app->Tick();else DrawDesktop(*app);return 0;}
    if(msg==WM_DESTROY){try{if(app->channel.shared||app->backport.ownsRequest)app->Release();}catch(std::exception const& e){app->Log("release_failed_on_close",e.what());}app->capture.Stop();UnregisterHotKey(w,1);UnregisterHotKey(w,2);DestroyWindow(app->overlay);app->RemoveTray();app->Log("controller_closed");PostQuitMessage(0);return 0;}
}catch(std::exception const& e){app->errorText=omfg::driver::Wide(e.what());app->Text(app->errorText);app->Log("operation_failed",e.what());}return DefWindowProcW(w,msg,wp,lp);}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR commandLine,int show){
    int brokerArgc{};auto brokerArgv=CommandLineToArgvW(GetCommandLineW(),&brokerArgc);
    if(brokerArgv&&brokerArgc>1&&!wcscmp(brokerArgv[1],L"--fps-broker")){auto result=RunFpsBroker(brokerArgc,brokerArgv);LocalFree(brokerArgv);return result;}if(brokerArgv)LocalFree(brokerArgv);
    HANDLE singleton=CreateMutexW(nullptr,FALSE,L"Local\\OptiMFG.Controller.Instance.v1");
    if(!singleton)return 1;
    if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(singleton);if(!(commandLine&&wcsstr(commandLine,L"--tray")))MessageBoxW(nullptr,L"OptiMFG is already running. Open it from the system tray.",L"OptiMFG",MB_OK);return 0;}
    App a;app=&a;try{
        wchar_t local[32768]{},exe[32768]{};GetEnvironmentVariableW(L"LOCALAPPDATA",local,ARRAYSIZE(local));GetModuleFileNameW(nullptr,exe,ARRAYSIZE(exe));
        a.directory=fs::path(local)/L"OptiMFG"/L"runtime";fs::create_directories(a.directory);a.helper=fs::path(exe).parent_path()/L"OptiMFG_LiveHelper_v4.dll";
        a.logPath=a.directory/(L"controller-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64())+L".jsonl");a.log.open(a.logPath);
        // Bind automatic launches to the exact originating game lifetime, even
        // if graphics initialization/attachment never completes.
        int argc{};auto argv=CommandLineToArgvW(GetCommandLineW(),&argc);
        std::wstring pidArg,birthArg;
        if(argv){for(int i=1;i<argc;++i){if(wcscmp(argv[i],L"--game-pid")==0&&i+1<argc)pidArg=argv[++i];else if(wcscmp(argv[i],L"--game-birth")==0&&i+1<argc)birthArg=argv[++i];}LocalFree(argv);}
        if(!pidArg.empty()||!birthArg.empty()){
            size_t used{};auto id=std::stoull(pidArg,&used);if(used!=pidArg.size()||!id||id>MAXDWORD)throw std::runtime_error("Invalid launch game PID");
            auto birth=std::stoull(birthArg,&used);if(used!=birthArg.size()||!birth)throw std::runtime_error("Invalid launch game birth");
            a.launchPid=static_cast<DWORD>(id);a.launchGame=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,a.launchPid);
            FILETIME created{},exited{},kernel{},user{};
            if(!a.launchGame||!GetProcessTimes(a.launchGame,&created,&exited,&kernel,&user)||((uint64_t(created.dwHighDateTime)<<32)|created.dwLowDateTime)!=birth||WaitForSingleObject(a.launchGame,0)!=WAIT_TIMEOUT){a.Log("launch_game_unavailable");CloseHandle(singleton);return 0;}
            a.Log("launch_game_bound",std::to_string(a.launchPid));
        }
        OptiMfgBackgroundBrush=CreateSolidBrush(RGB(21,18,29));OptiMfgSurfaceBrush=CreateSolidBrush(RGB(34,28,45));
        WNDCLASSW wc{};wc.hInstance=instance;wc.lpfnWndProc=Proc;wc.lpszClassName=L"OptiMFGLive";wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hbrBackground=OptiMfgBackgroundBrush;RegisterClassW(&wc);
        a.window=CreateWindowW(wc.lpszClassName,L"OptiMFG | OptiShade",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,960,820,nullptr,nullptr,instance,nullptr);
        WNDCLASSW ow{};ow.hInstance=instance;ow.lpfnWndProc=OverlayProc;ow.lpszClassName=L"OptiMFGOverlay";RegisterClassW(&ow);
        a.overlay=CreateWindowExW(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_TOPMOST|WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE,ow.lpszClassName,L"OptiMFG FPS",WS_POPUP,24,24,520,94,nullptr,nullptr,instance,nullptr);SetLayeredWindowAttributes(a.overlay,0,220,LWA_ALPHA);
        auto add=[&](wchar_t const* cls,wchar_t const* text,DWORD style,int x,int y,int width,int height,int id=0){if(wcscmp(cls,L"BUTTON")==0&&(style&BS_AUTOCHECKBOX)==0)style|=BS_OWNERDRAW;auto h=CreateWindowW(cls,text,WS_CHILD|style|(wcscmp(cls,L"STATIC")?WS_TABSTOP:0),x,y,width,height,a.window,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),instance,nullptr);SendMessageW(h,WM_SETFONT,reinterpret_cast<WPARAM>(GetStockObject(DEFAULT_GUI_FONT)),TRUE);return h;};
        add(L"STATIC",L"OPTIMFG  |  Live frame-generation controls",0,16,16,850,24);
        a.returnButton=add(L"BUTTON",L"Back to game",0,795,4,140,30,13);ShowWindow(a.returnButton,SW_HIDE);
        a.list=add(L"COMBOBOX",L"",CBS_DROPDOWNLIST,16,52,480,180);add(L"BUTTON",L"Refresh",0,510,50,100,30,1);add(L"BUTTON",L"Attach observer",0,625,50,220,30,2);
        a.mode=add(L"COMBOBOX",L"",CBS_DROPDOWNLIST,16,100,360,250);
        for(auto label:{L"Game controlled / release override",L"FG off",L"2x",L"3x",L"4x",L"5x",L"6x"})SendMessageW(a.mode,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label));SendMessageW(a.mode,CB_SETCURSEL,0,0);
        add(L"BUTTON",L"Apply and return to game",0,390,98,190,30,3);add(L"BUTTON",L"Return control to game",0,595,98,250,30,4);
        add(L"STATIC",L"Flight viewport:",0,16,140,100,22);a.viewportEdit=add(L"EDIT",L"0",WS_BORDER|ES_NUMBER,125,137,70,26);
        a.status=add(L"STATIC",L"",0,16,178,910,200);
        a.driverText=add(L"STATIC",L"",0,16,382,910,46);
        add(L"BUTTON",L"Check driver",0,16,435,140,30,6);add(L"BUTTON",L"Application controlled",0,170,435,200,30,7);add(L"BUTTON",L"Undo profile change",0,385,435,180,30,8);
        add(L"STATIC",L"Profile writes require the game to be closed; live multiplier controls do not.",0,16,473,900,24);
        a.fpsText=add(L"STATIC",L"FPS (PresentMon): connect to start capture",0,16,505,910,45);
        add(L"BUTTON",L"Toggle FPS overlay",0,16,558,190,30,9);a.hotkey=add(L"COMBOBOX",L"",CBS_DROPDOWNLIST,220,558,180,150);
        for(auto label:{L"Ctrl + Alt + F8",L"Ctrl + Alt + F9",L"Ctrl + Alt + F10"})SendMessageW(a.hotkey,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label));
        auto key=GetPrivateProfileIntW(L"Overlay",L"HotkeyIndex",2,(a.directory/L"settings.ini").c_str());SendMessageW(a.hotkey,CB_SETCURSEL,key<=2?key:2,0);add(L"BUTTON",L"Set hotkey",0,415,558,130,30,10);
        add(L"STATIC",L"Application FPS excludes generated frames; it is not the multiplied display FPS. Runtime frames are reported separately.\r\nOverlay supports windowed/borderless mode. OptiMFG releases live control and closes automatically when the connected game exits.",0,16,602,910,48);
        add(L"BUTTON",L"Send diagnostics report...",0,16,664,180,32,5);add(L"BUTTON",L"Open log folder",0,210,664,220,32,14);a.autoConnect=add(L"BUTTON",L"Automatically connect when game is ready",BS_AUTOCHECKBOX,445,664,460,32,16);SendMessageW(a.autoConnect,BM_SETCHECK,GetPrivateProfileIntW(L"Connection",L"Automatic",1,(a.directory/L"settings.ini").c_str())?BST_CHECKED:BST_UNCHECKED,0);a.Refresh();a.CheckDriver();try{a.BindHotkey();}catch(std::exception const& e){a.errorText=omfg::driver::Wide(e.what());a.Text(a.errorText);}
        InitDesktop(a.window);SetTimer(a.window,2,16,nullptr);
        a.Log("session_started","OptiMFG external controller IPC v1 integration candidate; helper v4; PresentMon 2.6.0");SetTimer(a.window,1,250,nullptr);a.startHidden=commandLine&&wcsstr(commandLine,L"--tray");
        if(!a.AddTray())throw std::runtime_error("Windows could not create the OptiMFG tray icon");
        ShowWindow(a.window,a.startHidden?SW_HIDE:show);
        MSG m{};while(GetMessageW(&m,nullptr,0,0)>0){if(a.panelOpen&&m.message==WM_KEYDOWN&&m.wParam==VK_ESCAPE){a.ClosePanel();continue;}if(!IsDialogMessageW(a.window,&m)){TranslateMessage(&m);DispatchMessageW(&m);}}ShutdownDesktop();CloseHandle(singleton);return 0;
    }catch(std::exception const& e){auto s=std::string(e.what());MessageBoxW(nullptr,std::wstring(s.begin(),s.end()).c_str(),L"OptiMFG",MB_ICONERROR);CloseHandle(singleton);return 1;}
}






