#pragma once
#include <filesystem>
#include <fstream>
#include <vector>
#include <array>
#include <cstdint>
#include <stdexcept>

// Standard ZIP (stored entries): no shell, scripts, or external archive dependency.
inline void ZipDiagnostics(std::filesystem::path const& folder,std::filesystem::path const& destination){
    struct Entry{std::filesystem::path path;std::string name;uint32_t size{},crc{},offset{};};std::vector<Entry> entries;
    auto crcUpdate=[](uint32_t crc,unsigned char const* data,size_t count){for(size_t i=0;i<count;++i){crc^=data[i];for(int bit=0;bit<8;++bit)crc=(crc>>1)^(0xedb88320u&(0u-(crc&1u)));}return crc;};
    uint64_t total=0;std::array<unsigned char,65536> buffer;
    for(auto const& item:std::filesystem::directory_iterator(folder)){if(!item.is_regular_file())continue;
        auto size=item.file_size();total+=size;if(total>512ull*1024*1024)throw std::runtime_error("Diagnostics exceed the 512 MB ZIP limit; send the saved folder instead");
        auto utf8=item.path().filename().u8string();Entry e{item.path(),std::string(utf8.begin(),utf8.end()),static_cast<uint32_t>(size)};
        if(e.name.size()>65535||entries.size()>=65535)throw std::runtime_error("Too many diagnostic entries");
        std::ifstream in(e.path,std::ios::binary);if(!in)throw std::runtime_error("Cannot read diagnostic file");uint32_t crc=0xffffffffu;uint64_t read=0;
        while(in){in.read(reinterpret_cast<char*>(buffer.data()),buffer.size());auto n=static_cast<size_t>(in.gcount());crc=crcUpdate(crc,buffer.data(),n);read+=n;}
        if(in.bad()||read!=size)throw std::runtime_error("Diagnostic file changed while preparing ZIP");e.crc=~crc;entries.push_back(e);
    }
    auto temp=destination;temp+=L".partial";
    try{std::ofstream out(temp,std::ios::binary|std::ios::trunc);if(!out)throw std::runtime_error("Cannot create diagnostic ZIP");
        auto u16=[&](uint16_t n){char b[2]={static_cast<char>(n),static_cast<char>(n>>8)};out.write(b,2);};
        auto u32=[&](uint32_t n){u16(static_cast<uint16_t>(n));u16(static_cast<uint16_t>(n>>16));};
        for(auto& e:entries){e.offset=static_cast<uint32_t>(out.tellp());u32(0x04034b50);u16(20);u16(0x800);u16(0);u16(0);u16(0x21);u32(e.crc);u32(e.size);u32(e.size);u16(static_cast<uint16_t>(e.name.size()));u16(0);out.write(e.name.data(),e.name.size());
            std::ifstream in(e.path,std::ios::binary);uint64_t copied=0;while(in){in.read(reinterpret_cast<char*>(buffer.data()),buffer.size());auto n=in.gcount();out.write(reinterpret_cast<char*>(buffer.data()),n);copied+=static_cast<uint64_t>(n);}if(in.bad()||copied!=e.size)throw std::runtime_error("Cannot copy diagnostic file into ZIP");}
        auto central=static_cast<uint32_t>(out.tellp());for(auto const& e:entries){u32(0x02014b50);u16(20);u16(20);u16(0x800);u16(0);u16(0);u16(0x21);u32(e.crc);u32(e.size);u32(e.size);u16(static_cast<uint16_t>(e.name.size()));u16(0);u16(0);u16(0);u16(0);u32(0);u32(e.offset);out.write(e.name.data(),e.name.size());}
        auto centralSize=static_cast<uint32_t>(out.tellp())-central;u32(0x06054b50);u16(0);u16(0);u16(static_cast<uint16_t>(entries.size()));u16(static_cast<uint16_t>(entries.size()));u32(centralSize);u32(central);u16(0);out.close();if(!out)throw std::runtime_error("Writing diagnostic ZIP failed");std::filesystem::rename(temp,destination);
    }catch(...){std::error_code ignored;std::filesystem::remove(temp,ignored);throw;}
}
