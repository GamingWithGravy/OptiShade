#include "Client.hpp"
#include <tlhelp32.h>
#include <algorithm>
namespace omfg::live {
struct Handle { HANDLE h{};~Handle(){if(h&&h!=INVALID_HANDLE_VALUE)CloseHandle(h);} };
static void Error(char const* reason){throw std::runtime_error(std::string(reason)+" (Windows "+std::to_string(GetLastError())+")");}
std::vector<Process> Processes(){
    Handle snap{CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0)};std::vector<Process> result;
    PROCESSENTRY32W p{};p.dwSize=sizeof(p);if(Process32FirstW(snap.h,&p))do{
        if(!_wcsicmp(p.szExeFile,L"FlightSimulator2024.exe")||!_wcsicmp(p.szExeFile,L"FlightSimulator.exe"))result.push_back({p.th32ProcessID,p.szExeFile});
    }while(Process32NextW(snap.h,&p));return result;
}
static uintptr_t Module(DWORD pid,std::wstring const& name){
    Handle snap{CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid)};
    MODULEENTRY32W m{};m.dwSize=sizeof(m);if(Module32FirstW(snap.h,&m))do{
        if(!_wcsicmp(m.szModule,name.c_str()))return reinterpret_cast<uintptr_t>(m.modBaseAddr);
    }while(Module32NextW(snap.h,&m));return 0;
}
bool StreamlineLoaded(DWORD pid){return Module(pid,L"sl.interposer.dll")!=0;}
void Attach(DWORD pid,std::filesystem::path helper,bool fixture){
    Channel existing;if(existing.Open(pid)){if(Read(existing.shared->ready)||(!fixture&&Read(existing.shared->status)!=HookError))return;throw std::runtime_error("Helper already present but not ready. Inspect helper log; restart the game before retrying");}
    helper=std::filesystem::absolute(helper);if(!std::filesystem::is_regular_file(helper))throw std::runtime_error("OptiMFG_LiveHelper.dll is missing beside the controller");
    Handle process{OpenProcess(PROCESS_CREATE_THREAD|PROCESS_QUERY_INFORMATION|PROCESS_VM_OPERATION|PROCESS_VM_WRITE|PROCESS_VM_READ,FALSE,pid)};
    if(!process.h)Error("Cannot open simulator for helper attachment");
    wchar_t path[32768]{};DWORD size=ARRAYSIZE(path);if(!QueryFullProcessImageNameW(process.h,0,path,&size))Error("Cannot verify target process");
    auto name=std::filesystem::path(path).filename().wstring();
    if(fixture){if(name!=L"OptiMFG_RuntimeFixture.exe")throw std::runtime_error("Fixture target mismatch");}
    else if(_wcsicmp(name.c_str(),L"FlightSimulator2024.exe")&&_wcsicmp(name.c_str(),L"FlightSimulator.exe"))throw std::runtime_error("Target is not MSFS");
    BOOL wow{};if(!IsWow64Process(process.h,&wow)||wow)throw std::runtime_error("Target must be an x64 process");
    if(!Module(pid,L"sl.interposer.dll"))throw std::runtime_error("Streamline is not loaded yet. Wait for MSFS to initialize");
    if(Module(pid,helper.filename().wstring()))throw std::runtime_error("Helper module already loaded without a usable channel; restart target");
    // Resolve remote LoadLibraryW by the containing system module's RVA, not by assuming ASLR equality.
    auto load=GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"LoadLibraryW");HMODULE owner{};
    if(!load||!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(load),&owner))Error("Cannot resolve system loader");
    wchar_t ownerPath[32768]{};GetModuleFileNameW(owner,ownerPath,ARRAYSIZE(ownerPath));
    auto remoteOwner=Module(pid,std::filesystem::path(ownerPath).filename().wstring());if(!remoteOwner)throw std::runtime_error("Target system loader module missing");
    auto remoteLoad=remoteOwner+(reinterpret_cast<uintptr_t>(load)-reinterpret_cast<uintptr_t>(owner));
    auto text=helper.wstring();SIZE_T bytes=(text.size()+1)*sizeof(wchar_t);
    void* remote=VirtualAllocEx(process.h,nullptr,bytes,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);if(!remote)Error("Cannot allocate helper path");
    if(!WriteProcessMemory(process.h,remote,text.c_str(),bytes,nullptr)){VirtualFreeEx(process.h,remote,0,MEM_RELEASE);Error("Cannot write helper path");}
    Handle loader{CreateRemoteThread(process.h,nullptr,0,reinterpret_cast<LPTHREAD_START_ROUTINE>(remoteLoad),remote,0,nullptr)};
    if(!loader.h){VirtualFreeEx(process.h,remote,0,MEM_RELEASE);Error("Cannot start helper loader");}
    if(WaitForSingleObject(loader.h,15000)!=WAIT_OBJECT_0)throw std::runtime_error("Helper loader timed out; path allocation retained to avoid freeing in-use memory. Restart target before retrying");
    VirtualFreeEx(process.h,remote,0,MEM_RELEASE);
    auto base=Module(pid,helper.filename().wstring());if(!base)throw std::runtime_error("Windows did not load the helper; inspect security/driver compatibility errors");
    HMODULE image=LoadLibraryExW(helper.c_str(),nullptr,DONT_RESOLVE_DLL_REFERENCES);if(!image)Error("Cannot inspect helper export");
    auto start=GetProcAddress(image,"OptiMFGLiveStart");auto rva=reinterpret_cast<uintptr_t>(start)-reinterpret_cast<uintptr_t>(image);FreeLibrary(image);
    if(!start)throw std::runtime_error("Helper start export missing");
    Handle worker{CreateRemoteThread(process.h,nullptr,0,reinterpret_cast<LPTHREAD_START_ROUTINE>(base+rva),nullptr,0,nullptr)};
    if(!worker.h)Error("Cannot initialize runtime observer");
    for(int i=0;i<100;++i){Channel channel;if(channel.Open(pid)){if(Read(channel.shared->ready))return;if(Read(channel.shared->status)==HookError)throw std::runtime_error("Helper initialization failed; export helper log");if(!fixture)return;}Sleep(100);}
    throw std::runtime_error("Observer readiness timed out; restart target before retrying");
}
}

