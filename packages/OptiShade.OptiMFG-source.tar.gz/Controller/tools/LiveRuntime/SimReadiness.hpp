#pragma once
#include <windows.h>
#include <filesystem>
#include <string>
#include "SimReadinessPolicy.hpp"

namespace omfg::live {

// Observes the documented SimConnect "Sim" event so automatic attachment can
// wait until MSFS reports that a flight is running. The simulator's own
// SimConnect DLL is loaded by absolute path; no Microsoft SDK binary is bundled.
class SimReadiness {
    struct Recv { DWORD size, version, id; };
    struct RecvEvent { Recv base; DWORD group, event, data; };
    using DispatchProc = void (CALLBACK*)(Recv const*, DWORD, void*);
    using OpenFn = HRESULT (WINAPI*)(HANDLE*, LPCSTR, HWND, DWORD, HANDLE, DWORD);
    using CloseFn = HRESULT (WINAPI*)(HANDLE);
    using SubscribeFn = HRESULT (WINAPI*)(HANDLE, DWORD, const char*);
    using CallDispatchFn = HRESULT (WINAPI*)(HANDLE, DispatchProc, void*);
    static constexpr DWORD SimEventId = 0x4F534D46;
    static constexpr DWORD RecvEventId = 4;
    HMODULE module_{};
    HANDLE handle_{};
    CloseFn close_{};
    CallDispatchFn callDispatch_{};
    DWORD pid_{};
    bool running_{};
    ULONGLONG runningSince_{};
    std::string error_;
    static void CALLBACK Receive(Recv const* data, DWORD, void* context) {
        auto* self = static_cast<SimReadiness*>(context);
        if (!self || !data || data->id != RecvEventId || data->size < sizeof(RecvEvent)) return;
        auto const* event = reinterpret_cast<RecvEvent const*>(data);
        if (event->event != SimEventId) return;
        const bool running = event->data != 0;
        if (running != self->running_) {
            self->running_ = running;
            self->runningSince_ = running ? GetTickCount64() : 0;
        }
    }
public:
    static constexpr UINT WindowMessage = WM_APP + 0x4D6;
    SimReadiness() = default;
    SimReadiness(SimReadiness const&) = delete;
    SimReadiness& operator=(SimReadiness const&) = delete;
    ~SimReadiness() { Close(); }
    void Close() noexcept {
        if (handle_ && close_) close_(handle_);
        handle_ = nullptr;
        if (module_) FreeLibrary(module_);
        module_ = nullptr; close_ = nullptr; callDispatch_ = nullptr;
        pid_ = 0; running_ = false; runningSince_ = 0;
    }
    bool Start(DWORD pid, std::filesystem::path const& gameFolder, HWND window) {
        if (handle_ && pid_ == pid) return true;
        Close(); error_.clear();
        auto dll = gameFolder / L"SimConnect_internal.dll";
        if (!std::filesystem::is_regular_file(dll)) dll = gameFolder / L"SimConnect.dll";
        if (!std::filesystem::is_regular_file(dll)) { error_ = "The simulator's SimConnect runtime was not found beside the game executable"; return false; }
        module_ = LoadLibraryExW(dll.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
        if (!module_) { error_ = "Could not load the simulator's SimConnect runtime (Windows " + std::to_string(GetLastError()) + ")"; return false; }
        auto open = reinterpret_cast<OpenFn>(GetProcAddress(module_, "SimConnect_Open"));
        close_ = reinterpret_cast<CloseFn>(GetProcAddress(module_, "SimConnect_Close"));
        auto subscribe = reinterpret_cast<SubscribeFn>(GetProcAddress(module_, "SimConnect_SubscribeToSystemEvent"));
        callDispatch_ = reinterpret_cast<CallDispatchFn>(GetProcAddress(module_, "SimConnect_CallDispatch"));
        if (!open || !close_ || !subscribe || !callDispatch_) { error_ = "SimConnect runtime is missing a required public API"; Close(); return false; }
        auto result = open(&handle_, "OptiMFG readiness observer", window, WindowMessage, nullptr, 0);
        if (FAILED(result)) { error_ = "SimConnect could not open a simulator session (HRESULT " + std::to_string(static_cast<unsigned long>(result)) + ")"; Close(); return false; }
        result = subscribe(handle_, SimEventId, "Sim");
        if (FAILED(result)) { error_ = "SimConnect could not subscribe to simulator readiness (HRESULT " + std::to_string(static_cast<unsigned long>(result)) + ")"; Close(); return false; }
        pid_ = pid;
        return true;
    }
    void Pump() noexcept { if (handle_ && callDispatch_) callDispatch_(handle_, Receive, this); }
    bool StableRunning(ULONGLONG now, ULONGLONG stableMs = 5000) const noexcept {
        return StableSimulationRunning(running_, runningSince_, now, stableMs);
    }
    DWORD pid() const noexcept { return pid_; }
    std::string const& error() const noexcept { return error_; }
};

} // namespace omfg::live
