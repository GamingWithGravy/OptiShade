#pragma once
#include <windows.h>
#include <filesystem>
#include <string>
#include <vector>
#include <deque>
#include <map>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <shellapi.h>
#include <objbase.h>
#include <shlobj.h>
#include <iomanip>

// PresentMon is an independent ETW observer. No frame data is fabricated from options-call cadence.
struct FpsCapture {
    HANDLE brokerProcess{},brokerStop{};std::filesystem::path brokerFile;
    HANDLE pipe{},process{},job{};std::string pending,error;std::vector<std::string> columns;
    struct Sample{double time{},duration{};};std::map<std::string,std::deque<Sample>> chains;
    DWORD target{};ULONGLONG lastData{};double fps{};std::filesystem::path errorPath,binary;std::wstring session;
    ~FpsCapture(){Stop();}
    static std::string FailureMessage(DWORD code, std::string text){
        text.erase(std::remove(text.begin(),text.end(),'\0'),text.end()); // PresentMon may write UTF-16 stderr.
        std::transform(text.begin(),text.end(),text.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
        if(text.find("access denied")!=std::string::npos || text.find("access is denied")!=std::string::npos)
            return "FPS capture permission denied. Use Enable FPS capture (administrator) to approve this capture session. Live MFG controls do not need elevation.";
        return "FPS capture stopped (exit "+std::to_string(code)+"). Export diagnostics for the PresentMon error.";
    }
    static uint64_t Birth(HANDLE h){FILETIME c{},e{},k{},u{};if(!GetProcessTimes(h,&c,&e,&k,&u))throw std::runtime_error("Cannot identify capture process lifetime");return (uint64_t(c.dwHighDateTime)<<32)|c.dwLowDateTime;}
    static std::filesystem::path BrokerFile(std::wstring const& token,HANDLE user=nullptr){PWSTR local{};if(FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData,0,user,&local)))throw std::runtime_error("Capture user app data unavailable");auto result=std::filesystem::path(local)/L"OptiMFG"/L"runtime"/(L"fps-broker-"+token+L".txt");CoTaskMemFree(local);return result;}

    void StartElevated(DWORD pid){
        HANDLE game=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!game)throw std::runtime_error("Game exited before FPS capture");uint64_t birth{};try{birth=Birth(game);}catch(...){CloseHandle(game);throw;}CloseHandle(game);
        Stop();error.clear();target=pid;GUID guid{};if(FAILED(CoCreateGuid(&guid)))throw std::runtime_error("Cannot create capture identity");wchar_t token[40]{};StringFromGUID2(guid,token,40);
        brokerFile=BrokerFile(token);errorPath=brokerFile.wstring()+L".log";std::filesystem::create_directories(brokerFile.parent_path());
        brokerStop=CreateEventW(nullptr,TRUE,FALSE,(std::wstring(L"Local\\OptiMFG.FPS.")+token).c_str());if(!brokerStop)throw std::runtime_error("Cannot create capture stop event");
        wchar_t exe[32768]{};GetModuleFileNameW(nullptr,exe,32768);
        std::wstring args=L"--fps-broker "+std::to_wstring(pid)+L" "+std::to_wstring(birth)+L" "+std::to_wstring(GetCurrentProcessId())+L" "+std::to_wstring(Birth(GetCurrentProcess()))+L" "+token;
        SHELLEXECUTEINFOW info{sizeof(info)};info.fMask=SEE_MASK_NOCLOSEPROCESS|SEE_MASK_FLAG_NO_UI;info.lpVerb=L"runas";info.lpFile=exe;info.lpParameters=args.c_str();info.nShow=SW_HIDE;
        if(!ShellExecuteExW(&info)){auto code=GetLastError();CloseHandle(brokerStop);brokerStop=nullptr;error=code==ERROR_CANCELLED?"FPS capture permission request cancelled; live controls remain available.":"Could not start elevated FPS capture.";throw std::runtime_error(error);}
        brokerProcess=info.hProcess;
    }
    void Stop(){if(brokerStop){SetEvent(brokerStop);CloseHandle(brokerStop);brokerStop=nullptr;}if(brokerProcess){CloseHandle(brokerProcess);brokerProcess=nullptr;}brokerFile.clear();if(process&&!session.empty()){
        std::wstring cmd=L"\""+binary.wstring()+L"\" --session_name "+session+L" --terminate_existing_session";STARTUPINFOW si{sizeof(si)};PROCESS_INFORMATION pi{};
        if(CreateProcessW(binary.c_str(),cmd.data(),nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,nullptr,&si,&pi)){if(WaitForSingleObject(pi.hProcess,1500)==WAIT_TIMEOUT)TerminateProcess(pi.hProcess,1);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);}}
        session.clear();if(job)CloseHandle(job);job=nullptr;if(process){WaitForSingleObject(process,1000);CloseHandle(process);}process=nullptr;if(pipe)CloseHandle(pipe);pipe=nullptr;fps=0;chains.clear();columns.clear();pending.clear();lastData=0;}
    static std::vector<std::string> Split(std::string const& line){std::vector<std::string> out;std::string field;bool quoted=false;for(char c:line){if(c=='"')quoted=!quoted;else if(c==','&&!quoted){out.push_back(field);field.clear();}else if(c!='\r')field+=c;}out.push_back(field);return out;}
    void Line(std::string const& line){auto fields=Split(line);if(fields.size()>2&&fields[0]=="Application"){columns=fields;return;}if(columns.empty()||fields.size()!=columns.size())return;
        auto get=[&](char const* name)->std::string{auto it=std::find(columns.begin(),columns.end(),name);return it==columns.end()?"":fields[static_cast<size_t>(it-columns.begin())];};
        try{if(std::stoul(get("ProcessID"))!=target)return;auto type=get("FrameType");if(!type.empty()&&type!="Application"&&type!="NotSet")return;
            double time=std::stod(get("CPUStartTime")),duration=std::stod(get("FrameTime"));if(!std::isfinite(time)||!std::isfinite(duration)||duration<=0||duration>10000)return;
            auto& q=chains[get("SwapChainAddress")];q.push_back({time,duration});while(!q.empty()&&(time-q.front().time>2000||q.size()>2000))q.pop_front();
            double best=0;for(auto const& [key,samples]:chains){if(samples.size()<3||time-samples.back().time>1000)continue;double total=0;for(auto const& s:samples)total+=s.duration;best=std::max(best,1000.0*samples.size()/total);}fps=best;lastData=GetTickCount64();
        }catch(...){} }
    void Poll(){if(brokerProcess){
        std::ifstream in(brokerFile);uint64_t tick{};double measured{};std::string message;
        if(in>>tick>>measured){in.ignore();std::getline(in,message);if(GetTickCount64()>=tick&&GetTickCount64()-tick<3000&&std::isfinite(measured)&&measured>=0){fps=measured;lastData=tick;error=message;}}
        if(GetTickCount64()-lastData>3000)fps=0;
        if(WaitForSingleObject(brokerProcess,0)==WAIT_OBJECT_0){if(error.empty())error="FPS capture session ended. Retry capture or export diagnostics.";Stop();}return;
    }if(!pipe)return;DWORD available{};while(PeekNamedPipe(pipe,nullptr,0,nullptr,&available,nullptr)&&available){char buffer[8192];DWORD read{};if(!ReadFile(pipe,buffer,std::min<DWORD>(available,sizeof(buffer)),&read,nullptr)||!read)break;pending.append(buffer,read);size_t end;while((end=pending.find('\n'))!=std::string::npos){Line(pending.substr(0,end));pending.erase(0,end+1);}if(pending.size()>1024*1024)pending.clear();}
        if(process&&WaitForSingleObject(process,0)==WAIT_OBJECT_0){DWORD code{};GetExitCodeProcess(process,&code);std::ifstream log(errorPath);std::string text(8192,'\0');log.read(text.data(),text.size());text.resize(static_cast<size_t>(log.gcount()));error=FailureMessage(code,text);Stop();}
        if(GetTickCount64()-lastData>3000)fps=0;
    }
    void Start(DWORD pid,std::filesystem::path const& executable,std::filesystem::path const& log){Stop();error.clear();target=pid;errorPath=log;
        if(!std::filesystem::exists(executable))throw std::runtime_error("PresentMon.exe is missing from the app folder");
        SECURITY_ATTRIBUTES sa{sizeof(sa),nullptr,TRUE};HANDLE write{};if(!CreatePipe(&pipe,&write,&sa,0))throw std::runtime_error("Cannot create FPS pipe");SetHandleInformation(pipe,HANDLE_FLAG_INHERIT,0);
        HANDLE stderrFile=CreateFileW(log.c_str(),GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
        HANDLE input=CreateFileW(L"NUL",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_EXISTING,0,nullptr);
        STARTUPINFOW si{sizeof(si)};si.dwFlags=STARTF_USESTDHANDLES;si.hStdOutput=write;si.hStdError=stderrFile;si.hStdInput=input;
        std::wstring command=L"\""+executable.wstring()+L"\" --process_id "+std::to_wstring(pid)+L" --output_stdout --v2_metrics --track_frame_type --no_console_stats --no_track_input --no_track_gpu --terminate_on_proc_exit --session_name OptiMFGFPS-"+std::to_wstring(GetCurrentProcessId());
        PROCESS_INFORMATION pi{};bool ok=CreateProcessW(executable.c_str(),command.data(),nullptr,nullptr,TRUE,CREATE_NO_WINDOW|CREATE_SUSPENDED,nullptr,nullptr,&si,&pi)!=FALSE;
        CloseHandle(write);if(stderrFile!=INVALID_HANDLE_VALUE)CloseHandle(stderrFile);if(input!=INVALID_HANDLE_VALUE)CloseHandle(input);
        if(!ok){Stop();throw std::runtime_error("Cannot start PresentMon FPS capture");}
        process=pi.hProcess;binary=executable;session=L"OptiMFGFPS-"+std::to_wstring(GetCurrentProcessId());job=CreateJobObjectW(nullptr,nullptr);JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};limits.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        if(!job||!SetInformationJobObject(job,JobObjectExtendedLimitInformation,&limits,sizeof(limits))||!AssignProcessToJobObject(job,process)){TerminateProcess(process,1);CloseHandle(pi.hThread);Stop();throw std::runtime_error("Cannot manage FPS capture lifetime");}
        ResumeThread(pi.hThread);CloseHandle(pi.hThread);
    }
};

// Explicitly approved, session-scoped observer. Never attaches a graphics helper or changes driver settings.
inline int RunFpsBroker(int argc,wchar_t** argv){
    if(argc!=7)return 2;
    HANDLE game{},parent{},stop{};
    try{
        const auto parse=[](wchar_t const* text){size_t used{};auto value=std::stoull(text,&used);if(!value||used!=wcslen(text))throw std::runtime_error("Invalid capture identity");return value;};
        auto gameId=parse(argv[2]),gameBirth=parse(argv[3]),parentId=parse(argv[4]),parentBirth=parse(argv[5]);
        if(gameId>MAXDWORD||parentId>MAXDWORD)throw std::runtime_error("Invalid process ID");
        std::wstring token(argv[6]);GUID guid{};if(token.size()!=38||FAILED(CLSIDFromString(token.c_str(),&guid)))throw std::runtime_error("Invalid capture token");
        game=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,static_cast<DWORD>(gameId));parent=OpenProcess(SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,static_cast<DWORD>(parentId));
        if(!game||!parent||FpsCapture::Birth(game)!=gameBirth||FpsCapture::Birth(parent)!=parentBirth)throw std::runtime_error("Capture session expired");
        wchar_t parentExe[32768]{},ownExe[32768]{};DWORD length=32768;GetModuleFileNameW(nullptr,ownExe,32768);
        if(!QueryFullProcessImageNameW(parent,0,parentExe,&length)||_wcsicmp(parentExe,ownExe))throw std::runtime_error("Unexpected capture controller");
        stop=OpenEventW(SYNCHRONIZE,FALSE,(L"Local\\OptiMFG.FPS."+token).c_str());if(!stop)throw std::runtime_error("Capture requester is unavailable");
        HANDLE parentToken{};if(!OpenProcessToken(parent,TOKEN_QUERY|TOKEN_IMPERSONATE,&parentToken))throw std::runtime_error("Cannot locate requesting user's capture folder");
        std::filesystem::path file;try{file=FpsCapture::BrokerFile(token,parentToken);}catch(...){CloseHandle(parentToken);throw;}CloseHandle(parentToken);auto temp=file;temp+=L".tmp";
        FpsCapture capture;capture.Start(static_cast<DWORD>(gameId),std::filesystem::path(ownExe).parent_path()/L"PresentMon.exe",file.wstring()+L".log");
        HANDLE waits[]={game,parent,stop};
        while(WaitForMultipleObjects(3,waits,FALSE,250)==WAIT_TIMEOUT){
            capture.Poll();std::ofstream out(temp,std::ios::trunc);out<<GetTickCount64()<<' '<<std::setprecision(12)<<capture.fps<<'\n'<<capture.error<<'\n';out.close();if(!out||!MoveFileExW(temp.c_str(),file.c_str(),MOVEFILE_REPLACE_EXISTING))break;
            if(!capture.error.empty())break;
        }
        capture.Stop();CloseHandle(stop);CloseHandle(parent);CloseHandle(game);return 0;
    }catch(...){if(stop)CloseHandle(stop);if(parent)CloseHandle(parent);if(game)CloseHandle(game);return 1;}
}
