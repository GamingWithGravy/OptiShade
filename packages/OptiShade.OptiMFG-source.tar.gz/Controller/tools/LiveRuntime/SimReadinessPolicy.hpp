#pragma once
#include <cstdint>

namespace omfg::live {
inline bool StableSimulationRunning(bool running, std::uint64_t runningSince,
                                    std::uint64_t now, std::uint64_t stableMs = 5000) noexcept {
    return running && runningSince != 0 && now >= runningSince && now - runningSince >= stableMs;
}
}
