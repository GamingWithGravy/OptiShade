OptiMFG / OptiShade external-controller integration candidate — 27 October 2026

In-game controls are in OptiShade > Performance > Frame generation. The desktop
OptiMFG EXE remains available from the system tray for recovery and diagnostics.
OptiShade IPC v1 forwards the same multiplier request to whichever provider is
actually installed for the selected MSFS process.

Provider selection is per game installation and comes from the owned
OptiMFGTest-backend.json manifest:
- No backend manifest: native Streamline control. The controller waits for
  Streamline to load and settle before attaching its native helper.
- Provider 1.7.0: MFG Unlocker file-transport route.
- Provider 1.2.2-optimfg.1: menu-free RTX provider route.
An existing backend is no longer rejected as retired. The controller waits for
its proxy/provider module and live status, then connects without loading the
native helper. It refuses to stack the native helper with either backend.

Each live route reports its detected GPU family, bridge readiness and safe
multiplier ceiling. OptiShade only exposes/forwards multipliers reported by the
active provider. This is routing and protocol validation, not a claim that each
game/GPU combination has verified image quality or smooth output. RTX 20/30/40
backend behavior remains experimental and requires hardware testing. RTX 50
uses the native route. AMD MFG is not supported by these NVIDIA provider paths.

Auto-connect uses process/module/provider readiness polling; it does not use
SimConnect. Native attachment waits five seconds after Streamline appears.
Provider-backed routes wait for the corresponding loader and fresh status.
Waiting/Connected reflects a live controller lease; runtime acknowledgement
and generated output are reported separately.

Install/repair core and OptiMFG together using a newly built OptiShade installer;
restart the simulator and controller. An older EXE does not implement this IPC.
No vendor DLSS/Streamline files were changed or downgraded by these route changes.

Validation: MSVC controller/helper/core builds, controller IPC expiry/request
checks, backend route-selection matrix, RTX-family protocol checks and source
checks. No GPU execution was tested here. Live MSFS menu visibility, disconnect
and reconnect, real multiplier changes, frame pacing and output still require
hardware verification.

The theme/widgets are GPL-3.0-or-later OptiShade additions; ImGui is MIT.
Keep license notices and corresponding source when distributing this candidate.
