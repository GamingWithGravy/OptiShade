﻿#pragma once
#include <string_view>
#include <stdexcept>
#include <vector>
#include <cstdint>

namespace omfg::live {
// A unique positive runtime observation may disambiguate duplicate processes.
// Zero or multiple qualified sessions retain the existing manual-selection guard.
inline uint32_t UniqueRenderingProcess(const std::vector<uint32_t>& qualified) noexcept {
    return qualified.size()==1?qualified.front():0;
}

// Warning only: never turn accepted settings into measured display output.
inline int BackendOutputWarning(bool driverOff, bool fresh, bool ready, bool accepted,
                                bool pending, bool gameOn, int request, uint64_t realMilli,
                                uint64_t outputMilli, unsigned source, unsigned windowMs,
                                uint64_t ageMs) noexcept {
    if(driverOff)return 300;
    const bool measured=source==1||source==2||source==4;
    if(fresh&&ready&&accepted&&!pending&&gameOn&&request>=2&&measured&&windowMs>=500&&ageMs<2000&&
       realMilli>0&&outputMilli>0&&double(outputMilli)<=double(realMilli)*1.1)return 301;
    return 0;
}

enum class ProviderRoute { Native, MfgUnlocker, Headless, Unsupported };

inline ProviderRoute SelectProviderRoute(bool hasManifest, std::string_view providerVersion,
                                         std::string_view proxy) noexcept {
    if (!hasManifest) return ProviderRoute::Native;
    if (proxy != "version.dll") return ProviderRoute::Unsupported;
    if (providerVersion == "1.7.0") return ProviderRoute::MfgUnlocker;
    if (providerVersion == "1.2.2-optimfg.1") return ProviderRoute::Headless;
    return ProviderRoute::Unsupported;
}

inline int ModeIndexForRequest(int request, bool supportsOff) {
    if (request == -1) return 0;
    if (request == 0) {
        if (!supportsOff) throw std::out_of_range("Off is controlled by the game for this provider/GPU");
        return 1;
    }
    if (request < 2 || request > 6) throw std::out_of_range("Unsupported frame-generation multiplier");
    return supportsOff ? request : request - 1;
}

inline int RequestForModeIndex(int index, bool supportsOff) {
    if (index < 0) throw std::out_of_range("No frame-generation option is selected");
    if (index == 0) return -1;
    if (supportsOff) {
        if (index == 1) return 0;
        if (index > 6) throw std::out_of_range("Selected multiplier is unavailable");
        return index;
    }
    if (index > 5) throw std::out_of_range("Selected multiplier is unavailable");
    return index + 1;
}

// A process can appear before its graphics provider has initialized. Only
// retry readiness races; permanent setup/ownership errors still stop retries.
inline bool RetryAutoConnect(std::string_view error) noexcept {
    return error.find("Streamline is not loaded yet") != std::string_view::npos ||
           error.find("Waiting for menu-free backend to load") != std::string_view::npos ||
           error.find("Backend status is stale; waiting for the game") != std::string_view::npos ||
           error.find("Backend status is not ready; waiting for the game") != std::string_view::npos ||
           error.find("Backend status belongs to an earlier game session; waiting for the game") != std::string_view::npos ||
           error.find("Menu-free backend status is stale") != std::string_view::npos ||
           error.find("Cannot read backend JSON") != std::string_view::npos ||
           error.find("Backend JSON is not an object") != std::string_view::npos;
}
}
