#include <windows.h>
#include <sddl.h>
#include <MinHook.h>
#include <sl.h>
#include <sl_dlss_g.h>
#include <OptiMFG/LivePolicy.hpp>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <vector>
#include <cstring>
#include <array>

using namespace omfg::live;
static Shared* shared{};
static HANDLE mapping{};
static PFun_slDLSSGSetOptions* originalSet{};
static PFun_slDLSSGGetState* originalState{};
static PFun_slSetTagForFrame* originalTags{};
static std::mutex guard;
static uint32_t firstViewport=UINT_MAX;
struct Capability{uint32_t viewport{UINT_MAX};LONG maximum{};bool valid{};DWORD observed{};};
static std::array<Capability,16> capabilities;
static LONG started{};

static sl::Result HookTags(sl::FrameToken const& frame,sl::ViewportHandle const& viewport,sl::ResourceTag const* tags,uint32_t count,sl::CommandBuffer* command){
    // Observe metadata only. Do not retain resources or change the game's submissions.
    LONG mask=0;
    if(tags)for(uint32_t i=0;i<count;++i){auto const& t=tags[i];
        if(t.structType!=sl::ResourceTag::s_structType||t.structVersion!=1||!t.resource)continue;
        if(t.resource->structType!=sl::Resource::s_structType||!t.resource->native)continue;
        if(t.type==sl::kBufferTypeDepth)mask|=1;
        if(t.type==sl::kBufferTypeMotionVectors)mask|=2;
        if(t.type==sl::kBufferTypeHUDLessColor)mask|=4;
        if(t.type==sl::kBufferTypeUIColorAndAlpha)mask|=8;
        if(t.type==sl::kBufferTypeBackbuffer)mask|=16;
    }
    auto result=originalTags(frame,viewport,tags,count,command);
    InterlockedIncrement(&shared->tagCalls);
    if(result!=sl::Result::eOk)InterlockedIncrement(&shared->tagErrors);
    else {InterlockedOr(&shared->tagMask,mask);Write(shared->tagViewport,static_cast<LONG>(static_cast<uint32_t>(viewport)));}
    return result;
}

static size_t OptionBytes(sl::DLSSGOptions const& o){
    if(o.structType!=sl::DLSSGOptions::s_structType)return 0;
    // Copy only through the last member present in the declared ABI version.
    auto end=[&](auto const& member){return static_cast<size_t>(reinterpret_cast<char const*>(&member)-reinterpret_cast<char const*>(&o))+sizeof(member);};
    switch(o.structVersion){case 1:return end(o.onErrorCallback);case 2:return end(o.bReserved15);
    case 3:return end(o.queueParallelismMode);case 4:return end(o.enableUserInterfaceRecomposition);case 5:return end(o.dynamicTargetFrameRate);default:return 0;}
}
static sl::Result HookSet(sl::ViewportHandle const& viewport,sl::DLSSGOptions const& options){
    LONG seq{},request{-1}; Decision decision; bool validCommand=ReadCommand(*shared,seq,request);
    const auto bytes=OptionBytes(options);
    {
        std::lock_guard lock(guard);
        auto vp=static_cast<uint32_t>(viewport);
        if(firstViewport==UINT_MAX)firstViewport=vp;
        InterlockedIncrement(&shared->optionCalls);
        Write(shared->viewport,static_cast<LONG>(vp));Write(shared->optionsVersion,static_cast<LONG>(options.structVersion));
        Write(shared->callbackThread,static_cast<LONG>(GetCurrentThreadId()));
        Write(shared->originalMode,static_cast<LONG>(options.mode));Write(shared->originalCount,static_cast<LONG>(options.numFramesToGenerate));
        bool lease=static_cast<DWORD>(GetTickCount()-static_cast<DWORD>(Read(shared->heartbeat)))<3000;
        Capability cap;for(auto const& entry:capabilities)if(entry.viewport==vp){cap=entry;break;}
        Write(shared->capabilityViewport,static_cast<LONG>(cap.viewport));
        Write(shared->maximum,cap.maximum);Write(shared->typeMatches,options.structType==sl::DLSSGOptions::s_structType?1:0);
        auto selected=Read(shared->selectedViewport);auto active=selected==-1?firstViewport:static_cast<uint32_t>(selected);
        bool capFresh=cap.valid&&GetTickCount()-cap.observed<3000;
        decision=Decide(validCommand?request:-1,static_cast<LONG>(options.mode),static_cast<LONG>(options.numFramesToGenerate),cap.maximum,capFresh,lease);
        if(!bytes){decision.change=false;decision.status=UnsupportedAbi;}
        if(vp!=active){decision.change=false;decision.status=MultipleViewports;}
        Write(shared->decisionStatus,decision.status);
    }
    sl::DLSSGOptions copy;
    if(decision.change){std::memcpy(&copy,&options,bytes);copy.mode=static_cast<sl::DLSSGMode>(decision.mode);copy.numFramesToGenerate=static_cast<uint32_t>(decision.count);}
    auto result=originalSet(viewport,decision.change?copy:options);
    Write(shared->lastResult,static_cast<LONG>(result));
    Write(shared->effectiveMode,decision.change?decision.mode:static_cast<LONG>(options.mode));
    Write(shared->effectiveCount,decision.change?decision.count:static_cast<LONG>(options.numFramesToGenerate));
    Write(shared->status,result==sl::Result::eOk?decision.status:ApiError);
    if(validCommand && result==sl::Result::eOk && (decision.change||request==-1))Write(shared->appliedSequence,seq);
    return result;
}
static sl::Result HookState(sl::ViewportHandle const& viewport,sl::DLSSGState& state,sl::DLSSGOptions const* options){
    auto result=originalState(viewport,state,options);
    // Observe the game's call; do not make extra calls that reset its presented-frame counters.
    std::lock_guard lock(guard);InterlockedIncrement(&shared->stateCalls);
    bool valid=result==sl::Result::eOk&&state.structType==sl::DLSSGState::s_structType&&state.structVersion>=2;
    auto vp=static_cast<uint32_t>(viewport);Capability* entry=nullptr;
    for(auto& candidate:capabilities)if(candidate.viewport==vp){entry=&candidate;break;}
    if(!entry)for(auto& candidate:capabilities)if(candidate.viewport==UINT_MAX){entry=&candidate;break;}
    // Failed/older-ABI queries do not return a valid capability sample. Keep the most recent
    // successful sample for at most three seconds; an explicit runtime failure invalidates it.
    if(entry&&valid)*entry={vp,static_cast<LONG>(state.numFramesToGenerateMax),state.status==sl::DLSSGStatus::eOk,GetTickCount()};
    if(!valid)InterlockedIncrement(&shared->failedStates);
    if(valid){InterlockedIncrement(&shared->validStates);
        auto presented=static_cast<LONG>(state.numFramesActuallyPresented);
        if(presented>Read(shared->presentedMaximum))Write(shared->presentedMaximum,presented);
        if(presented>1)InterlockedIncrement(&shared->multiPresentSamples);
        Write(shared->maximum,static_cast<LONG>(state.numFramesToGenerateMax));
        Write(shared->runtimeStatus,static_cast<LONG>(state.status));Write(shared->presented,static_cast<LONG>(state.numFramesActuallyPresented));
    }
    return result;
}
static bool CreateChannel(){
    HANDLE token{};if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&token))return false;
    DWORD size{};GetTokenInformation(token,TokenUser,nullptr,0,&size);std::vector<BYTE> buffer(size);
    if(!GetTokenInformation(token,TokenUser,buffer.data(),size,&size)){CloseHandle(token);return false;}CloseHandle(token);
    LPWSTR sid{};if(!ConvertSidToStringSidW(reinterpret_cast<TOKEN_USER*>(buffer.data())->User.Sid,&sid))return false;
    std::wstring sddl=L"D:P(A;;GA;;;SY)(A;;GA;;;"+std::wstring(sid)+L")S:(ML;;NW;;;ME)";LocalFree(sid);
    PSECURITY_DESCRIPTOR descriptor{};if(!ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl.c_str(),SDDL_REVISION_1,&descriptor,nullptr))return false;
    SECURITY_ATTRIBUTES attributes{sizeof(attributes),descriptor,FALSE};
    mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,&attributes,PAGE_READWRITE,0,sizeof(Shared),MappingName(GetCurrentProcessId()).c_str());
    DWORD error=GetLastError();LocalFree(descriptor);if(!mapping||error==ERROR_ALREADY_EXISTS){if(mapping)CloseHandle(mapping);mapping=nullptr;return false;}
    shared=static_cast<Shared*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared)));if(!shared)return false;
    new(shared) Shared;Write(shared->version,Version);Write(shared->pid,static_cast<LONG>(GetCurrentProcessId()));Write(shared->magic,Magic);Write(shared->status,WaitingOptions);return true;
}
extern "C" __declspec(dllexport) DWORD WINAPI OptiMFGLiveStart(void*){
    if(InterlockedCompareExchange(&started,1,0))return 1;
    HMODULE pinned{};GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,reinterpret_cast<LPCWSTR>(&OptiMFGLiveStart),&pinned);
    if(!CreateChannel())return 2;
    wchar_t local[32768]{};GetEnvironmentVariableW(L"LOCALAPPDATA",local,ARRAYSIZE(local));
    std::ofstream log;
    try{auto dir=std::filesystem::path(local)/L"OptiMFG"/L"runtime";std::filesystem::create_directories(dir);log.open(dir/(L"helper-v4-"+std::to_wstring(GetCurrentProcessId())+L".jsonl"));}catch(...){}
    auto fail=[&](char const* reason){Write(shared->status,HookError);if(log){log<<"{\"event\":\"helper_error\",\"reason\":\""<<reason<<"\"}\n";log.flush();}return DWORD(3);};
    auto interposer=GetModuleHandleW(L"sl.interposer.dll");if(!interposer)return fail("streamline_not_loaded");
    auto getFunction=reinterpret_cast<PFun_slGetFeatureFunction*>(GetProcAddress(interposer,"slGetFeatureFunction"));
    if(!getFunction)return fail("feature_resolver_missing");
    void* set{},*state{};
    const auto deadline=GetTickCount64()+120000;
    for(;;){
        set=nullptr;state=nullptr;
        const auto setResult=getFunction(sl::kFeatureDLSS_G,"slDLSSGSetOptions",set);
        const auto stateResult=getFunction(sl::kFeatureDLSS_G,"slDLSSGGetState",state);
        if(setResult==sl::Result::eOk&&stateResult==sl::Result::eOk&&set&&state)break;
        if(log){log<<"{\"event\":\"feature_lookup_wait\",\"set_result\":"<<static_cast<int>(setResult)<<",\"state_result\":"<<static_cast<int>(stateResult)<<"}\n";log.flush();}
        auto transient=[](sl::Result result){return result==sl::Result::eOk||result==sl::Result::eErrorNotInitialized||result==sl::Result::eErrorInitNotCalled||result==sl::Result::eErrorFeatureMissing;};
        if(!transient(setResult)||!transient(stateResult)||GetTickCount64()>=deadline)return fail("feature_functions_unavailable");
        Sleep(500);
    }
    if(MH_Initialize()!=MH_OK)return fail("hook_engine_init_failed");
    auto tags=GetProcAddress(interposer,"slSetTagForFrame");
    bool tagsHooked=tags&&MH_CreateHook(reinterpret_cast<void*>(tags),reinterpret_cast<void*>(&HookTags),reinterpret_cast<void**>(&originalTags))==MH_OK;
    if(MH_CreateHook(set,reinterpret_cast<void*>(&HookSet),reinterpret_cast<void**>(&originalSet))!=MH_OK||MH_CreateHook(state,reinterpret_cast<void*>(&HookState),reinterpret_cast<void**>(&originalState))!=MH_OK)return fail("hook_creation_failed");
    if(MH_QueueEnableHook(set)!=MH_OK||MH_QueueEnableHook(state)!=MH_OK||MH_ApplyQueued()!=MH_OK)return fail("hook_enable_failed");
    if(tagsHooked&&MH_EnableHook(reinterpret_cast<void*>(tags))!=MH_OK)tagsHooked=false;
    Write(shared->ready,1);
    if(log){log<<"{\"event\":\"observer_ready\",\"pid\":"<<GetCurrentProcessId()<<",\"tag_observer\":"<<(tagsHooked?"true":"false")<<",\"overrides_enabled\":false}\n";log.flush();}
    LONG oldStatus=-1,oldApplied=-1;DWORD lastReport{};
    for(;;){
        Sleep(250);LONG status=Read(shared->status),applied=Read(shared->appliedSequence);
        if(log&&(status!=oldStatus||applied!=oldApplied||GetTickCount()-lastReport>5000)){
            log<<"{\"event\":\"output_evidence\",\"tick_ms\":"<<GetTickCount64()<<",\"request\":"<<Read(shared->request)<<",\"last_result\":"<<Read(shared->lastResult)<<",\"valid_states\":"<<Read(shared->validStates)<<",\"failed_states\":"<<Read(shared->failedStates)<<",\"presented_maximum\":"<<Read(shared->presentedMaximum)<<",\"multi_present_samples\":"<<Read(shared->multiPresentSamples)<<",\"tag_calls\":"<<Read(shared->tagCalls)<<",\"tag_errors\":"<<Read(shared->tagErrors)<<",\"tag_mask\":"<<Read(shared->tagMask)<<",\"tag_viewport\":"<<Read(shared->tagViewport)<<"}\n";
            log<<"{\"event\":\"runtime_observation\",\"tick_ms\":"<<GetTickCount64()<<",\"status\":"<<status<<",\"request\":"<<Read(shared->request)<<",\"applied_sequence\":"<<applied<<",\"options_calls\":"<<Read(shared->optionCalls)<<",\"state_calls\":"<<Read(shared->stateCalls)<<",\"maximum_generated\":"<<Read(shared->maximum)<<",\"runtime_status\":"<<Read(shared->runtimeStatus)<<",\"effective_mode\":"<<Read(shared->effectiveMode)<<",\"effective_generated\":"<<Read(shared->effectiveCount)<<",\"game_observed_presented\":"<<Read(shared->presented)<<"}\n";log.flush();
            oldStatus=status;oldApplied=applied;lastReport=GetTickCount();
        }
    }
}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH)DisableThreadLibraryCalls(instance);return TRUE;}


