#include "Client.hpp"
#include <OptiMFG/LivePolicy.hpp>
#include <iostream>
using namespace omfg::live;
static void Require(bool value,char const* message){if(!value)throw std::runtime_error(message);}
int wmain(int argc,wchar_t** argv){try{
    if(argc<3)throw std::runtime_error("Usage: OptiMFG_LiveCtl --observe PID | --fixture-test PID | --request PID {-1|0|2..6} [seconds]");
    std::wstring action=argv[1];DWORD pid=std::stoul(argv[2]);
    wchar_t path[32768]{};GetModuleFileNameW(nullptr,path,ARRAYSIZE(path));
    if(action!=L"--observe"&&action!=L"--fixture-test"&&action!=L"--request")throw std::runtime_error("Unknown action");
    Attach(pid,std::filesystem::path(path).parent_path()/L"OptiMFG_LiveHelper_v4.dll",action==L"--fixture-test");
    Channel c;Require(c.Open(pid),"Open channel failed");auto& s=*c.shared;
    auto wait=[&](LONG request,LONG expectedStatus){Command(s,request);auto seq=Read(s.commandSequence);DWORD until=GetTickCount()+2500;
        while(static_cast<LONG>(until-GetTickCount())>0){c.Heartbeat();Sleep(25);if(Read(s.status)==expectedStatus&&(expectedStatus!=Accepted||Read(s.appliedSequence)==seq))return;}
        throw std::runtime_error("Timed out waiting for expected runtime response");};
    if(action==L"--fixture-test"){
        // Policy checks represent reported capabilities, not architecture-name guesses.
        Require(Decide(2,1,1,1,true,true).change,"2x rejected with capability 1");
        Require(!Decide(3,1,1,1,true,true).change,"3x accepted with capability 1");
        Require(!Decide(2,0,1,5,true,true).change,"Game OFF overwritten");
        Require(!Decide(2,1,1,5,true,false).change,"Expired lease accepted");
        Require(!Decide(2,1,1,0,false,true).change,"Unqueried support accepted");
        Require(Decide(0,2,0,5,true,true).count==1,"OFF must normalize invalid zero count");
        for(int i=0;i<100&&Read(s.stateCalls)<2;++i){c.Heartbeat();Sleep(25);}Require(Read(s.stateCalls)>0,"No game state calls observed");
        LONG maximum=Read(s.maximum);for(LONG n=2;n<=6;++n){wait(n,n-1<=maximum?Accepted:UnsupportedCount);if(n-1<=maximum)Require(Read(s.effectiveCount)==n-1,"Wrong generated count");}
        wait(0,Accepted);Require(Read(s.effectiveMode)==0,"Off not applied");wait(-1,Observing);Require(Read(s.effectiveMode)==1&&Read(s.effectiveCount)==1,"Game settings not restored");
        Require(Read(s.tagCalls)>0&&Read(s.tagMask)==2&&Read(s.tagErrors)==0,"Tag observer failed");
        wait(2,Accepted);Sleep(3300);Require(Read(s.status)==LeaseExpired&&Read(s.effectiveCount)==1,"Lease expiry did not return game settings");
        wait(-1,Observing);Require(Read(s.multiPresentSamples)>0&&Read(s.failedStates)>0,"Presentation/query counters missing");std::cout<<"Fixture passed: max generated="<<maximum<<"; modes, restore, heartbeat, capability policy, output counters\n";return 0;
    }
    LONG request=-1;unsigned seconds=5;
    if(action==L"--request"){if(argc<4)throw std::runtime_error("Missing request");request=std::stol(argv[3]);if(request!=-1&&request!=0&&(request<2||request>6))throw std::runtime_error("Invalid multiplier");if(argc>4)seconds=std::stoul(argv[4]);}
    // An explicit viewport is needed when loading/menu calls preceded the flight viewport.
    if(argc>5&&action==L"--request"){
        auto viewport=std::stoul(argv[5]);
        Require(viewport<=0x7fffffffUL,"Viewport out of range");
        Write(s.selectedViewport,static_cast<LONG>(viewport));
    }
    Command(s,request);
    for(unsigned i=0;i<seconds*4;++i){c.Heartbeat();Sleep(250);if(i%4==0)std::cout<<"status="<<Read(s.status)<<" options="<<Read(s.optionCalls)<<" states="<<Read(s.stateCalls)<<" max="<<Read(s.maximum)<<" host="<<Read(s.originalMode)<<" requested="<<Read(s.request)<<" effective="<<Read(s.effectiveCount)<<" ack="<<Read(s.appliedSequence)<<" seq="<<Read(s.commandSequence)<<" result="<<Read(s.lastResult)<<" abi="<<Read(s.optionsVersion)<<" viewport="<<Read(s.viewport)<<" hostCount="<<Read(s.originalCount)<<" mode="<<Read(s.effectiveMode)<<" thread="<<Read(s.callbackThread)<<" decision="<<Read(s.decisionStatus)<<" capvp="<<Read(s.capabilityViewport)<<" type="<<Read(s.typeMatches)<<"\n";}
    Command(s,-1);std::cout<<"Returned control request to game. Helper remains passive until process exit.\n";return 0;
}catch(std::exception const& e){std::cerr<<e.what()<<'\n';return 1;}}



