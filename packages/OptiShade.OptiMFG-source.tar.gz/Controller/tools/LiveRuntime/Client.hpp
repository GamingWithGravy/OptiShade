#pragma once
#include <OptiMFG/LiveProtocol.hpp>
#include <filesystem>
#include <stdexcept>
#include <vector>
namespace omfg::live {
struct Process { DWORD pid; std::wstring name; };
std::vector<Process> Processes();
bool StreamlineLoaded(DWORD pid);
void Attach(DWORD pid,std::filesystem::path helper,bool fixture=false);
struct Channel {
    HANDLE mapping{},writerLock{};Shared* shared{};
    ~Channel(){Close();}
    void Close(){if(shared)UnmapViewOfFile(shared);if(mapping)CloseHandle(mapping);if(writerLock)CloseHandle(writerLock);shared=nullptr;mapping=nullptr;writerLock=nullptr;}
    bool Open(DWORD pid){
        Close();PSECURITY_DESCRIPTOR descriptor{};
        if(!ConvertStringSecurityDescriptorToSecurityDescriptorW(L"D:P(A;;GA;;;SY)(A;;GA;;;OW)S:(ML;;NW;;;ME)",SDDL_REVISION_1,&descriptor,nullptr))throw std::runtime_error("Cannot prepare shared-control security descriptor");
        SECURITY_ATTRIBUTES attributes{sizeof(attributes),descriptor,FALSE};
        writerLock=CreateMutexW(&attributes,FALSE,(L"Local\\OptiMFG.Live.Writer."+std::to_wstring(pid)).c_str());LocalFree(descriptor);
        if(!writerLock)throw std::runtime_error("Cannot acquire controller lock");
        if(GetLastError()==ERROR_ALREADY_EXISTS){Close();throw std::runtime_error("Another live controller is connected to this process");}
        mapping=OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,MappingName(pid).c_str());if(!mapping){Close();return false;}
        shared=static_cast<Shared*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared)));
        if(!shared||Read(shared->magic)!=Magic||Read(shared->version)!=Version||static_cast<DWORD>(Read(shared->pid))!=pid){Close();return false;}return true;
    }
    void Heartbeat(){if(shared)Write(shared->heartbeat,static_cast<LONG>(GetTickCount()));}
};
}
