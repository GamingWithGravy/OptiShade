// Uses OptiShade's actual shared native widgets and theme, not a colour-only
// imitation of the legacy Win32 form. Rendering is confined to this EXE.
static ID3D11Device* desktopDevice{};
static ID3D11DeviceContext* desktopContext{};
static IDXGISwapChain* desktopSwap{};
static ID3D11RenderTargetView* desktopTarget{};
static bool desktopReady{};
static void InitDesktop(HWND window){
    DXGI_SWAP_CHAIN_DESC sd{};sd.BufferCount=2;sd.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;sd.OutputWindow=window;sd.SampleDesc.Count=1;sd.Windowed=TRUE;
    D3D_FEATURE_LEVEL level;
    auto result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&sd,&desktopSwap,&desktopDevice,&level,&desktopContext);
    if(FAILED(result))throw std::runtime_error("Cannot initialize the OptiShade desktop renderer");
    ID3D11Texture2D* buffer{};if(FAILED(desktopSwap->GetBuffer(0,IID_PPV_ARGS(&buffer))))throw std::runtime_error("Cannot create desktop surface");
    result=desktopDevice->CreateRenderTargetView(buffer,nullptr,&desktopTarget);buffer->Release();if(FAILED(result))throw std::runtime_error("Cannot create desktop render target");
    ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;
    io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeui.ttf",17.f);
    ImFontConfig font{};strcpy_s(font.Name,"OptiShade Semibold");io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/seguisb.ttf",20.f,&font);
    optishade::panel::ApplyDefaultTheme(ImGui::GetStyle(),1.f);
    if(!ImGui_ImplWin32_Init(window)||!ImGui_ImplDX11_Init(desktopDevice,desktopContext))throw std::runtime_error("Cannot initialize the OptiShade desktop UI");
    desktopReady=true;
}
static void ShutdownDesktop(){
    if(desktopReady){desktopReady=false;ImGui_ImplDX11_Shutdown();ImGui_ImplWin32_Shutdown();ImGui::DestroyContext();}
    if(desktopTarget)desktopTarget->Release();if(desktopSwap)desktopSwap->Release();if(desktopContext)desktopContext->Release();if(desktopDevice)desktopDevice->Release();
}
static void DesktopAction(App& a,auto action){try{a.errorText.clear();action();}catch(std::exception const& e){a.errorText=omfg::driver::Wide(e.what());a.Log("operation_failed",e.what());}}
// A button action can block in a Windows prompt (the FPS capture administrator
// request) that keeps dispatching messages. A WM_TIMER then drew a second frame
// inside this one, which ended its window, and the next widget wrote through a
// null window (OSD-D8G7: OptiMFG_Live.exe+0x82e6b after fps_elevation_requested).
static bool desktopDrawing{};
static void DrawDesktop(App& a){
    if(desktopDrawing||!desktopReady||!IsWindowVisible(a.window)||IsIconic(a.window))return;
    struct DrawingScope{DrawingScope(){desktopDrawing=true;}~DrawingScope(){desktopDrawing=false;}} drawingScope;
    ImGui_ImplDX11_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();
    ImGui::SetNextWindowPos({0,0});ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);
    ImGui::Begin("OptiMFG desktop",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);
    optishade::panel::PageTitle("OptiMFG","OptiShade live frame-generation controller");
    bool connected=a.game&&WaitForSingleObject(a.game,0)==WAIT_TIMEOUT&&((a.channel.shared&&Read(a.channel.shared->ready))||(a.backport.pid&&a.backport.fresh));
    optishade::panel::Card("Connection",[&]{
        optishade::panel::CardHeading("CONNECTION",connected?"Connected":"Waiting for game connection",7);
        bool automatic=SendMessageW(a.autoConnect,BM_GETCHECK,0,0)==BST_CHECKED;
        if(ImGui::Checkbox("Connect automatically",&automatic)){SendMessageW(a.autoConnect,BM_SETCHECK,automatic?BST_CHECKED:BST_UNCHECKED,0);a.nextAutoScan=0;a.autoAttemptedPid=0;WritePrivateProfileStringW(L"Connection",L"Automatic",automatic?L"1":L"0",(a.directory/L"settings.ini").c_str());}
        int index=static_cast<int>(SendMessageW(a.list,CB_GETCURSEL,0,0));
        auto name=index>=0&&static_cast<size_t>(index)<a.processes.size()?omfg::driver::Utf8(a.processes[index].name):"Select game";
        if(ImGui::BeginCombo("##game",name.c_str())){for(size_t n=0;n<a.processes.size();++n){auto label=omfg::driver::Utf8(a.processes[n].name)+" ("+std::to_string(a.processes[n].pid)+")";if(ImGui::Selectable(label.c_str(),index==static_cast<int>(n)))SendMessageW(a.list,CB_SETCURSEL,n,0);}ImGui::EndCombo();}
        if(ImGui::Button("Refresh"))DesktopAction(a,[&]{a.Refresh();});ImGui::SameLine();
        if(ImGui::Button("Connect"))DesktopAction(a,[&]{a.Connect();});
        if(!connected&&!a.autoMessage.empty())ImGui::TextWrapped("%s",omfg::driver::Utf8(a.autoMessage).c_str());
    });
    optishade::panel::Card("Frame generation",[&]{
        optishade::panel::CardHeading("FRAME GENERATION","Control here or in OptiShade > Performance",8);
        ImGui::BeginDisabled(!connected);
        int selected=static_cast<int>(SendMessageW(a.mode,CB_GETCURSEL,0,0));
        const bool backendReady=!a.backport.pid||(a.backport.fresh&&a.backport.snapshot.value("bridgeReady",false));
        const int count=static_cast<int>(SendMessageW(a.mode,CB_GETCOUNT,0,0));
        auto modeLabel=[&](int index){wchar_t text[128]{};if(index>=0&&index<count&&SendMessageW(a.mode,CB_GETLBTEXTLEN,index,0)<128)SendMessageW(a.mode,CB_GETLBTEXT,index,reinterpret_cast<LPARAM>(text));return omfg::driver::Utf8(text);};
        auto label=modeLabel(selected);
        ImGui::BeginDisabled(!backendReady);
        if(ImGui::BeginCombo("Multiplier",label.empty()?"Follow game":label.c_str())){
            for(int n=0;n<count;++n){auto item=modeLabel(n);if(ImGui::Selectable(item.c_str(),selected==n))SendMessageW(a.mode,CB_SETCURSEL,n,0);}ImGui::EndCombo();}
        if(ImGui::Button("Apply"))DesktopAction(a,[&]{a.Request();});ImGui::EndDisabled();
        ImGui::SameLine();if(ImGui::Button("Follow game"))DesktopAction(a,[&]{a.Release();});ImGui::EndDisabled();
        if(a.backport.pid&&a.backport.fresh&&!backendReady)ImGui::TextWrapped("Backend not ready: %s",a.backport.snapshot.value("universalRouteFailureReason",std::string("waiting for provider")).c_str());
        if(a.channel.shared)ImGui::TextWrapped("%s",omfg::driver::Utf8(StatusText(Read(a.channel.shared->status))).c_str());
        ImGui::TextWrapped("%s",omfg::driver::Utf8(a.fpsLabel).c_str());
        ImGui::TextDisabled("Application FPS excludes generated frames.");
        if(!a.capture.error.empty()){ImGui::TextWrapped("%s",a.capture.error.c_str());ImGui::BeginDisabled(!connected);if(ImGui::Button("Enable FPS capture (administrator)"))DesktopAction(a,[&]{a.capture.StartElevated(a.pid);a.Log("fps_elevation_requested","User requested session-only FPS capture");});ImGui::EndDisabled();}
        bool overlay=a.showOverlay;if(ImGui::Checkbox("Show FPS in game",&overlay))a.ToggleOverlay();
        int key=static_cast<int>(SendMessageW(a.hotkey,CB_GETCURSEL,0,0));
        const char* keys[]={"Ctrl + Alt + F8","Ctrl + Alt + F9","Ctrl + Alt + F10"};
        if(ImGui::Combo("FPS shortcut",&key,keys,3))DesktopAction(a,[&]{SendMessageW(a.hotkey,CB_SETCURSEL,key,0);a.BindHotkey();});
        if(ImGui::CollapsingHeader("Runtime details")){wchar_t value[8192]{};GetWindowTextW(a.status,value,8192);ImGui::TextWrapped("%s",omfg::driver::Utf8(value).c_str());}
    });
    optishade::panel::Card("Diagnostics",[&]{
        optishade::panel::CardHeading("DIAGNOSTICS","",7);
        if(ImGui::Button("Export diagnostics ZIP"))DesktopAction(a,[&]{a.Export();});ImGui::SameLine();
        if(ImGui::Button("Open diagnostics folder"))DesktopAction(a,[&]{a.OpenDiagnostics();});
        if(ImGui::CollapsingHeader("Driver profile")){
            wchar_t text[2048]{};GetWindowTextW(a.driverText,text,2048);ImGui::TextWrapped("%s",omfg::driver::Utf8(text).c_str());
            if(ImGui::Button("Check driver"))DesktopAction(a,[&]{a.CheckDriver();});
            ImGui::BeginDisabled(a.game!=nullptr);ImGui::SameLine();if(ImGui::Button("Application controlled"))DesktopAction(a,[&]{a.FixDriver();});ImGui::SameLine();if(ImGui::Button("Undo profile change"))DesktopAction(a,[&]{a.UndoDriver();});ImGui::EndDisabled();
            ImGui::TextDisabled("Close the game before changing its driver profile.");
        }
    });
    if(!a.errorText.empty())ImGui::TextWrapped("%s",omfg::driver::Utf8(a.errorText).c_str());
    ImGui::End();ImGui::Render();float background[]={.063f,.059f,.110f,1.f};desktopContext->OMSetRenderTargets(1,&desktopTarget,nullptr);desktopContext->ClearRenderTargetView(desktopTarget,background);ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());desktopSwap->Present(1,0);
}
