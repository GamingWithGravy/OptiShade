﻿// Executed only by the EXE's UI thread. Never call game APIs from this IPC
// handler: requests go through the same validation path as desktop actions.
void ServiceController(){
    if(!game||WaitForSingleObject(game,0)!=WAIT_TIMEOUT){controller.Close();return;}
    if(!controller.Open(pid,true))return;
    omfg::controller::State incoming;
    if(!controller.Snapshot(incoming))return;
    LONG received=incoming.receivedSequence,result=incoming.commandResult;
    if(incoming.commandSequence!=received){
        received=incoming.commandSequence;
        try{
            auto value=incoming.request;
            if(value!=-1&&value!=0&&(value<2||value>6))throw std::runtime_error("Invalid in-game multiplier request");
            auto index=backport.pid?BackportIndexForRequest(value):value==-1?0:value==0?1:value;
            SendMessageW(mode,CB_SETCURSEL,index,0);
            if(SendMessageW(mode,CB_GETCURSEL,0,0)!=index)throw std::runtime_error("Requested mode is unavailable");
            if(channel.shared)SetWindowTextW(viewportEdit,std::to_wstring(Read(channel.shared->viewport)).c_str());
            Request();result=1;controllerHelperSequence=channel.shared?Read(channel.shared->commandSequence):0;
            Log("optishade_request_received",std::to_string(value));
        }catch(std::exception const& e){result=-1;errorText=omfg::driver::Wide(e.what());Log("optishade_request_rejected",e.what());}
    }
    controller.Update([&](auto& out){
        out.receivedSequence=received;out.commandResult=result;
        if(channel.shared){auto& s=*channel.shared;
            const bool attached=game&&WaitForSingleObject(game,0)==WAIT_TIMEOUT;
            const bool ready=attached&&Read(s.ready)!=0;
            // Connected means the controller has a live game session. Keep
            // capability separate so the UI can show OptiMFG's waiting state
            // instead of falling back to native 2x controls before FG starts.
            out.activeRequest=Read(s.request);out.connected=attached;out.maximumGenerated=ready?Read(s.maximum):-1;out.stateCalls=Read(s.stateCalls);
            out.status=Read(s.status);out.effectiveCount=Read(s.effectiveCount);out.lastResult=Read(s.lastResult);
            if(result==1&&controllerHelperSequence==Read(s.appliedSequence))out.appliedSequence=received;
        }else if(backport.pid){
            auto attached=backport.fresh;
            auto ready=attached&&backport.snapshot.value("bridgeReady",false);
            out.activeRequest=backport.requested;out.connected=attached;out.maximumGenerated=ready?backport.snapshot.value("safeMaximumMultiplier",1)-1:-1;
            out.stateCalls=attached?1:0;out.status=ready?1:2;
            if(attached&&!ready){auto failure=backport.snapshot.value("universalRouteFailure",0);if(failure>=1&&failure<=14)out.status=200+failure;}
            out.effectiveCount=ready?backport.snapshot.value("appliedMultiplier",1)-1:0;
            if(result==1&&ready&&!backport.snapshot.value("pending",true)&&backport.snapshot.value("setOptionsAccepted",false)&&backport.snapshot.value("appliedMultiplier",0)==out.request){out.appliedSequence=received;out.status=5;}
        }else out.connected=0;
        const bool driverOff=profile&&!profile->values.empty()&&profile->values[0].value==1;
        if(backport.pid){
            auto const& b=backport.snapshot;
            const int warning=BackendOutputWarning(driverOff,backport.fresh,b.value("bridgeReady",false),
                b.value("setOptionsAccepted",false),b.value("pending",true),b.value("gameFrameGenerationOn",false),
                backport.requested,b.value("realFpsMilli",uint64_t{0}),b.value("dlssFpsMilli",uint64_t{0}),
                b.value("fpsOutputSource",0u),b.value("fpsSampleWindowMs",0u),b.value("fpsSampleAgeMs",UINT64_MAX));
            if(warning)out.status=warning;
        }else if(channel.shared&&driverOff)out.status=300;
    });
}
