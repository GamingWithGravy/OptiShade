#include <windows.h>
#include <shellapi.h>
#include <commdlg.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <wrl/client.h>
#include "OptiMFG/HostGpuContract.hpp"
#include "OptiMFG/OptiMFG.h"
#include "OptiMFG/Dx12Interpolator.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include "SceneVS.h"
#include "ScenePS.h"
#include "TagPS.h"
using Microsoft::WRL::ComPtr;
namespace {
struct HrError : std::runtime_error {
    HRESULT hr;
    HrError(HRESULT code, const char* operation) : std::runtime_error(operation), hr(code) {}
};
void check(HRESULT hr, const char* operation) { if (FAILED(hr)) throw HrError(hr, operation); }
void require(omfg::Result r) { if (!r) throw std::runtime_error(std::string(omfg::name(r.error))); }
std::string hex(uint64_t n) { std::ostringstream s; s << "0x" << std::hex << n; return s.str(); }
std::string utf8(const wchar_t* s) {
    int size = WideCharToMultiByte(CP_UTF8, 0, s, -1, nullptr, 0, nullptr, nullptr);
    if (size <= 0) return "unknown";
    std::string result(static_cast<size_t>(size), '\0');
    WideCharToMultiByte(CP_UTF8, 0, s, -1, result.data(), size, nullptr, nullptr);
    result.pop_back(); return result;
}
std::string jsonQuote(const std::string& value) {
    std::string out = "\"";
    for (unsigned char c : value) {
        if (c == '"' || c == '\\') { out += '\\'; out += static_cast<char>(c); }
        else if (c >= 32) out += static_cast<char>(c);
    }
    return out + "\"";
}
struct Options {
    uint64_t frames = 0, simulateLossAt = 0;
    unsigned stress = 0;
    unsigned adapter = 0, multiplier = 2;
    bool mfg = false, verifyReadback = false, native = false;
    bool debug = false, validation = false, diagnostic = false, vsync = true, borderless = false;
    std::filesystem::path log = L"OptiMFG-host-" + std::to_wstring(GetCurrentProcessId()) + L".jsonl";
    std::filesystem::path exportLog;
};
Options options() {
    int count = 0; auto args = CommandLineToArgvW(GetCommandLineW(), &count);
    if (!args) throw std::runtime_error("command_line_parse_failed");
    Options o;
    try {
        for (int i = 1; i < count; ++i) {
            std::wstring a = args[i];
            auto value = [&]() -> std::wstring { if (++i >= count) throw std::runtime_error("missing_argument"); return args[i]; };
            auto number = [&]() { auto s = value(); if (s.empty() || s.find_first_not_of(L"0123456789") != std::wstring::npos) throw std::runtime_error("invalid_number"); return std::stoull(s); };
            if (a == L"--frames") o.frames = number();
            else if (a == L"--stress-resizes") { auto n = number(); if (n > 10000) throw std::runtime_error("stress_limit_10000"); o.stress = static_cast<unsigned>(n); }
            else if (a == L"--simulate-device-loss") o.simulateLossAt = number();
            else if (a == L"--log") o.log = value();
            else if (a == L"--export-log") o.exportLog = value();
            else if (a == L"--adapter") { auto n = number(); if (n > 100) throw std::runtime_error("invalid_adapter"); o.adapter = static_cast<unsigned>(n); }
            else if (a == L"--multiplier") { auto n = number(); if (n < 2 || n > 6) throw std::runtime_error("multiplier_must_be_2_to_6"); o.multiplier = static_cast<unsigned>(n); }
            else if (a == L"--mfg") o.mfg = true;
            else if (a == L"--verify-readback") o.verifyReadback = true;
            else if (a == L"--native") o.native = true;
            else if (a == L"--debug") o.debug = true;
            else if (a == L"--gpu-validation") o.debug = o.validation = true;
            else if (a == L"--diagnostic") o.diagnostic = true;
            else if (a == L"--no-vsync") o.vsync = false;
            else if (a == L"--borderless") o.borderless = true;
            else throw std::runtime_error("unknown_argument");
        }
    } catch (...) { LocalFree(args); throw; }
    LocalFree(args); return o;
}
class Log {
    std::ofstream stream_;
    uint64_t sequence_ = 0;
public:
    explicit Log(const std::filesystem::path& path) : stream_(path, std::ios::trunc) {
        if (!stream_) throw std::runtime_error("log_open_failed");
    }
    void event(const char* event, const std::string& fields = "") {
        stream_ << "{\"sequence\":" << ++sequence_ << ",\"event\":\"" << event << "\"" << fields << "}\n";
        stream_.flush();
        if (!stream_) throw std::runtime_error("log_write_failed");
    }
};
std::string windowsVersion() {
    wchar_t directory[MAX_PATH]{};
    if (!GetSystemDirectoryW(directory, MAX_PATH)) return "unknown";
    auto path = std::wstring(directory) + L"\\kernel32.dll";
    DWORD unused = 0, size = GetFileVersionInfoSizeW(path.c_str(), &unused);
    std::vector<BYTE> data(size);
    VS_FIXEDFILEINFO* info = nullptr; UINT bytes = 0;
    if (!size || !GetFileVersionInfoW(path.c_str(), 0, size, data.data()) ||
        !VerQueryValueW(data.data(), L"\\", reinterpret_cast<void**>(&info), &bytes) || bytes < sizeof(*info)) return "unknown";
    return std::to_string(HIWORD(info->dwFileVersionMS)) + "." + std::to_string(LOWORD(info->dwFileVersionMS)) + "." +
           std::to_string(HIWORD(info->dwFileVersionLS)) + "." + std::to_string(LOWORD(info->dwFileVersionLS));
}
class App {
    Options opt_;
    Log log_;
    HWND window_ = nullptr;
    HWND adapterControl_ = nullptr, backendControl_ = nullptr, multiplierControl_ = nullptr, statusControl_ = nullptr, exportControl_ = nullptr;
    std::vector<HWND> controls_;
    std::vector<std::wstring> adapterNames_;
    bool toggleRequested_ = false, exportRequested_ = false, adapterChangeRequested_ = false, backendChanged_ = false, multiplierChanged_ = false;
    bool mfgRequested_ = false, mfgActive_ = false;
    bool backendReady_ = false;
    std::string backendBlocker_;
    unsigned backendSelection_ = 0;
    bool minimized_ = false, pendingResize_ = false, displayChanged_ = true, quit_ = false, occluded_ = false;
    bool debugActive_ = false, validationActive_ = false, tearing_ = false;
    UINT width_ = 1000, height_ = 620, pendingWidth_ = 1000, pendingHeight_ = 620;
    ComPtr<IDXGIFactory6> factory_;
    ComPtr<IDXGIAdapter1> adapter_;
    ComPtr<ID3D12Device> device_;
    ComPtr<ID3D12InfoQueue> info_;
    ComPtr<ID3D12CommandQueue> queue_;
    ComPtr<IDXGISwapChain3> swap_;
    ComPtr<ID3D12DescriptorHeap> heap_;
    ComPtr<ID3D12CommandAllocator> allocator_;
    ComPtr<ID3D12GraphicsCommandList> list_;
    ComPtr<ID3D12Fence> fence_;
    ComPtr<ID3D12RootSignature> root_;
    ComPtr<ID3D12PipelineState> scenePipeline_, tagPipeline_;
    std::array<ComPtr<ID3D12Resource>, 2> buffers_;
    ComPtr<ID3D12Resource> color_, depth_, motion_;
    ComPtr<ID3D12Resource> previousColor_, previousDepth_;
    omfg::Dx12Interpolator interpolator_;
    uint64_t generated_ = 0;
    HANDLE event_ = nullptr;
    UINT descriptorSize_ = 0;
    uint64_t fenceValue_ = 0, submitted_ = 0, presented_ = 0, occludedPresents_ = 0, frameId_ = 0;
    uint64_t debugErrors_ = 0, debugWarnings_ = 0, resizeCount_ = 0, recoveries_ = 0;
    unsigned stressDone_ = 0, recoveryAttempts_ = 0;
    bool simulationDone_ = false;
    int previousX_ = 0;
    int64_t previousTimestamp_ = -1;
    LARGE_INTEGER frequency_{}, origin_{};
    omfg::HostContract contract_;
    static LRESULT CALLBACK proc(HWND h, UINT msg, WPARAM w, LPARAM l) {
        auto self = reinterpret_cast<App*>(GetWindowLongPtrW(h, GWLP_USERDATA));
        if (msg == WM_NCCREATE) {
            self = static_cast<App*>(reinterpret_cast<CREATESTRUCTW*>(l)->lpCreateParams);
            SetWindowLongPtrW(h, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
        }
        if (self) {
            if (msg == WM_COMMAND) {
                const auto id = LOWORD(w), notification = HIWORD(w);
                if (id == 101 && notification == BN_CLICKED) self->toggleRequested_ = true;
                if (id == 102 && notification == BN_CLICKED) self->exportRequested_ = true;
                if (id == 103 && notification == CBN_SELCHANGE) self->adapterChangeRequested_ = true;
                if (id == 104 && notification == CBN_SELCHANGE) {
                    self->backendSelection_ = static_cast<unsigned>(SendMessageW(self->backendControl_, CB_GETCURSEL, 0, 0));
                    self->backendChanged_ = true;
                }
                if (id == 105 && notification == CBN_SELCHANGE) {
                    self->opt_.multiplier = static_cast<unsigned>(SendMessageW(self->multiplierControl_, CB_GETCURSEL, 0, 0)) + 2;
                    self->multiplierChanged_ = true;
                }
                return 0;
            }
            if (msg == WM_SIZE) {
                self->minimized_ = w == SIZE_MINIMIZED;
                if (!self->minimized_ && LOWORD(l) && HIWORD(l)) {
                    self->pendingWidth_ = LOWORD(l); self->pendingHeight_ = HIWORD(l); self->pendingResize_ = true;
                }
                return 0;
            }
            if (msg == WM_DISPLAYCHANGE || msg == WM_MOVE) self->displayChanged_ = true;
            if (msg == WM_KEYDOWN && w == VK_ESCAPE) { DestroyWindow(h); return 0; }
            if (msg == WM_DESTROY) { self->quit_ = true; PostQuitMessage(0); return 0; }
            if (msg == WM_ERASEBKGND) return 1;
        }
        return DefWindowProcW(h, msg, w, l);
    }
    omfg::Output output() const { return {width_, height_, DXGI_FORMAT_R8G8B8A8_UNORM, omfg::Transfer::SDR_Gamma22, false}; }
    D3D12_CPU_DESCRIPTOR_HANDLE rtv(UINT slot) const {
        auto h = heap_->GetCPUDescriptorHandleForHeapStart(); h.ptr += static_cast<SIZE_T>(descriptorSize_) * slot; return h;
    }
    void transition(ID3D12Resource* resource, D3D12_RESOURCE_STATES from, D3D12_RESOURCE_STATES to) {
        D3D12_RESOURCE_BARRIER b{};
        b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        b.Transition.pResource = resource; b.Transition.StateBefore = from; b.Transition.StateAfter = to;
        b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        list_->ResourceBarrier(1, &b);
    }
    void debugMessages() {
        if (!info_) return;
        const auto count = info_->GetNumStoredMessagesAllowedByRetrievalFilter();
        for (UINT64 i = 0; i < count; ++i) {
            SIZE_T size = 0; check(info_->GetMessage(i, nullptr, &size), "debug_message_size");
            std::vector<BYTE> data(size);
            auto m = reinterpret_cast<D3D12_MESSAGE*>(data.data());
            check(info_->GetMessage(i, m, &size), "debug_message_read");
            if (m->Severity <= D3D12_MESSAGE_SEVERITY_WARNING) {
                if (m->Severity <= D3D12_MESSAGE_SEVERITY_ERROR) ++debugErrors_; else ++debugWarnings_;
                // Message IDs suffice for diagnostics without arbitrary driver strings/paths.
                log_.event("d3d12_validation", ",\"id\":" + std::to_string(m->ID) + ",\"severity\":" + std::to_string(m->Severity));
            }
        }
        info_->ClearStoredMessages();
    }
    void waitGpu() {
        if (!fence_ || !fenceValue_) return;
        auto completed = fence_->GetCompletedValue();
        if (completed == UINT64_MAX) throw HrError(DXGI_ERROR_DEVICE_REMOVED, "fence_device_removed");
        if (completed < fenceValue_) {
            check(fence_->SetEventOnCompletion(fenceValue_, event_), "fence_event");
            DWORD result = WaitForSingleObject(event_, 10000);
            if (result != WAIT_OBJECT_0) {
                HRESULT reason = device_->GetDeviceRemovedReason();
                log_.event("sync_failure", ",\"wait_result\":" + std::to_string(result) + ",\"removal_reason\":" + jsonQuote(hex(static_cast<uint32_t>(reason))));
                if (FAILED(reason)) throw HrError(reason, "fence_wait_device_removed");
                throw std::runtime_error("gpu_wait_timeout_or_failure");
            }
        }
        if (fence_->GetCompletedValue() == UINT64_MAX) throw HrError(DXGI_ERROR_DEVICE_REMOVED, "fence_device_removed");
        debugMessages();
    }
    void flush() {
        if (queue_ && fence_) { check(queue_->Signal(fence_.Get(), ++fenceValue_), "flush_signal"); waitGpu(); }
    }
    void targets() {
        for (UINT i = 0; i < 2; ++i) {
            check(swap_->GetBuffer(i, IID_PPV_ARGS(&buffers_[i])), "get_back_buffer");
            device_->CreateRenderTargetView(buffers_[i].Get(), nullptr, rtv(i));
        }
        auto target = [&](DXGI_FORMAT format, UINT slot, ComPtr<ID3D12Resource>& resource) {
            D3D12_FEATURE_DATA_FORMAT_SUPPORT support{format};
            check(device_->CheckFeatureSupport(D3D12_FEATURE_FORMAT_SUPPORT, &support, sizeof(support)), "target_format_query");
            if (!(support.Support1 & D3D12_FORMAT_SUPPORT1_RENDER_TARGET)) throw std::runtime_error("target_format_unsupported");
            D3D12_HEAP_PROPERTIES memory{}; memory.Type = D3D12_HEAP_TYPE_DEFAULT;
            D3D12_RESOURCE_DESC desc{};
            desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D; desc.Width = width_; desc.Height = height_;
            desc.DepthOrArraySize = 1; desc.MipLevels = 1; desc.Format = format; desc.SampleDesc.Count = 1;
            desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET;
            check(device_->CreateCommittedResource(&memory, D3D12_HEAP_FLAG_NONE, &desc, D3D12_RESOURCE_STATE_RENDER_TARGET,
                nullptr, IID_PPV_ARGS(&resource)), "create_scene_target");
            device_->CreateRenderTargetView(resource.Get(), nullptr, rtv(slot));
        };
        target(DXGI_FORMAT_R8G8B8A8_UNORM, 2, color_);
        target(DXGI_FORMAT_R32_FLOAT, 3, depth_);
        target(DXGI_FORMAT_R32G32_FLOAT, 4, motion_);
        auto history = [&](ID3D12Resource* source, ComPtr<ID3D12Resource>& dest) {
            auto desc = source->GetDesc(); desc.Flags = D3D12_RESOURCE_FLAG_NONE;
            D3D12_HEAP_PROPERTIES memory{}; memory.Type = D3D12_HEAP_TYPE_DEFAULT;
            check(device_->CreateCommittedResource(&memory, D3D12_HEAP_FLAG_NONE, &desc, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&dest)), "create_history");
        };
        history(color_.Get(), previousColor_); history(depth_.Get(), previousDepth_);
        backendReady_ = false;
        try {
            interpolator_.initialize(device_.Get(), width_, height_); backendReady_ = true; backendBlocker_.clear();
            log_.event("custom_probe", ",\"status\":\"initialized_requires_execution\"");
        } catch (const std::exception& e) {
            backendBlocker_ = e.what();
            log_.event("custom_probe", ",\"status\":\"failed\",\"blocker\":" + jsonQuote(backendBlocker_));
        }
    }
    void releaseGpu() {
        list_.Reset(); allocator_.Reset();
        scenePipeline_.Reset(); tagPipeline_.Reset(); root_.Reset();
        for (auto& b : buffers_) b.Reset();
        color_.Reset(); depth_.Reset(); motion_.Reset(); heap_.Reset();
        previousColor_.Reset(); previousDepth_.Reset(); interpolator_ = {};
        swap_.Reset(); fence_.Reset(); queue_.Reset(); info_.Reset(); device_.Reset(); adapter_.Reset(); factory_.Reset();
        if (event_) { CloseHandle(event_); event_ = nullptr; }
        fenceValue_ = 0; frameId_ = 0; previousTimestamp_ = -1;
        mfgActive_ = false;
    }
    void pipelines() {
        D3D12_ROOT_PARAMETER parameter{};
        parameter.ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
        parameter.Constants.Num32BitValues = 5;
        parameter.ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
        D3D12_ROOT_SIGNATURE_DESC desc{}; desc.NumParameters = 1; desc.pParameters = &parameter;
        ComPtr<ID3DBlob> serialized, errors;
        check(D3D12SerializeRootSignature(&desc, D3D_ROOT_SIGNATURE_VERSION_1, &serialized, &errors), "serialize_root_signature");
        check(device_->CreateRootSignature(0, serialized->GetBufferPointer(), serialized->GetBufferSize(), IID_PPV_ARGS(&root_)), "create_root_signature");
        D3D12_GRAPHICS_PIPELINE_STATE_DESC p{};
        p.pRootSignature = root_.Get(); p.VS = {SceneVS, sizeof(SceneVS)}; p.PS = {ScenePS, sizeof(ScenePS)};
        p.SampleMask = UINT_MAX; p.SampleDesc.Count = 1;
        p.RasterizerState.FillMode = D3D12_FILL_MODE_SOLID; p.RasterizerState.CullMode = D3D12_CULL_MODE_NONE;
        p.RasterizerState.DepthClipEnable = TRUE;
        p.BlendState.RenderTarget[0].RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
        p.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
        p.NumRenderTargets = 3; p.RTVFormats[0] = DXGI_FORMAT_R8G8B8A8_UNORM;
        p.RTVFormats[1] = DXGI_FORMAT_R32_FLOAT; p.RTVFormats[2] = DXGI_FORMAT_R32G32_FLOAT;
        check(device_->CreateGraphicsPipelineState(&p, IID_PPV_ARGS(&scenePipeline_)), "create_scene_pipeline");
        p.NumRenderTargets = 1; p.RTVFormats[1] = p.RTVFormats[2] = DXGI_FORMAT_UNKNOWN; p.PS = {TagPS, sizeof(TagPS)};
        check(device_->CreateGraphicsPipelineState(&p, IID_PPV_ARGS(&tagPipeline_)), "create_tag_pipeline");
    }
    void initGpu() {
        check(CreateDXGIFactory2(debugActive_ ? DXGI_CREATE_FACTORY_DEBUG : 0, IID_PPV_ARGS(&factory_)), "create_factory");
        adapterNames_.clear(); unsigned hardwareIndex = 0;
        for (UINT index = 0;; ++index) {
            ComPtr<IDXGIAdapter1> candidate;
            auto hr = factory_->EnumAdapterByGpuPreference(index, DXGI_GPU_PREFERENCE_HIGH_PERFORMANCE, IID_PPV_ARGS(&candidate));
            if (hr == DXGI_ERROR_NOT_FOUND) break;
            check(hr, "enumerate_adapter");
            DXGI_ADAPTER_DESC1 desc{}; check(candidate->GetDesc1(&desc), "adapter_description");
            LARGE_INTEGER driver{}; auto driverHr = candidate->CheckInterfaceSupport(__uuidof(IDXGIDevice), &driver);
            ComPtr<ID3D12Device> probe;
            auto deviceHr = D3D12CreateDevice(candidate.Get(), D3D_FEATURE_LEVEL_11_0, IID_PPV_ARGS(&probe));
            log_.event("adapter", ",\"status\":\"observed\",\"name\":" + jsonQuote(utf8(desc.Description)) +
                ",\"vendor_id\":" + std::to_string(desc.VendorId) + ",\"device_id\":" + std::to_string(desc.DeviceId) +
                ",\"luid_high\":" + std::to_string(desc.AdapterLuid.HighPart) + ",\"luid_low\":" + std::to_string(desc.AdapterLuid.LowPart) +
                ",\"software\":" + std::string((desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) ? "true" : "false") +
                ",\"driver_query_hr\":" + jsonQuote(hex(static_cast<uint32_t>(driverHr))) +
                ",\"driver_version\":" + jsonQuote(SUCCEEDED(driverHr) ? std::to_string(HIWORD(driver.HighPart)) + "." + std::to_string(LOWORD(driver.HighPart)) + "." + std::to_string(HIWORD(driver.LowPart)) + "." + std::to_string(LOWORD(driver.LowPart)) : "unknown") +
                ",\"dx12_create_hr\":" + jsonQuote(hex(static_cast<uint32_t>(deviceHr))));
            const bool hardware = !(desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE);
            if (hardware) adapterNames_.push_back(desc.Description);
            if (!device_ && hardware && hardwareIndex == opt_.adapter) {
                check(deviceHr, "selected_adapter_dx12_unsupported");
                adapter_ = candidate; device_ = probe;
                log_.event("adapter_selected", ",\"hardware_index\":" + std::to_string(hardwareIndex) + ",\"name\":" + jsonQuote(utf8(desc.Description)));
            }
            if (hardware) ++hardwareIndex;
        }
        if (!device_) throw std::runtime_error("no_hardware_dx12_device");
        device_.As(&info_);
        D3D12_FEATURE_DATA_D3D12_OPTIONS features{};
        auto featureHr = device_->CheckFeatureSupport(D3D12_FEATURE_D3D12_OPTIONS, &features, sizeof(features));
        D3D_FEATURE_LEVEL levels[]{D3D_FEATURE_LEVEL_12_2, D3D_FEATURE_LEVEL_12_1, D3D_FEATURE_LEVEL_12_0, D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0};
        D3D12_FEATURE_DATA_FEATURE_LEVELS levelData{5, levels, D3D_FEATURE_LEVEL_11_0};
        auto levelHr = device_->CheckFeatureSupport(D3D12_FEATURE_FEATURE_LEVELS, &levelData, sizeof(levelData));
        log_.event("features", ",\"status\":\"observed\",\"options_hr\":" + jsonQuote(hex(static_cast<uint32_t>(featureHr))) +
            ",\"resource_binding_tier\":" + std::to_string(features.ResourceBindingTier) +
            ",\"feature_level_hr\":" + jsonQuote(hex(static_cast<uint32_t>(levelHr))) +
            ",\"max_feature_level\":" + std::to_string(levelData.MaxSupportedFeatureLevel) +
            ",\"native_mfg\":\"not_queried_no_provider\",\"custom_mfg\":\"initial_motion_guided_backend_requires_gpu_execution\"");
        BOOL tearing = FALSE;
        tearing_ = SUCCEEDED(factory_->CheckFeatureSupport(DXGI_FEATURE_PRESENT_ALLOW_TEARING, &tearing, sizeof(tearing))) && tearing;
        D3D12_COMMAND_QUEUE_DESC queueDesc{}; queueDesc.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
        check(device_->CreateCommandQueue(&queueDesc, IID_PPV_ARGS(&queue_)), "create_direct_queue");
        check(device_->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&allocator_)), "create_allocator");
        check(device_->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, allocator_.Get(), nullptr, IID_PPV_ARGS(&list_)), "create_command_list");
        check(list_->Close(), "close_initial_list");
        check(device_->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&fence_)), "create_fence");
        event_ = CreateEventW(nullptr, FALSE, FALSE, nullptr);
        if (!event_) throw std::runtime_error("create_fence_event_failed");
        DXGI_SWAP_CHAIN_DESC1 swapDesc{};
        swapDesc.Width = width_; swapDesc.Height = height_; swapDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        swapDesc.SampleDesc.Count = 1; swapDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        swapDesc.BufferCount = 2; swapDesc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
        swapDesc.Flags = tearing_ ? DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING : 0;
        ComPtr<IDXGISwapChain1> swap;
        check(factory_->CreateSwapChainForHwnd(queue_.Get(), window_, &swapDesc, nullptr, nullptr, &swap), "create_swapchain");
        check(swap.As(&swap_), "swapchain3");
        check(factory_->MakeWindowAssociation(window_, DXGI_MWA_NO_ALT_ENTER), "window_association");
        check(swap_->SetColorSpace1(DXGI_COLOR_SPACE_RGB_FULL_G22_NONE_P709), "set_sdr_color_space");
        D3D12_DESCRIPTOR_HEAP_DESC heapDesc{}; heapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV; heapDesc.NumDescriptors = 5;
        check(device_->CreateDescriptorHeap(&heapDesc, IID_PPV_ARGS(&heap_)), "create_rtv_heap");
        descriptorSize_ = device_->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
        targets();
        pipelines();
        require(contract_.initialize({1, 1, 1, 1}, {1, 1, 1, 1, 1}, output()));
        require(contract_.start());
        log_.event("init", ",\"status\":\"active\",\"mode\":" + jsonQuote(opt_.diagnostic ? "diagnostic_tagged_copy_not_fg" : "pass_through") +
            ",\"hdr\":false,\"max_frames_in_flight\":1,\"tearing_supported\":" + (tearing_ ? "true" : "false"));
        displayChanged_ = true;
        if (adapterControl_) {
            SendMessageW(adapterControl_, CB_RESETCONTENT, 0, 0);
            for (const auto& name : adapterNames_) SendMessageW(adapterControl_, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(name.c_str()));
            SendMessageW(adapterControl_, CB_SETCURSEL, opt_.adapter, 0);
        }
    }
    void resize() {
        pendingResize_ = false;
        if (width_ == pendingWidth_ && height_ == pendingHeight_) return;
        require(contract_.drain()); flush();
        for (auto& b : buffers_) b.Reset();
        color_.Reset(); depth_.Reset(); motion_.Reset();
        check(swap_->ResizeBuffers(2, pendingWidth_, pendingHeight_, DXGI_FORMAT_R8G8B8A8_UNORM,
            tearing_ ? DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING : 0), "resize_buffers");
        width_ = pendingWidth_; height_ = pendingHeight_;
        targets(); require(contract_.recreate(output(), fence_->GetCompletedValue())); require(contract_.start());
        frameId_ = 0; previousTimestamp_ = -1; mfgActive_ = false; ++resizeCount_;
        log_.event("resize", ",\"epoch\":" + std::to_string(contract_.snapshot().epoch) + ",\"width\":" + std::to_string(width_) + ",\"height\":" + std::to_string(height_));
    }
    void display() {
        displayChanged_ = false;
        ComPtr<IDXGIOutput> output;
        if (SUCCEEDED(swap_->GetContainingOutput(&output))) {
            DXGI_OUTPUT_DESC desc{}; check(output->GetDesc(&desc), "output_description");
            DEVMODEW mode{}; mode.dmSize = sizeof(mode);
            const bool observed = EnumDisplaySettingsW(desc.DeviceName, ENUM_CURRENT_SETTINGS, &mode) != FALSE;
            log_.event("display", ",\"refresh_status\":" + jsonQuote(observed ? "observed_integer_hz" : "unavailable") +
                ",\"refresh_hz\":" + std::to_string(observed ? mode.dmDisplayFrequency : 0) + ",\"output_mode\":\"SDR_G22_P709\"");
        }
    }
    int64_t timestamp() const {
        LARGE_INTEGER now{}; QueryPerformanceCounter(&now);
        const auto ticks = now.QuadPart - origin_.QuadPart;
        return (ticks / frequency_.QuadPart) * 1000000000LL + (ticks % frequency_.QuadPart) * 1000000000LL / frequency_.QuadPart;
    }
    void beginCommands() {
        waitGpu(); check(allocator_->Reset(), "reset_allocator"); check(list_->Reset(allocator_.Get(), nullptr), "reset_list");
    }
    void finishCommands() {
        check(list_->Close(), "close_commands"); ID3D12CommandList* commands[]{list_.Get()}; queue_->ExecuteCommandLists(1, commands);
        check(queue_->Signal(fence_.Get(), ++fenceValue_), "commands_signal"); waitGpu();
    }
    void pace(int64_t target) {
        // Source-clock delay supplies evenly spaced output slots; actual display
        // timing is controlled by DXGI and is deliberately not called measured FPS.
        while (timestamp() + 1000000 < target) Sleep(1);
    }
    void present(ID3D12Resource* source, const char* kind, int64_t ns, uint64_t realId, float alpha) {
        beginCommands(); const UINT index = swap_->GetCurrentBackBufferIndex();
        transition(buffers_[index].Get(), D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_COPY_DEST);
        list_->CopyResource(buffers_[index].Get(), source);
        if (opt_.diagnostic) {
            transition(buffers_[index].Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_RENDER_TARGET);
            list_->SetGraphicsRootSignature(root_.Get()); list_->SetPipelineState(tagPipeline_.Get());
            D3D12_VIEWPORT viewport{0, 0, static_cast<float>(width_), static_cast<float>(height_), 0, 1};
            D3D12_RECT rect{0, 0, static_cast<LONG>(width_), static_cast<LONG>(std::min(12u, height_))};
            list_->RSSetViewports(1, &viewport); list_->RSSetScissorRects(1, &rect);
            const auto target = rtv(index); list_->OMSetRenderTargets(1, &target, FALSE, nullptr);
            list_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST); list_->DrawInstanced(3, 1, 0, 0);
            transition(buffers_[index].Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_PRESENT);
        } else transition(buffers_[index].Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_PRESENT);
        check(list_->Close(), "close_present_list"); ID3D12CommandList* commands[]{list_.Get()}; queue_->ExecuteCommandLists(1, commands);
        auto hr = swap_->Present(opt_.vsync ? 1 : 0, !opt_.vsync && tearing_ ? DXGI_PRESENT_ALLOW_TEARING : 0); check(hr, "present");
        if (hr == DXGI_STATUS_OCCLUDED) { occluded_ = true; ++occludedPresents_; } else ++presented_;
        check(queue_->Signal(fence_.Get(), ++fenceValue_), "present_signal"); waitGpu();
        log_.event("frame", ",\"kind\":" + jsonQuote(kind) + ",\"epoch\":" + std::to_string(contract_.snapshot().epoch) +
            ",\"source_real_id\":" + std::to_string(realId) + ",\"output_id\":" + std::to_string(presented_ + occludedPresents_) +
            ",\"timestamp_ns\":" + std::to_string(ns) + ",\"alpha\":" + std::to_string(alpha) + ",\"buffer_index\":" + std::to_string(index) +
            ",\"fence_signaled\":" + std::to_string(fenceValue_) + ",\"fence_completed\":" + std::to_string(fence_->GetCompletedValue()) +
            ",\"queue_depth_after_wait\":0,\"present_status\":" + jsonQuote(hr == DXGI_STATUS_OCCLUDED ? "occluded" : "submitted_to_dxgi"));
    }
    void verifyOutput(ID3D12Resource* source, int expectedLeft, int y, int size, float alpha) {
        // Read back an actual generated GPU scanline, not CPU reference pixels.
        const UINT rowPitch = (width_ * 4 + 255) & ~255u;
        D3D12_RESOURCE_DESC desc{}; desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER; desc.Width = rowPitch;
        desc.Height = 1; desc.DepthOrArraySize = 1; desc.MipLevels = 1; desc.SampleDesc.Count = 1; desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
        D3D12_HEAP_PROPERTIES heap{}; heap.Type = D3D12_HEAP_TYPE_READBACK;
        ComPtr<ID3D12Resource> readback;
        check(device_->CreateCommittedResource(&heap, D3D12_HEAP_FLAG_NONE, &desc, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&readback)), "create_readback");
        beginCommands(); D3D12_TEXTURE_COPY_LOCATION dst{}, src{};
        dst.pResource = readback.Get(); dst.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
        dst.PlacedFootprint.Footprint = {DXGI_FORMAT_R8G8B8A8_UNORM, width_, 1, 1, rowPitch};
        src.pResource = source; src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
        D3D12_BOX box{0, static_cast<UINT>(y + size / 2), 0, width_, static_cast<UINT>(y + size / 2 + 1), 1};
        list_->CopyTextureRegion(&dst, 0, 0, 0, &src, &box); finishCommands();
        const BYTE* pixels = nullptr; D3D12_RANGE range{0, rowPitch};
        check(readback->Map(0, &range, reinterpret_cast<void**>(const_cast<BYTE**>(&pixels))), "map_readback");
        int left = -1, right = -1;
        for (UINT x = 0; x < width_; ++x) if (pixels[x * 4 + 1] > 100) { if (left < 0) left = static_cast<int>(x); right = static_cast<int>(x); }
        D3D12_RANGE noWrite{0, 0}; readback->Unmap(0, &noWrite);
        const bool passed = std::abs(left - expectedLeft) <= 2 && std::abs(right - (expectedLeft + size - 1)) <= 2;
        log_.event("gpu_readback", ",\"status\":" + jsonQuote(passed ? "passed" : "failed") + ",\"alpha\":" + std::to_string(alpha) +
            ",\"expected_left\":" + std::to_string(expectedLeft) + ",\"observed_left\":" + std::to_string(left) + ",\"observed_right\":" + std::to_string(right));
        if (!passed) throw std::runtime_error("generated_image_ground_truth_mismatch");
    }
    void controls(HINSTANCE instance) {
        auto add = [&](const wchar_t* type, const wchar_t* text, DWORD style, int x, int y, int width, int height, int id) {
            HWND h = CreateWindowExW(0, type, text, WS_CHILD | WS_VISIBLE | style, x, y, width, height, window_, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), instance, nullptr);
            if (!h) throw std::runtime_error("create_controls_failed");
            SendMessageW(h, WM_SETFONT, reinterpret_cast<WPARAM>(GetStockObject(DEFAULT_GUI_FONT)), TRUE); controls_.push_back(h); return h;
        };
        add(L"STATIC", L"OptiMFG  |  Standalone controls", SS_LEFT, 16, 16, 340, 24, 0);
        adapterControl_ = add(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL, 16, 44, 340, 200, 103);
        backendControl_ = add(L"COMBOBOX", L"", CBS_DROPDOWNLIST, 16, 76, 240, 100, 104);
        SendMessageW(backendControl_, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"Custom GPU interpolation"));
        SendMessageW(backendControl_, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"Native NVIDIA (not integrated)"));
        SendMessageW(backendControl_, CB_SETCURSEL, 0, 0);
        multiplierControl_ = add(L"COMBOBOX", L"", CBS_DROPDOWNLIST, 264, 76, 92, 150, 105);
        for (const auto* value : {L"2x", L"3x", L"4x", L"5x", L"6x"}) SendMessageW(multiplierControl_, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(value));
        SendMessageW(multiplierControl_, CB_SETCURSEL, opt_.multiplier - 2, 0);
        add(L"BUTTON", L"Toggle MFG", BS_PUSHBUTTON, 16, 108, 160, 30, 101);
        add(L"BUTTON", L"Export Logs", BS_PUSHBUTTON, 184, 108, 172, 30, 102);
        statusControl_ = add(L"STATIC", L"MFG off - real frames only\nSelect a GPU and enable custom MFG.", SS_LEFT, 16, 148, 340, 56, 106);
        exportControl_ = add(L"STATIC", L"Exports are saved in the log's exports folder.", SS_LEFT, 16, 208, 340, 36, 107);
    }
    void requestMfg(bool enabled) {
        mfgRequested_ = enabled; mfgActive_ = false;
        log_.event("mfg_activation", ",\"status\":\"requested\",\"enabled\":" + std::string(enabled ? "true" : "false") +
            ",\"backend\":" + jsonQuote(backendSelection_ == 0 ? "custom_motion_guided" : "native_nvidia") + ",\"multiplier\":" + std::to_string(opt_.multiplier));
        if (!enabled) { log_.event("mfg_activation", ",\"status\":\"inactive\""); SetWindowTextW(statusControl_, L"MFG off - real frames only"); return; }
        log_.event("mfg_activation", ",\"status\":\"attempted\"");
        if (backendSelection_ != 0) {
            log_.event("mfg_activation", ",\"status\":\"failed\",\"blocker\":\"native_provider_not_integrated\",\"hardware_support\":\"not_queried\"");
            SetWindowTextW(statusControl_, L"Native MFG blocked: no provider integrated\nCard support has not been queried.\nSelect Custom to use GPU interpolation.");
        } else if (!backendReady_) {
            log_.event("mfg_activation", ",\"status\":\"failed\",\"blocker\":" + jsonQuote(backendBlocker_));
            SetWindowTextW(statusControl_, L"Custom MFG unavailable on this configuration\nExport Logs for the backend failure reason.\nReal-frame presentation remains active.");
        } else SetWindowTextW(statusControl_, L"Custom MFG requested\nWaiting for two valid real frames...");
    }
    void exportLogs() {
        const auto folder = opt_.log.parent_path() / L"exports";
        std::error_code ec; std::filesystem::create_directories(folder, ec);
        const auto file = folder / (L"OptiMFG-diagnostics-" + std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(GetTickCount64()) + L".jsonl");
        const bool exported = !ec && exportTo(file);
        SetWindowTextW(exportControl_, exported ? L"Log exported successfully.\nSee the exports folder beside the session log." : L"Export failed: folder is not writable.\nThe original session log is still available.");
    }
    bool exportTo(const std::filesystem::path& destination) {
        log_.event("export", ",\"status\":\"attempted\""); std::error_code ec;
        std::filesystem::copy_file(opt_.log, destination, std::filesystem::copy_options::overwrite_existing, ec);
        log_.event("export", ",\"status\":" + jsonQuote(ec ? "failed" : "succeeded") + ",\"error_code\":" + std::to_string(ec.value()));
        if (!ec) {
            // Include the success event in the saved diagnostic snapshot.
            std::filesystem::copy_file(opt_.log, destination, std::filesystem::copy_options::overwrite_existing, ec);
        }
        return !ec;
    }
    void render() {
        waitGpu();
        check(allocator_->Reset(), "reset_allocator"); check(list_->Reset(allocator_.Get(), nullptr), "reset_list");
        if (frameId_) transition(color_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
        const auto renderStart = timestamp();
        // The standalone source has a deterministic 30 Hz simulation clock.
        // GPU startup/validation stalls must not turn into unbounded scene jumps.
        const auto ns = static_cast<int64_t>(submitted_) * 33333333LL;
        const double seconds = static_cast<double>(ns) / 1.0e9;
        const LONG size = static_cast<LONG>(std::max(1u, std::min(width_, height_) / 5));
        const LONG x = static_cast<LONG>((static_cast<double>(width_) - size) * (0.5 + 0.4 * std::sin(seconds * 1.25)));
        const LONG y = static_cast<LONG>(height_ / 2) - size / 2;
        const bool cut = frameId_ == 0;
        const float motion[]{cut ? 0.0f : static_cast<float>(x - previousX_), 0, 0, 0};
        const float constants[]{static_cast<float>(x), static_cast<float>(y), static_cast<float>(x + size), static_cast<float>(y + size), motion[0]};
        list_->SetGraphicsRootSignature(root_.Get()); list_->SetPipelineState(scenePipeline_.Get());
        list_->SetGraphicsRoot32BitConstants(0, 5, constants, 0);
        D3D12_VIEWPORT viewport{0, 0, static_cast<float>(width_), static_cast<float>(height_), 0, 1};
        D3D12_RECT scissor{0, 0, static_cast<LONG>(width_), static_cast<LONG>(height_)};
        list_->RSSetViewports(1, &viewport); list_->RSSetScissorRects(1, &scissor);
        D3D12_CPU_DESCRIPTOR_HANDLE rtvs[]{rtv(2), rtv(3), rtv(4)};
        list_->OMSetRenderTargets(3, rtvs, FALSE, nullptr);
        list_->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST); list_->DrawInstanced(3, 1, 0, 0);
        transition(color_.Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_COPY_SOURCE);
        check(list_->Close(), "close_frame_list");
        auto texture = [&](uint64_t token, DXGI_FORMAT format, omfg::ResourceState state) { return omfg::Texture{true, token, static_cast<uint32_t>(format), width_, height_, state}; };
        omfg::Frame frame{};
        frame.id = frameId_ + 1; frame.epoch = contract_.snapshot().epoch; frame.timestampNs = ns;
        frame.sceneCut = cut; frame.completionFence = fenceValue_ + 1;
        frame.color = texture(1, DXGI_FORMAT_R8G8B8A8_UNORM, omfg::ResourceState::CopySource);
        frame.hudless = frame.color;
        frame.depth = texture(2, DXGI_FORMAT_R32_FLOAT, omfg::ResourceState::RenderTarget);
        frame.motion = texture(3, DXGI_FORMAT_R32G32_FLOAT, omfg::ResourceState::RenderTarget);
        require(contract_.accept(frame));
        ID3D12CommandList* commands[]{list_.Get()}; queue_->ExecuteCommandLists(1, commands);
        check(queue_->Signal(fence_.Get(), ++fenceValue_), "scene_signal"); waitGpu(); ++submitted_;
        const bool generate = mfgRequested_ && backendSelection_ == 0 && backendReady_ && !cut;
        if (generate) {
            int64_t times[5]{};
            const auto count = omfgSchedule(previousTimestamp_, ns, opt_.multiplier, times, 5);
            if (count < 0) throw std::runtime_error("interpolation_timestamp_schedule_failed");
            for (int i = 0; i < count; ++i) {
                const float alpha = static_cast<float>(i + 1) / static_cast<float>(opt_.multiplier);
                beginCommands();
                transition(color_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                transition(previousColor_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                transition(previousDepth_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                transition(depth_.Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                transition(motion_.Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                interpolator_.record(list_.Get(), previousColor_.Get(), color_.Get(), motion_.Get(), previousDepth_.Get(), depth_.Get(), alpha);
                transition(color_.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE);
                transition(previousColor_.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE);
                transition(previousDepth_.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE);
                transition(depth_.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
                transition(motion_.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
                finishCommands();
                if (opt_.verifyReadback) verifyOutput(interpolator_.output(), previousX_ + static_cast<int>(std::round(alpha * (x - previousX_))), y, size, alpha);
                pace(renderStart + static_cast<int64_t>(33333333.0 * alpha));
                present(interpolator_.output(), "generated", times[i], frame.id, alpha);
                ++generated_;
                if (!mfgActive_) {
                    mfgActive_ = true;
                    log_.event("mfg_activation", ",\"status\":\"active\",\"backend\":\"custom_motion_guided\",\"evidence\":\"dispatch_fence_completed\"");
                    SetWindowTextW(statusControl_, L"Custom MFG active\nGPU-generated intermediate frames\nInitial backend: image quality limited");
                }
            }
            pace(renderStart + 33333333);
        }
        if (!generate && opt_.vsync) pace(renderStart + 33333333);
        present(color_.Get(), "real", ns, frame.id, 1);
        // History belongs to the host and is retained until next frame completes.
        beginCommands();
        if (!cut) {
            transition(previousColor_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
            transition(previousDepth_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
        }
        transition(depth_.Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_COPY_SOURCE);
        list_->CopyResource(previousColor_.Get(), color_.Get()); list_->CopyResource(previousDepth_.Get(), depth_.Get());
        transition(depth_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
        transition(previousColor_.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COPY_SOURCE);
        transition(previousDepth_.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COPY_SOURCE);
        finishCommands();
        if (cut) log_.event("bypass", ",\"reason\":\"new_epoch_or_scene_cut\",\"epoch\":" + std::to_string(frame.epoch));
        ++frameId_; previousX_ = x; previousTimestamp_ = ns;
    }
    void recover(bool simulated, HRESULT hr) {
        const HRESULT reason = device_ ? device_->GetDeviceRemovedReason() : hr;
        log_.event("device_loss", ",\"simulated\":" + std::string(simulated ? "true" : "false") +
            ",\"hr\":" + jsonQuote(hex(static_cast<uint32_t>(hr))) + ",\"removal_reason\":" + jsonQuote(hex(static_cast<uint32_t>(reason))));
        if (simulated) flush();
        contract_.deviceLost(); releaseGpu();
        log_.event("recovery", ",\"status\":\"attempted\"");
        initGpu(); ++recoveries_;
        log_.event("recovery", ",\"status\":\"active\"");
    }
public:
    explicit App(Options o) : opt_(std::move(o)), log_(opt_.log) { backendSelection_ = opt_.native ? 1 : 0; }
    ~App() {
        // Normal path drains explicitly; removed-device path cannot wait safely.
        releaseGpu(); if (window_ && IsWindow(window_)) DestroyWindow(window_);
    }
    int run(HINSTANCE instance) {
        log_.event("request", ",\"version\":\"0.2.0\",\"status\":\"requested\",\"custom_mfg\":" + std::string(opt_.mfg ? "true" : "false") + ",\"diagnostic\":" + std::string(opt_.diagnostic ? "true" : "false") +
            ",\"debug\":" + (opt_.debug ? "true" : "false") + ",\"gpu_validation\":" + (opt_.validation ? "true" : "false"));
        log_.event("environment", ",\"windows_kernel_file_version\":" + jsonQuote(windowsVersion()));
        if (opt_.debug) {
            ComPtr<ID3D12Debug> debug;
            auto hr = D3D12GetDebugInterface(IID_PPV_ARGS(&debug));
            if (SUCCEEDED(hr)) {
                debug->EnableDebugLayer(); debugActive_ = true;
                if (opt_.validation) {
                    ComPtr<ID3D12Debug1> extended;
                    if (SUCCEEDED(debug.As(&extended))) { extended->SetEnableGPUBasedValidation(TRUE); validationActive_ = true; }
                }
            }
            log_.event("validation", ",\"debug_active\":" + std::string(debugActive_ ? "true" : "false") + ",\"gpu_validation_active\":" + (validationActive_ ? "true" : "false") + ",\"query_hr\":" + jsonQuote(hex(static_cast<uint32_t>(hr))));
        }
        QueryPerformanceFrequency(&frequency_); QueryPerformanceCounter(&origin_);
        log_.event("clock", ",\"wall_clock\":\"QPC\",\"frequency\":" + std::to_string(frequency_.QuadPart) + ",\"source_timestamps\":\"deterministic_30hz_simulation_ns\",\"source_interval_ns\":33333333,\"output_pacing\":\"QPC_relative_per_source_frame\"");
        WNDCLASSW wc{}; wc.hInstance = instance; wc.lpfnWndProc = proc; wc.lpszClassName = L"OptiMFG_Dx12Host";
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        if (!RegisterClassW(&wc)) throw std::runtime_error("register_window_failed");
        RECT rect{0, 0, static_cast<LONG>(width_), static_cast<LONG>(height_)};
        const DWORD style = opt_.borderless ? WS_POPUP : WS_OVERLAPPEDWINDOW;
        AdjustWindowRect(&rect, style, FALSE);
        window_ = CreateWindowExW(0, wc.lpszClassName, L"OptiMFG | Standalone GPU frame generation | Esc to close",
            style | WS_CLIPCHILDREN, CW_USEDEFAULT, CW_USEDEFAULT, rect.right - rect.left, rect.bottom - rect.top, nullptr, nullptr, instance, this);
        if (!window_) throw std::runtime_error("create_window_failed");
        ShowWindow(window_, SW_SHOW);
        try {
            controls(instance);
            SendMessageW(backendControl_, CB_SETCURSEL, backendSelection_, 0);
            log_.event("init", ",\"status\":\"attempted\""); initGpu();
            requestMfg(opt_.mfg);
            while (!quit_) {
                MSG msg{};
                while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { if (msg.message == WM_QUIT) quit_ = true; TranslateMessage(&msg); DispatchMessageW(&msg); }
                if (quit_ || (opt_.frames && submitted_ >= opt_.frames)) break;
                if (minimized_) { MsgWaitForMultipleObjects(0, nullptr, FALSE, 100, QS_ALLINPUT); continue; }
                try {
                    if (exportRequested_) { exportRequested_ = false; exportLogs(); }
                    if (toggleRequested_) { toggleRequested_ = false; requestMfg(!mfgRequested_); }
                    if (backendChanged_ || multiplierChanged_) {
                        backendChanged_ = multiplierChanged_ = false; requestMfg(mfgRequested_);
                    }
                    if (adapterChangeRequested_) {
                        adapterChangeRequested_ = false;
                        auto selected = static_cast<unsigned>(SendMessageW(adapterControl_, CB_GETCURSEL, 0, 0));
                        if (selected != opt_.adapter) {
                            require(contract_.drain()); flush(); require(contract_.stop(fence_->GetCompletedValue()));
                            releaseGpu(); opt_.adapter = selected; mfgActive_ = false;
                            log_.event("adapter_switch", ",\"status\":\"attempted\",\"hardware_index\":" + std::to_string(selected));
                            initGpu(); requestMfg(mfgRequested_);
                        }
                    }
                    if (pendingResize_) resize();
                    if (displayChanged_) display();
                    if (occluded_) {
                        auto hr = swap_->Present(0, DXGI_PRESENT_TEST); check(hr, "occlusion_test");
                        if (hr == DXGI_STATUS_OCCLUDED) { MsgWaitForMultipleObjects(0, nullptr, FALSE, 100, QS_ALLINPUT); continue; }
                        occluded_ = false;
                    }
                    render();
                    if (!simulationDone_ && opt_.simulateLossAt && submitted_ >= opt_.simulateLossAt) {
                        simulationDone_ = true; recover(true, S_OK);
                    }
                    if (stressDone_ < opt_.stress && submitted_ % 5 == 0) {
                        ++stressDone_;
                        SetWindowPos(window_, nullptr, 0, 0, 800 + (stressDone_ % 2) * 120, 520 + (stressDone_ % 3) * 40, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
                        // Lifecycle stress includes real minimize/restore; it does not claim an Alt-Tab test.
                        if (stressDone_ % 10 == 0) { ShowWindow(window_, SW_MINIMIZE); ShowWindow(window_, SW_SHOWNOACTIVATE); }
                        log_.event("stress_action", ",\"resize_request\":" + std::to_string(stressDone_) + ",\"minimize_restore\":" + (stressDone_ % 10 == 0 ? "true" : "false"));
                    }
                } catch (const HrError& e) {
                    if ((e.hr == DXGI_ERROR_DEVICE_REMOVED || e.hr == DXGI_ERROR_DEVICE_RESET || e.hr == DXGI_ERROR_DEVICE_HUNG) && recoveryAttempts_++ < 2) recover(false, e.hr);
                    else throw;
                }
            }
            require(contract_.drain()); flush(); require(contract_.stop(fence_->GetCompletedValue()));
            log_.event("shutdown", ",\"status\":\"stopped\",\"real_submitted\":" + std::to_string(submitted_) +
                ",\"present_calls_succeeded\":" + std::to_string(presented_) + ",\"occluded_presents\":" + std::to_string(occludedPresents_) +
                ",\"generated_frames\":" + std::to_string(generated_) + ",\"displayed_frame_count\":null,\"display_dropped_frames\":null,\"host_dropped_frames\":0,\"resizes\":" + std::to_string(resizeCount_) +
                ",\"stress_actions\":" + std::to_string(stressDone_) + ",\"recoveries\":" + std::to_string(recoveries_) +
                ",\"debug_errors\":" + std::to_string(debugErrors_) + ",\"debug_warnings\":" + std::to_string(debugWarnings_));
            if (!opt_.exportLog.empty() && !exportTo(opt_.exportLog)) return 4;
            return debugErrors_ ? 3 : 0;
        } catch (const HrError& e) {
            log_.event("failure", ",\"status\":\"failed\",\"operation\":" + jsonQuote(e.what()) + ",\"hr\":" + jsonQuote(hex(static_cast<uint32_t>(e.hr))));
            contract_.deviceLost(); return 1;
        } catch (const std::exception& e) {
            log_.event("failure", ",\"status\":\"failed\",\"operation\":" + jsonQuote(e.what()));
            // Try to drain an otherwise healthy device before releasing its resources.
            try { flush(); } catch (...) {}
            contract_.deviceLost(); return 1;
        }
    }
};
}
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int) {
    try { App app(options()); return app.run(instance); }
    catch (const std::exception&) {
        OutputDebugStringW(L"OptiMFG: startup failed (arguments, log, or window). See README.\n");
        return 2;
    }
}
