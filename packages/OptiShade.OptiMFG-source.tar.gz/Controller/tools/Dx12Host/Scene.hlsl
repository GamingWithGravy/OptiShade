// Independently authored diagnostic ground truth, not an interpolator.
cbuffer Scene : register(b0) { float4 bounds; float motionX; };
float4 SceneVS(uint id : SV_VertexID) : SV_Position {
    float2 p = float2((id << 1) & 2, id & 2);
    return float4(p * float2(2, -2) + float2(-1, 1), 0, 1);
}
struct Targets { float4 color : SV_Target0; float depth : SV_Target1; float2 motion : SV_Target2; };
Targets ScenePS(float4 position : SV_Position) {
    bool inside = all(position.xy >= bounds.xy) && all(position.xy < bounds.zw);
    Targets o;
    o.color = inside ? float4(0.08, 0.8, 0.7, 1) : float4(0.025, 0.045, 0.075, 1);
    o.depth = inside ? 0.25 : 1;
    o.motion = inside ? float2(motionX, 0) : float2(0, 0);
    return o;
}
float4 TagPS() : SV_Target0 { return float4(1, 0.65, 0, 1); }
