#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include <OptiMFG/DriverController.hpp>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <string>

using namespace omfg::driver;
namespace fs = std::filesystem;
struct App {
    HWND window{}, target{}, mode{}, current{}, status{}, hardware{};
    fs::path directory, logPath, backup;
    std::ofstream log;
    std::unique_ptr<Controller> controller;
    std::optional<Snapshot> reviewed;
    std::wstring reviewedExe;
    unsigned sequence{};
    void Event(std::string const& event, std::string const& fields = "") {
        log << "{\"sequence\":" << ++sequence << ",\"tick_ms\":" << GetTickCount64() << ",\"event\":" << Json(event) << fields << "}\n";
        log.flush(); if (!log) throw std::runtime_error("Cannot write session log");
    }
    void Status(std::wstring const& value) { if(status) SetWindowTextW(status,value.c_str()); }
    void Error(std::exception const& error) {
        try { Event("error",",\"message\":"+Json(error.what())); } catch(...) {}
        Status(L"Operation failed: "+Wide(error.what())+L"\r\nExport logs for diagnosis. For access denied, restart this app as administrator.");
    }
    std::wstring Exe() {
        int length=GetWindowTextLengthW(target); std::wstring text(static_cast<size_t>(length)+1,0);
        GetWindowTextW(target,text.data(),length+1); text.resize(length);
        auto name=fs::path(text).filename().wstring();
        if (_wcsicmp(name.c_str(),L"FlightSimulator2024.exe") && _wcsicmp(name.c_str(),L"FlightSimulator.exe"))
            throw std::runtime_error("Choose FlightSimulator2024.exe or FlightSimulator.exe");
        return text;
    }
    void Initialize() {
        controller=std::make_unique<Controller>(directory/L"backups",[this](auto const& e, auto const& f){Event(e,f);});
        auto text=controller->Hardware(); if(hardware) SetWindowTextW(hardware,text.c_str());
    }
    void Refresh() {
        reviewed.reset(); if(!controller) Initialize();
        auto executable=Exe(); auto snapshot=controller->Read(executable);
        reviewed=snapshot; reviewedExe=executable;
        auto const& v=snapshot.values;
        std::wstring modeText;
        switch(v[0].value) {
            case 0: modeText=L"Application controlled"; break;
            case 1: modeText=L"FG off requested"; break;
            case 2: modeText=L"FG on requested"; break;
            case 3: modeText=L"Auto"; break;
            case 4: modeText=L"Dynamic"; break;
            default: modeText=L"Unrecognized driver mode "+std::to_wstring(v[0].value);
        }
        std::wstring text=L"Driver profile: "+snapshot.profile+L"\r\nSaved mode: "+modeText;
        text += L" | Fixed count: "+std::to_wstring(v[1].value)+L" generated per real frame";
        text += L"\r\nModel override: "+std::to_wstring(v[2].value)+L" | Preset: "+std::to_wstring(v[3].value);
        text += L"\r\nReadback confirms stored settings only. Game activation is not measured.";
        SetWindowTextW(current,text.c_str());
        Status(SimulatorRunning()?L"MSFS is running. Close it before Apply or Restore.":L"Ready. Choose a requested mode, then Apply. Settings persist after this controller closes.");
    }
    std::optional<fs::path> Browse(bool restore) {
        wchar_t path[32768]{}; OPENFILENAMEW ofn{}; ofn.lStructSize=sizeof(ofn); ofn.hwndOwner=window;
        ofn.lpstrFile=path; ofn.nMaxFile=ARRAYSIZE(path); ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
        ofn.lpstrFilter=restore?L"OptiMFG backups\0*.omfgbackup\0\0":L"Simulator executable\0FlightSimulator2024.exe;FlightSimulator.exe\0\0";
        auto folder=(directory/L"backups").wstring(); if(restore) ofn.lpstrInitialDir=folder.c_str();
        ofn.lpstrTitle=restore?L"Choose the backup to restore":L"Choose the MSFS executable";
        if(GetOpenFileNameW(&ofn)) return fs::path(path);
        if(CommDlgExtendedError()) throw std::runtime_error("File selection failed"); return {};
    }
    void Apply() {
        auto executable=Exe();
        if(!controller || !reviewed || executable!=reviewedExe) throw std::runtime_error("Refresh the selected executable before applying");
        auto selection=SendMessageW(mode,CB_GETCURSEL,0,0);
        if(selection<0||selection>6) throw std::runtime_error("Choose an MFG mode");
        backup=controller->Apply(executable,static_cast<Mode>(selection),*reviewed);
        Refresh();
        Status(L"Saved and verified in a fresh driver session. Relaunch MSFS to test.\r\nRuntime MFG is unverified. Backup: "+backup.wstring());
    }
    void Restore(bool choose) {
        if(choose || backup.empty()) { auto picked=Browse(true); if(!picked) return; backup=*picked; }
        if(!controller) Initialize(); controller->Restore(Exe(),backup); Refresh();
        Status(L"Previous MFG settings restored and verified. Relaunch MSFS to test.");
    }
    void Export() {
        auto destination=directory/L"exports"/(L"OptiMFG-controller-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64())+L".jsonl");
        fs::create_directories(destination.parent_path()); log.flush();
        fs::copy_file(logPath,destination,fs::copy_options::none);
        Event("export_succeeded",",\"file\":"+Json(Utf8(destination.filename().wstring())));
        Status(L"Exported: "+destination.wstring());
    }
};
static App* app{};
static LRESULT CALLBACK Procedure(HWND window,UINT msg,WPARAM wp,LPARAM lp) {
    try {
        if(msg==WM_COMMAND) {
            switch(LOWORD(wp)) {
                case 1: app->Refresh(); break;
                case 2: { auto path=app->Browse(false); if(path){SetWindowTextW(app->target,path->c_str());app->Refresh();} break; }
                case 3: app->Apply(); break;
                case 4: app->Restore(false); break;
                case 5: app->Restore(true); break;
                case 6: app->Export(); break;
                case 7: ShellExecuteW(window,L"open",app->directory.c_str(),nullptr,nullptr,SW_SHOWNORMAL); break;
            }
            return 0;
        }
        if(msg==WM_DESTROY){PostQuitMessage(0);return 0;}
    }catch(std::exception const& e){app->Error(e);}
    return DefWindowProcW(window,msg,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR,int show) {
    App state; app=&state; bool commandLine=false;
    struct MutexGuard { HANDLE handle{}; ~MutexGuard(){if(handle)CloseHandle(handle);} } instanceLock;
    try {
        wchar_t local[32768]{}; auto count=GetEnvironmentVariableW(L"LOCALAPPDATA",local,ARRAYSIZE(local));
        if(!count||count>=ARRAYSIZE(local)) throw std::runtime_error("LOCALAPPDATA unavailable");
        state.directory=fs::path(local)/L"OptiMFG"/L"controller"; fs::create_directories(state.directory);
        bool selfTest=false,probe=false,applicationControl=false; std::wstring executable=L"FlightSimulator2024.exe";
        int argc{}; auto argv=CommandLineToArgvW(GetCommandLineW(),&argc);
        for(int i=1;i<argc;++i) {
            std::wstring arg=argv[i];
            if(arg==L"--self-test") {selfTest=true;commandLine=true;}
            else if(arg==L"--probe") {probe=true;commandLine=true;}
            else if(arg==L"--application-control") {applicationControl=true;commandLine=true;}
            else if(arg==L"--log"&&i+1<argc) state.logPath=fs::absolute(argv[++i]);
            else if(arg==L"--exe"&&i+1<argc) executable=argv[++i];
            else {LocalFree(argv);throw std::runtime_error("Options: --probe | --self-test, --log path, --exe simulator.exe");}
        }
        LocalFree(argv);
        if(state.logPath.empty()) state.logPath=state.directory/(L"session-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64())+L".jsonl");
        fs::create_directories(state.logPath.parent_path()); state.log.open(state.logPath);
        state.Event("session_started",",\"version\":\"0.4.0-controller\",\"backend\":\"nvidia_driver_profile\",\"runtime_mfg_verified\":false");
        instanceLock.handle=CreateMutexW(nullptr,FALSE,L"Local\\OptiMFG.DriverController");
        if(!instanceLock.handle || GetLastError()==ERROR_ALREADY_EXISTS) throw std::runtime_error("Another OptiMFG controller is open. Close it before starting this one");
        if(static_cast<int>(selfTest)+static_cast<int>(probe)+static_cast<int>(applicationControl)>1)throw std::runtime_error("Choose one command-line action");
        if(selfTest||probe||applicationControl) {
            state.Initialize();
            if(selfTest) state.controller->SelfTest();
            else if(applicationControl){auto reviewed=state.controller->Read(executable);state.controller->Apply(executable,Mode::Application,reviewed);}
            else state.controller->Read(executable);
            state.Event("session_finished",",\"success\":true"); return 0;
        }
        WNDCLASSW wc{}; wc.hInstance=instance; wc.lpfnWndProc=Procedure; wc.lpszClassName=L"OptiMFGDriverController";
        wc.hCursor=LoadCursorW(nullptr,IDC_ARROW); wc.hbrBackground=reinterpret_cast<HBRUSH>(COLOR_BTNFACE+1); RegisterClassW(&wc);
        state.window=CreateWindowW(wc.lpszClassName,L"OptiMFG | External MFG controller",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,
            CW_USEDEFAULT,CW_USEDEFAULT,970,650,nullptr,nullptr,instance,nullptr);
        if(!state.window) throw std::runtime_error("Cannot create controller window");
        auto add=[&](wchar_t const* cls,wchar_t const* text,DWORD style,int x,int y,int w,int h,int id=0){
            auto control=CreateWindowW(cls,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,state.window,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),instance,nullptr);
            SendMessageW(control,WM_SETFONT,reinterpret_cast<WPARAM>(GetStockObject(DEFAULT_GUI_FONT)),TRUE); return control;
        };
        add(L"STATIC",L"MSFS driver-profile controller | NVIDIA backend",0,16,14,900,22);
        state.hardware=add(L"STATIC",L"Detecting NVIDIA driver...",0,16,42,900,36);
        state.target=add(L"EDIT",executable.c_str(),WS_BORDER|ES_AUTOHSCROLL|WS_TABSTOP,16,84,650,26);
        add(L"BUTTON",L"Choose EXE",WS_TABSTOP,680,82,120,30,2); add(L"BUTTON",L"Refresh",WS_TABSTOP,810,82,120,30,1);
        state.current=add(L"STATIC",L"No profile loaded",0,16,128,910,94);
        add(L"STATIC",L"Requested mode (hardware and game support still apply)",0,16,235,680,22);
        state.mode=add(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,16,262,360,250);
        for(auto label:{L"Application controlled",L"Frame generation OFF",L"2x total (1 generated frame)",L"3x total (2 generated frames)",L"4x total (3 generated frames)",L"5x total (4 generated frames)",L"6x total (5 generated frames)"})
            SendMessageW(state.mode,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label));
        SendMessageW(state.mode,CB_SETCURSEL,0,0);
        add(L"BUTTON",L"Apply + verify",WS_TABSTOP,390,260,145,32,3);
        add(L"BUTTON",L"Undo last apply",WS_TABSTOP,548,260,155,32,4);
        add(L"BUTTON",L"Restore backup...",WS_TABSTOP,716,260,180,32,5);
        add(L"STATIC",L"For ON tests: enable DLSS Frame Generation in MSFS, then exit the game. Apply here and relaunch.\r\nFixed modes also request the latest FG model. Use Undo to recover your previous settings.\r\nRTX 40-series native FG is normally 2x; higher multipliers require supported hardware/game/driver.\r\nThis changes real driver settings. It does not inject OptiMFG or unlock unsupported GPUs.",0,16,312,910,90);
        state.status=add(L"STATIC",L"",0,16,416,910,112);
        add(L"BUTTON",L"Export logs",WS_TABSTOP,16,550,150,32,6);
        add(L"BUTTON",L"Open logs / backups",WS_TABSTOP,180,550,200,32,7);
        try{state.Refresh();}catch(std::exception const& e){state.Error(e);}
        ShowWindow(state.window,show);
        MSG message{}; while(GetMessageW(&message,nullptr,0,0)>0){if(!IsDialogMessageW(state.window,&message)){TranslateMessage(&message);DispatchMessageW(&message);}}
        state.Event("session_finished",",\"success\":true"); return 0;
    }catch(std::exception const& e){
        state.Error(e);
        if(!commandLine) MessageBoxW(nullptr,Wide(e.what()).c_str(),L"OptiMFG controller",MB_ICONERROR);
        return 1;
    }
}
