// Independent external window capture. No injection, engine hooks or Optishade dependency.
#include <windows.h>
#include <shellapi.h>
#include <d3d11.h>
#include <dxgi.h>
#include <windows.graphics.capture.interop.h>
#include <windows.graphics.directx.direct3d11.interop.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <winrt/Windows.Graphics.DirectX.Direct3D11.h>
#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <thread>
#include <future>

using namespace winrt;
using namespace winrt::Windows::Graphics;
using namespace winrt::Windows::Graphics::Capture;
using namespace winrt::Windows::Graphics::DirectX;
using namespace winrt::Windows::Graphics::DirectX::Direct3D11;
namespace fs = std::filesystem;

struct Target { HWND window{}; DWORD pid{}; std::wstring exe; };
static std::wstring Executable(HWND w, DWORD& pid) {
    GetWindowThreadProcessId(w, &pid);
    HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!p) return {};
    wchar_t path[32768]; DWORD count = ARRAYSIZE(path);
    bool ok = QueryFullProcessImageNameW(p, 0, path, &count) != FALSE;
    CloseHandle(p);
    return ok ? fs::path(std::wstring(path, count)).filename().wstring() : L"";
}
static bool IsSimulator(std::wstring const& exe) {
    return _wcsicmp(exe.c_str(), L"FlightSimulator2024.exe") == 0 ||
           _wcsicmp(exe.c_str(), L"FlightSimulator.exe") == 0;
}
static std::string Quote(std::string const& s) {
    std::string r = "\"";
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += static_cast<char>(c); }
        else if (c < 32) r += ' ';
        else r += static_cast<char>(c);
    }
    return r + "\"";
}
struct App {
    HWND window{}, combo{}, status{}, source{};
    bool selfTest{}, failed{}, resized{}, restarted{}, closedTest{}, sawResize{};
    unsigned frameCount{}, changes{}, sourceTick{}, framesBeforeRestart{};
    uint64_t previousHash{}, begun{}, lastFrameAt{}, exportStatusUntil{};
    int width{}, height{}, poolWidth{}, poolHeight{};
    int64_t previousTime{};
    std::vector<Target> targets;
    Target selected;
    fs::path logPath, exportPath;
    std::ofstream log;
    std::vector<uint8_t> pixels;
    com_ptr<ID3D11Device> device;
    com_ptr<ID3D11DeviceContext> context;
    com_ptr<ID3D11Texture2D> staging;
    IDirect3DDevice rtDevice{nullptr};
    GraphicsCaptureItem item{nullptr};
    Direct3D11CaptureFramePool pool{nullptr};
    GraphicsCaptureSession session{nullptr};
    void Event(std::string const& name, std::string const& fields = "") {
        log << "{\"event\":" << Quote(name) << ",\"tick_ms\":" << GetTickCount64()
            << fields << "}\n"; log.flush();
        if (!log) throw std::runtime_error("Could not write diagnostic log");
    }
    void Status(std::wstring const& s) { SetWindowTextW(status, s.c_str()); }
    void Refresh() {
        targets.clear(); SendMessageW(combo, CB_RESETCONTENT, 0, 0);
        EnumWindows([](HWND w, LPARAM arg) -> BOOL {
            auto& a = *reinterpret_cast<App*>(arg);
            if (!IsWindowVisible(w) || GetWindow(w, GW_OWNER)) return TRUE;
            DWORD pid{}; auto exe = Executable(w, pid);
            if (IsSimulator(exe)) a.targets.push_back({w, pid, exe});
            return TRUE;
        }, reinterpret_cast<LPARAM>(this));
        if (selfTest && source) targets.push_back({source, GetCurrentProcessId(), L"self-test"});
        for (auto const& t : targets) {
            auto label = t.exe + L" (PID " + std::to_wstring(t.pid) + L", window " +
                         std::to_wstring(reinterpret_cast<uintptr_t>(t.window)) + L")";
            SendMessageW(combo, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(label.c_str()));
        }
        SendMessageW(combo, CB_SETCURSEL, 0, 0);
        if (!session) Status(targets.empty() ? L"Waiting for MSFS. Open the simulator, then click Refresh." : L"Select the simulator window and click Start capture.");
        Event("targets_refreshed", ",\"count\":" + std::to_string(targets.size()));
    }
    void Stop(std::string const& reason) {
        if (session) { session.Close(); session = nullptr; }
        if (pool) { pool.Close(); pool = nullptr; }
        item = nullptr; staging = nullptr;
        pixels.clear(); width = height = 0; previousTime = 0;
        Event("capture_stopped", ",\"reason\":" + Quote(reason));
        Status(L"Capture stopped. MFG inactive: captured color has no engine depth or motion.");
        InvalidateRect(window, nullptr, FALSE);
    }
    void Start() {
        auto n = SendMessageW(combo, CB_GETCURSEL, 0, 0);
        if (n < 0 || static_cast<size_t>(n) >= targets.size()) { Status(L"No simulator window found. Open MSFS, then Refresh."); return; }
        if (session) Stop("restart");
        selected = targets[static_cast<size_t>(n)];
        DWORD pid{}; auto exe = Executable(selected.window, pid);
        if (!IsWindow(selected.window) || pid != selected.pid ||
            (!(selfTest && selected.window == source) && (!IsSimulator(exe) || exe != selected.exe)))
            throw std::runtime_error("Selected simulator window changed; refresh the list");
        if (!GraphicsCaptureSession::IsSupported()) throw std::runtime_error("Windows Graphics Capture is unsupported");
        if (!device) {
            D3D_FEATURE_LEVEL level{};
            check_hresult(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr,
                D3D11_CREATE_DEVICE_BGRA_SUPPORT, nullptr, 0, D3D11_SDK_VERSION,
                device.put(), &level, context.put()));
            com_ptr<IInspectable> inspectable;
            check_hresult(CreateDirect3D11DeviceFromDXGIDevice(device.as<IDXGIDevice>().get(), inspectable.put()));
            rtDevice = inspectable.as<IDirect3DDevice>();
            com_ptr<IDXGIAdapter> adapter; check_hresult(device.as<IDXGIDevice>()->GetAdapter(adapter.put()));
            DXGI_ADAPTER_DESC desc{}; check_hresult(adapter->GetDesc(&desc));
            Event("capture_device", ",\"adapter\":" + Quote(to_string(desc.Description)) +
                ",\"vendor_id\":" + std::to_string(desc.VendorId) + ",\"device_id\":" + std::to_string(desc.DeviceId));
        }
        auto interop = get_activation_factory<GraphicsCaptureItem, IGraphicsCaptureItemInterop>();
        check_hresult(interop->CreateForWindow(selected.window, guid_of<GraphicsCaptureItem>(), put_abi(item)));
        auto size = item.Size(); poolWidth = size.Width; poolHeight = size.Height;
        pool = Direct3D11CaptureFramePool::CreateFreeThreaded(rtDevice, DirectXPixelFormat::B8G8R8A8UIntNormalized, 2, size);
        session = pool.CreateCaptureSession(item);
        session.IsCursorCaptureEnabled(false);
        session.StartCapture(); lastFrameAt = GetTickCount64(); previousTime = 0;
        Event("capture_started", ",\"source_kind\":" + Quote(selfTest ? "self_test" : "simulator_window") +
            ",\"source_exe\":" + Quote(to_string(selected.exe)) + ",\"source_pid\":" + std::to_string(selected.pid) +
            ",\"api\":\"Windows.Graphics.Capture\",\"pixel_format\":\"BGRA8\",\"hdr_validated\":false,\"depth_available\":false,\"motion_available\":false,\"hudless_available\":false,\"mfg_active\":false,\"generated_frames\":0,\"blocker\":\"engine_motion_and_depth_unavailable\",\"native_support_queried\":false");
        Status(L"Capturing at up to 10 previews/sec. MFG inactive: depth and motion unavailable.");
    }
    void Poll() {
        if (!session) return;
        if (!IsWindow(selected.window)) { Stop("source_closed"); closedTest = true; return; }
        auto frame = pool.TryGetNextFrame();
        if (!frame) {
            if (GetTickCount64() - lastFrameAt > 5000) Status(L"No recent frames. Source may be minimized, blocked or idle; restore it.");
            return;
        }
        auto size = frame.ContentSize();
        if (size.Width <= 0 || size.Height <= 0) { frame.Close(); return; }
        auto timestamp = frame.SystemRelativeTime().count();
        if (previousTime && timestamp <= previousTime) Event("nonincreasing_source_timestamp");
        previousTime = timestamp;
        {
            auto access = frame.Surface().as<::Windows::Graphics::DirectX::Direct3D11::IDirect3DDxgiInterfaceAccess>();
            com_ptr<ID3D11Texture2D> texture;
            check_hresult(access->GetInterface(__uuidof(ID3D11Texture2D), texture.put_void()));
            D3D11_TEXTURE2D_DESC desc{}; texture->GetDesc(&desc);
            if (desc.Format != DXGI_FORMAT_B8G8R8A8_UNORM) throw std::runtime_error("Unexpected captured pixel format");
            // Map waits for CopyResource completion. The captured frame stays alive until both finish.
            D3D11_TEXTURE2D_DESC old{}; if (staging) staging->GetDesc(&old);
            if (!staging || old.Width != desc.Width || old.Height != desc.Height) {
                staging = nullptr; auto stagingDesc = desc;
                stagingDesc.Usage = D3D11_USAGE_STAGING; stagingDesc.BindFlags = 0;
                stagingDesc.MiscFlags = 0; stagingDesc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
                check_hresult(device->CreateTexture2D(&stagingDesc, nullptr, staging.put()));
            }
            context->CopyResource(staging.get(), texture.get());
            int w = std::min(size.Width, static_cast<int>(desc.Width));
            int h = std::min(size.Height, static_cast<int>(desc.Height));
            // Allocate before Map so allocation failure cannot leave a resource mapped.
            pixels.resize(static_cast<size_t>(w) * h * 4);
            D3D11_MAPPED_SUBRESOURCE mapped{};
            check_hresult(context->Map(staging.get(), 0, D3D11_MAP_READ, 0, &mapped));
            for (int y = 0; y < h; ++y)
                memcpy(pixels.data() + static_cast<size_t>(y) * w * 4,
                    static_cast<uint8_t*>(mapped.pData) + static_cast<size_t>(y) * mapped.RowPitch, static_cast<size_t>(w) * 4);
            context->Unmap(staging.get(), 0); width = w; height = h;
        }
        frame.Close(); frame = nullptr;
        if (size.Width != poolWidth || size.Height != poolHeight) {
            pool.Recreate(rtDevice, DirectXPixelFormat::B8G8R8A8UIntNormalized, 2, size);
            poolWidth = size.Width; poolHeight = size.Height; sawResize = true;
            Event("capture_resized", ",\"width\":" + std::to_string(poolWidth) + ",\"height\":" + std::to_string(poolHeight));
        }
        uint64_t hash = 14695981039346656037ull;
        for (size_t i = 0; i < pixels.size(); i += 16) { hash ^= pixels[i]; hash *= 1099511628211ull; }
        if (frameCount && hash != previousHash) ++changes;
        previousHash = hash; ++frameCount; lastFrameAt = GetTickCount64();
        Event("color_frame_readback", ",\"number\":" + std::to_string(frameCount) + ",\"source_time_100ns\":" + std::to_string(timestamp) +
            ",\"width\":" + std::to_string(width) + ",\"height\":" + std::to_string(height) +
            ",\"sample_hash\":" + Quote(std::to_string(hash)) + ",\"gpu_copy_completed\":true,\"generated\":false");
        if (GetTickCount64() > exportStatusUntil)
            Status(L"Live color preview | Captured " + std::to_wstring(frameCount) + L" | MFG inactive: no depth/motion");
        InvalidateRect(window, nullptr, FALSE);
    }
    void Export() {
        fs::path destination = exportPath;
        if (destination.empty()) destination = logPath.parent_path() / L"exports" /
            (L"OptiMFG-capture-" + std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(GetTickCount64()) + L".jsonl");
        fs::create_directories(destination.parent_path());
        log.flush();
        fs::copy_file(logPath, destination, fs::copy_options::overwrite_existing);
        Event("log_exported", ",\"file\":" + Quote(to_string(destination.filename().wstring())));
        Status(L"Logs exported: " + destination.wstring());
        exportStatusUntil = GetTickCount64() + 15000;
    }
    void Paint() {
        PAINTSTRUCT ps{}; HDC dc = BeginPaint(window, &ps);
        RECT r{}; GetClientRect(window, &r); r.top = 104;
        FillRect(dc, &r, static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));
        if (!pixels.empty() && width && height && r.bottom > r.top) {
            double scale = std::min(static_cast<double>(r.right) / width, static_cast<double>(r.bottom-r.top) / height);
            int w = static_cast<int>(width * scale), h = static_cast<int>(height * scale);
            BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
            bi.bmiHeader.biWidth = width; bi.bmiHeader.biHeight = -height;
            bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
            StretchDIBits(dc, (r.right-w)/2, r.top+(r.bottom-r.top-h)/2, w, h, 0, 0, width, height,
                pixels.data(), &bi, DIB_RGB_COLORS, SRCCOPY);
        }
        EndPaint(window, &ps);
    }
    void Failure(std::string const& message) {
        failed = true;
        try { Stop("error"); Event("error", ",\"message\":" + Quote(message)); } catch (...) {}
        Status(L"Capture error: " + std::wstring(to_hstring(message)) + L". Export logs for diagnosis.");
        if (selfTest) PostMessageW(window, WM_CLOSE, 0, 0);
    }
};
static App* app{};
static LRESULT CALLBACK SourceProc(HWND w, UINT m, WPARAM wp, LPARAM lp) {
    static unsigned tick{};
    if (m == WM_TIMER) { ++tick; InvalidateRect(w, nullptr, FALSE); return 0; }
    if (m == WM_DESTROY) { PostQuitMessage(0); return 0; }
    if (m == WM_PAINT) {
        PAINTSTRUCT ps{}; auto dc = BeginPaint(w, &ps); RECT r{}; GetClientRect(w, &r);
        auto brush = CreateSolidBrush(RGB(tick % 255, 60, (tick * 3) % 255)); FillRect(dc, &r, brush); DeleteObject(brush);
        SetTextColor(dc, RGB(255,255,255)); SetBkMode(dc, TRANSPARENT);
        DrawTextW(dc, L"OptiMFG controlled capture test (not MSFS)", -1, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        EndPaint(w, &ps); return 0;
    }
    return DefWindowProcW(w, m, wp, lp);
}
static LRESULT CALLBACK WindowProc(HWND w, UINT m, WPARAM wp, LPARAM lp) {
    try {
        if (m == WM_GETMINMAXINFO) {
            auto info = reinterpret_cast<MINMAXINFO*>(lp);
            info->ptMinTrackSize = {960, 400}; return 0;
        }
        if (m == WM_COMMAND) {
            switch (LOWORD(wp)) {
                case 1: app->Refresh(); break;
                case 2: app->Start(); break;
                case 3: app->Stop("user"); break;
                case 4: app->Export(); break;
            }
            return 0;
        }
        if (m == WM_TIMER) {
            if (app->selfTest) {
                ++app->sourceTick;
                if (app->source) InvalidateRect(app->source, nullptr, FALSE);
                auto elapsed = GetTickCount64() - app->begun;
                if (elapsed > 2000 && !app->resized) {
                    SetWindowPos(app->source, nullptr, 0, 0, 570, 350, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE); app->resized = true;
                }
                if (elapsed > 4000 && !app->restarted) {
                    app->framesBeforeRestart = app->frameCount;
                    app->Stop("self_test_restart"); app->Start(); app->restarted = true;
                }
                if (elapsed > 6500 && app->source) { PostMessageW(app->source, WM_CLOSE, 0, 0); app->source = nullptr; }
                if (elapsed > 8000) {
                    bool passed = app->frameCount >= 20 && app->changes >= 10 && app->sawResize && app->closedTest &&
                        app->frameCount > app->framesBeforeRestart + 5 && !app->failed;
                    app->Event("self_test_result", std::string(",\"passed\":") + (passed ? "true" : "false") +
                        ",\"captured_frames\":" + std::to_string(app->frameCount) + ",\"changed_samples\":" + std::to_string(app->changes) +
                        ",\"resize_observed\":" + (app->sawResize ? "true" : "false") + ",\"source_close_observed\":" + (app->closedTest ? "true" : "false"));
                    app->failed = !passed; app->Export(); PostMessageW(w, WM_CLOSE, 0, 0); return 0;
                }
            }
            app->Poll(); return 0;
        }
        if (m == WM_PAINT) { app->Paint(); return 0; }
        if (m == WM_DESTROY) { KillTimer(w, 1); app->Stop("app_exit"); PostQuitMessage(app->failed ? 1 : 0); return 0; }
    } catch (hresult_error const& e) { app->Failure(to_string(e.message()) + " HRESULT=" + std::to_string(static_cast<uint32_t>(e.code().value))); }
      catch (std::exception const& e) { app->Failure(e.what()); }
    return DefWindowProcW(w, m, wp, lp);
}
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    try {
        init_apartment(apartment_type::multi_threaded);
        App a; app = &a;
        int argc{}; auto argv = CommandLineToArgvW(GetCommandLineW(), &argc);
        for (int i = 1; i < argc; ++i) {
            std::wstring arg = argv[i];
            if (arg == L"--self-test") a.selfTest = true;
            else if (arg == L"--log" && i+1 < argc) a.logPath = fs::absolute(argv[++i]);
            else if (arg == L"--export-log" && i+1 < argc) a.exportPath = fs::absolute(argv[++i]);
            else { LocalFree(argv); throw std::runtime_error("Usage: OptiMFG_MsfsCapture [--self-test] [--log path] [--export-log path]"); }
        }
        LocalFree(argv);
        if (a.logPath.empty()) {
            wchar_t dir[32768]; DWORD n = GetEnvironmentVariableW(L"LOCALAPPDATA", dir, ARRAYSIZE(dir));
            if (!n || n >= ARRAYSIZE(dir)) throw std::runtime_error("LOCALAPPDATA is unavailable");
            a.logPath = fs::path(dir) / L"OptiMFG" / L"capture-logs" /
                (L"capture-" + std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(GetTickCount64()) + L".jsonl");
        }
        if (!a.exportPath.empty() && a.exportPath == a.logPath) throw std::runtime_error("Export and session log must use different paths");
        fs::create_directories(a.logPath.parent_path()); a.log.open(a.logPath);
        a.Event("session_started", ",\"version\":\"0.3.0-capture\",\"preview_limit_hz\":10,\"mfg_active\":false,\"optishade_dependency\":false");
        WNDCLASSW wc{}; wc.hInstance = instance; wc.lpfnWndProc = WindowProc;
        wc.lpszClassName = L"OptiMFGCapture"; wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_BTNFACE+1); RegisterClassW(&wc);
        a.window = CreateWindowW(wc.lpszClassName, L"OptiMFG | Standalone MSFS capture diagnostic", WS_OVERLAPPEDWINDOW,
            60, 60, 960, 640, nullptr, nullptr, instance, nullptr);
        if (!a.window) throw std::runtime_error("Could not create capture window");
        a.combo = CreateWindowW(L"COMBOBOX", L"", WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL,
            12,12,520,200,a.window,nullptr,instance,nullptr);
        auto button = [&](wchar_t const* text, int id, int x, int w) {
            CreateWindowW(L"BUTTON", text, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, x,12,w,28,a.window,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),instance,nullptr);
        };
        button(L"Refresh",1,542,80); button(L"Start capture",2,628,110); button(L"Stop",3,744,65); button(L"Export logs",4,815,110);
        a.status = CreateWindowW(L"STATIC", L"", WS_CHILD | WS_VISIBLE,12,48,910,48,a.window,nullptr,instance,nullptr);
        ShowWindow(a.window, show); ShowWindow(a.window, SW_SHOWNOACTIVATE);
        std::jthread sourceThread;
        if (a.selfTest) {
            wc.lpszClassName = L"OptiMFGCaptureSource"; wc.lpfnWndProc = SourceProc; RegisterClassW(&wc);
            std::promise<HWND> ready; auto result = ready.get_future();
            sourceThread = std::jthread([instance, ready = std::move(ready)](std::stop_token stop) mutable {
                HWND sourceWindow = CreateWindowW(L"OptiMFGCaptureSource",L"OptiMFG controlled source",WS_OVERLAPPEDWINDOW,1050,80,420,270,nullptr,nullptr,instance,nullptr);
                ShowWindow(sourceWindow,SW_SHOWNOACTIVATE); SetTimer(sourceWindow,1,100,nullptr);
                ready.set_value(sourceWindow);
                std::stop_callback cleanup(stop, [sourceWindow] { PostMessageW(sourceWindow,WM_CLOSE,0,0); });
                MSG message{}; while (GetMessageW(&message,nullptr,0,0)>0) { TranslateMessage(&message); DispatchMessageW(&message); }
            });
            a.source = result.get();
        }
        a.Refresh(); a.begun = GetTickCount64();
        if (a.selfTest) { SendMessageW(a.combo,CB_SETCURSEL,a.targets.size()-1,0); a.Start(); }
        SetTimer(a.window,1,100,nullptr);
        MSG msg{}; while (GetMessageW(&msg,nullptr,0,0)>0) { TranslateMessage(&msg); DispatchMessageW(&msg); }
        return a.failed ? 1 : 0;
    } catch (hresult_error const& e) { MessageBoxW(nullptr,e.message().c_str(),L"OptiMFG capture error",MB_ICONERROR); return 1; }
      catch (std::exception const& e) { MessageBoxW(nullptr,to_hstring(e.what()).c_str(),L"OptiMFG capture error",MB_ICONERROR); return 1; }
}
