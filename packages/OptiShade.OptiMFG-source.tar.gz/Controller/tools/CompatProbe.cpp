#include "OptiMFG/ConfigProbe.hpp"
#include <fstream>
#include <iostream>
int main(int argc, char** argv) {
    if (argc != 2) { std::cerr << "Usage: OptiMFG_CompatProbe <explicit-ini-path> (read only)\n"; return 2; }
    std::ifstream input(argv[1]);
    if (!input) { std::cerr << "Could not read configuration\n"; return 1; }
    const auto p = omfg::probeConfig(input);
    std::cout << "{\"status\":\"observed_text_only\",\"enabled\":\"" << p.enabled
              << "\",\"fg_output\":\"" << p.fgOutput << "\",\"legacy\":" << (p.legacy ? "true" : "false")
              << ",\"ambiguous\":" << (p.ambiguous ? "true" : "false") << ",\"compatibility\":\"unverified\"}\n";
}
