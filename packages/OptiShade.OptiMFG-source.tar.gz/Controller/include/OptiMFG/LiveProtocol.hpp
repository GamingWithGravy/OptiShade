#pragma once
#include <windows.h>
#include <sddl.h>
#include <string>
namespace omfg::live {
constexpr LONG Magic=0x4f4d4c56, Version=4;
enum Status : LONG { Observing, WaitingOptions, WaitingState, HostDisabled, UnsupportedCount,
    Accepted, ApiError, UnsupportedAbi, MultipleViewports, LeaseExpired, HookError };
// Every concurrently accessed field uses Windows interlocked operations. One controller writes commands.
struct Shared {
    LONG magic{},version{},pid{},ready{};
    LONG commandSequence{},request{-1},heartbeat{};
    LONG status{},appliedSequence{},effectiveMode{},effectiveCount{},lastResult{};
    LONG optionCalls{},stateCalls{},viewport{-1},optionsVersion{},maximum{},runtimeStatus{},presented{};
    LONG originalMode{},originalCount{},callbackThread{};
    LONG decisionStatus{},capabilityViewport{-1},selectedViewport{-1},typeMatches{};
    LONG validStates{},failedStates{},presentedMaximum{},multiPresentSamples{};
    LONG tagCalls{},tagErrors{},tagMask{},tagViewport{-1};
};
inline LONG Read(LONG const& v){return InterlockedCompareExchange(const_cast<LONG*>(&v),0,0);}
inline void Write(LONG& v,LONG n){InterlockedExchange(&v,n);}
inline std::wstring MappingName(DWORD pid){return L"Local\\OptiMFG.Live.v4."+std::to_wstring(pid);}
inline bool TryCommand(Shared& s,LONG request,DWORD waitMs=INFINITE){
    auto name=L"Local\\OptiMFG.Live.Writer."+std::to_wstring(static_cast<DWORD>(Read(s.pid)));
    HANDLE writer=OpenMutexW(SYNCHRONIZE|MUTEX_MODIFY_STATE,FALSE,name.c_str());if(!writer)return false;
    DWORD result=WaitForSingleObject(writer,waitMs);
    if(result!=WAIT_OBJECT_0&&result!=WAIT_ABANDONED){CloseHandle(writer);return false;}
    InterlockedIncrement(&s.commandSequence);Write(s.request,request);Write(s.heartbeat,static_cast<LONG>(GetTickCount()));InterlockedIncrement(&s.commandSequence);
    ReleaseMutex(writer);CloseHandle(writer);return true;
}
inline void Command(Shared& s,LONG request){(void)TryCommand(s,request,3000);}
inline bool ReadCommand(Shared const& s,LONG& sequence,LONG& request){sequence=Read(s.commandSequence);if(sequence&1)return false;request=Read(s.request);return sequence==Read(s.commandSequence);}
inline wchar_t const* StatusText(LONG s){switch(s){
case Observing:return L"Observing / game controls MFG";case WaitingOptions:return L"Waiting for the game's next MFG options call";
case WaitingState:return L"Waiting for capability state from the game";case HostDisabled:return L"Game has disabled FG; enable it in MSFS first";
case UnsupportedCount:return L"Requested multiplier exceeds runtime capability";case Accepted:return L"Runtime API accepted request (not a displayed-FPS measurement)";
case ApiError:return L"Runtime API returned an error";case UnsupportedAbi:return L"Unknown options ABI; game call passed through";
case MultipleViewports:return L"Multiple viewports observed; overrides disabled";case LeaseExpired:return L"Controller heartbeat lost; returning control to the game";
default:return L"Helper unavailable / hook initialization error";}}
}
