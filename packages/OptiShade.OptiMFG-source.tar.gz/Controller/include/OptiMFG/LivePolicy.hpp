#pragma once
#include "LiveProtocol.hpp"
namespace omfg::live {
struct Decision { bool change{}; LONG mode{},count{},status{Observing}; };
inline Decision Decide(LONG request,LONG hostMode,LONG hostCount,LONG maximum,bool stateValid,bool leaseValid){
    Decision d{false,hostMode,hostCount,Observing};
    if(request==-1)return d;
    if(!leaseValid){d.status=LeaseExpired;return d;}
    if(hostMode==0){d.status=HostDisabled;return d;}
    if(request==0){d.change=true;d.mode=0;d.count=hostCount>0?hostCount:1;d.status=Accepted;return d;}
    if(request<2||request>6){d.status=UnsupportedCount;return d;}
    if(!stateValid){d.status=WaitingState;return d;}
    if(request-1>maximum){d.status=UnsupportedCount;return d;}
    d.change=true;d.mode=1;d.count=request-1;d.status=Accepted;return d;
}
}
