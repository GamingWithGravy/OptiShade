#pragma once
#include <istream>
#include <string>
namespace omfg {
struct ConfigObservation {
    std::string enabled = "absent";
    std::string fgOutput = "absent";
    bool legacy = false, ambiguous = false;
};
// Read-only lexical observations; no inference of effective runtime settings.
ConfigObservation probeConfig(std::istream& input);
}
