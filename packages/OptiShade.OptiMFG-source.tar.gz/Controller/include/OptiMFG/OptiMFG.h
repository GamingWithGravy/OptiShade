#pragma once
#include <stdint.h>
#if defined(_WIN32)
# ifdef OMFG_EXPORTS
#  define OMFG_API __declspec(dllexport)
# else
#  define OMFG_API __declspec(dllimport)
# endif
#else
# define OMFG_API __attribute__((visibility("default")))
#endif
#define OMFG_ABI_VERSION 1u
#ifdef __cplusplus
extern "C" {
#endif
/* Fresh OptiMFG ABI: no compatibility claim with the unavailable GravyMFG P0.
   Scheduler only; it does not render or generate frames. Nanoseconds, monotonic. */
OMFG_API uint32_t omfgGetAbiVersion(void);
/* Produces multiplier-1 timestamps strictly between endpoints. Returns count,
   or -1 for invalid inputs; never writes a partial result on error. */
OMFG_API int32_t omfgSchedule(int64_t previous_ns, int64_t current_ns,
                            uint32_t multiplier, int64_t* out_ns, uint32_t capacity);
#ifdef __cplusplus
}
#endif
