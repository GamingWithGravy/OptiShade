#pragma once
#include <cstdint>
#include <mutex>
#include <string_view>
namespace omfg {
inline constexpr uint32_t HostVersion = 1;
using HostID = uint64_t;
using PresentOwnerID = uint64_t;
using FGOwnerID = uint64_t;
enum class BackendType { PassThrough, DiagnosticCopy, Custom, Native };
enum class Lifecycle { Created, Initialized, Running, Draining, Stopped };
enum class FrameKind { Real, Generated };
enum class Transfer { SDR_Gamma22, Linear, PQ };
enum class ResourceState { Unknown, RenderTarget, CopySource, CopyDest, Present };
enum class Error { None, InvalidState, OwnerConflict, InvalidFrame, StaleEpoch,
                   MissingColor, InvalidResource, SyncFailure, Unsupported };
struct Result { Error error = Error::None; explicit operator bool() const { return error == Error::None; } };
std::string_view name(Error error);
/* Native format identifiers are backend-specific (DXGI_FORMAT for DX12).
   Tokens are opaque non-owning identities, NOT pointers exposed in the C ABI.
   All valid resources remain alive until the host observes completionFence.
   Invalid resources must have token=0; no inferred engine motion or depth. */
struct Texture {
    bool valid = false;
    uint64_t token = 0;
    uint32_t nativeFormat = 0, width = 0, height = 0;
    ResourceState state = ResourceState::Unknown;
};
struct Output {
    uint32_t width = 0, height = 0, nativeFormat = 0;
    Transfer transfer = Transfer::SDR_Gamma22;
    bool hdr = false;
};
struct Owners {
    uint64_t swapchain = 0;
    HostID host = 0;
    PresentOwnerID present = 0;
    FGOwnerID fg = 0;
};
/* Host exclusively owns device, direct queue, command lists, allocators, heaps,
   descriptors and fence. Host waits before reuse/release, transitions resources,
   submits, signals monotonically, and presents exactly once per accepted real
   frame. A future provider borrows views for one epoch and must return explicit
   state + completion requirements; P1 has no provider or external queue route. */
struct GpuOwnership {
    HostID device = 0, queue = 0, commandList = 0, descriptors = 0, fence = 0;
};
struct Frame {
    FrameKind kind = FrameKind::Real;
    uint64_t id = 0, epoch = 0, completionFence = 0;
    int64_t timestampNs = 0;
    bool sceneCut = false;
    Texture color, depth, motion, hudless, ui;
};
struct Snapshot {
    Lifecycle state; uint64_t epoch, accepted, bypassed, rejected, lastFence;
};
/* Mutex-linearized lifecycle and delivery. Registry enforces one present/FG
   owner per swapchain identity in this process. External owners must declare
   their identity through a future adapter: no claim of detecting foreign hooks. */
class HostContract {
public:
    HostContract() = default;
    ~HostContract();
    HostContract(const HostContract&) = delete;
    HostContract& operator=(const HostContract&) = delete;
    Result initialize(Owners owners, GpuOwnership gpu, Output output);
    Result start();
    Result accept(const Frame& frame);
    Result drain();
    Result stop(uint64_t completedFence);
    Result recreate(Output output, uint64_t completedFence);
    void deviceLost(); // invalidate all borrowed views; no wait on removed device
    Snapshot snapshot() const;
private:
    void releaseOwner();
    mutable std::mutex mutex_;
    Lifecycle state_ = Lifecycle::Created;
    Owners owners_{};
    Output output_{};
    uint64_t epoch_ = 1, lastId_ = 0, fence_ = 0, accepted_ = 0, bypassed_ = 0, rejected_ = 0;
    int64_t timestamp_ = -1;
};
}
