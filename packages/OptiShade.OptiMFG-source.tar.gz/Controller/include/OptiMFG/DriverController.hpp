#pragma once
#include <array>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <string>
namespace omfg::driver {
struct Value {
    uint32_t id{}, value{};
    bool local{};
    bool operator==(Value const&) const = default;
};
struct Snapshot {
    std::wstring profile;
    std::array<Value, 4> values;
};
enum class Mode { Application, Off, X2, X3, X4, X5, X6 };
using Logger = std::function<void(std::string const&, std::string const&)>;
std::string Utf8(std::wstring const& text);
std::wstring Wide(std::string const& text);
std::string Json(std::string const& text);
std::array<uint32_t,4> Desired(Mode mode);
bool SimulatorRunning();
class Controller {
public:
    Controller(std::filesystem::path directory, Logger logger);
    ~Controller();
    Controller(Controller const&) = delete;
    Controller& operator=(Controller const&) = delete;
    std::wstring Hardware();
    Snapshot Read(std::wstring const& executable);
    std::filesystem::path Apply(std::wstring const& executable, Mode mode, Snapshot const& reviewed);
    void Restore(std::wstring const& executable, std::filesystem::path const& backup);
    void SelfTest();
private:
    struct Impl;
    Impl* impl_{};
};
}
