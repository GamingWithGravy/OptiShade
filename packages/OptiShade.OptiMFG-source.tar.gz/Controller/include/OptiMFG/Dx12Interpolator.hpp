#pragma once
#ifdef _WIN32
#include <d3d12.h>
#include <wrl/client.h>
#include <cstdint>
namespace omfg {
// Initial independently authored motion-guided GPU interpolation provider.
// Host owns presentation, device, queue, command list, transitions of inputs,
// and completion waits. Call only after previous record's completion fence;
// the provider's descriptors and output may not be concurrently reused.
// Inputs are same-sized, single-sample textures in NON_PIXEL_SHADER_RESOURCE:
// previous/current RGBA8 SDR, current motion RG32F in current-minus-previous
// pixels, previous/current R32F linear depth (near=0, far=1).
// Provider output is RGBA8 in COPY_SOURCE after record(). No Present, hooks,
// driver-native claims, external runtimes, or private Optishade dependencies.
class Dx12Interpolator {
public:
    void initialize(ID3D12Device* device, uint32_t width, uint32_t height);
    void record(ID3D12GraphicsCommandList* commands, ID3D12Resource* previous,
                ID3D12Resource* current, ID3D12Resource* motion,
                ID3D12Resource* previousDepth, ID3D12Resource* currentDepth, float alpha);
    ID3D12Resource* output() const { return output_.Get(); }
private:
    Microsoft::WRL::ComPtr<ID3D12Device> device_;
    Microsoft::WRL::ComPtr<ID3D12RootSignature> root_;
    Microsoft::WRL::ComPtr<ID3D12PipelineState> pipeline_;
    Microsoft::WRL::ComPtr<ID3D12DescriptorHeap> descriptors_;
    Microsoft::WRL::ComPtr<ID3D12Resource> output_;
    uint32_t width_ = 0, height_ = 0, stride_ = 0;
    bool used_ = false;
};
}
#endif
