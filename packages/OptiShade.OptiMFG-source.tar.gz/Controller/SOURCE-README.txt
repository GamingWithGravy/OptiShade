OptiMFG controller corresponding source for OptiMFG 1.0.100

Source of OptiMFG_Live.exe, OptiMFG_LiveCtl.exe, OptiMFG_LiveHelper_v4.dll and OptiMFG_Controller.exe as shipped in OptiShade.OptiMFG 1.0.100 (OptiShade source commit bf5105981d91dbe9644d5f88d309eebefbf742cd). The OptiShade desktop theme (shared/PanelUi.h) and OptiShade additions are GPL-3.0-or-later. Dear ImGui (Beta/reshade/deps/imgui in the OptiShade source), MinHook, nlohmann/json, NVIDIA Streamline headers and NVAPI keep their own licences; the Streamline and NVAPI SDKs are not included and come from NVIDIA. Build with CMake and MSVC; set OPTISHADE_SOURCE_ROOT so the build finds ImGui and shared/PanelUi.h.

Source203040/ holds the source of the earlier bundled RTX backend. OptiMFG 1.0.100 no longer ships that backend: it downloads the unchanged MFG Unlocker 1.7.0 from its official GitHub release on the player's PC instead.
