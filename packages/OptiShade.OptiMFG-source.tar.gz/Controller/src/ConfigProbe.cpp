#include "OptiMFG/ConfigProbe.hpp"
#include <algorithm>
#include <cctype>
namespace omfg {
namespace {
std::string trim(std::string s) {
    const auto a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return {};
    return s.substr(a, s.find_last_not_of(" \t\r\n") - a + 1);
}
std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}
}
ConfigObservation probeConfig(std::istream& input) {
    ConfigObservation result;
    std::string line, section;
    bool seen = false, outputSeen = false;
    while (std::getline(input, line)) {
        if (line.starts_with("\xef\xbb\xbf")) line.erase(0, 3);
        line = trim(line.substr(0, line.find_first_of(";#")));
        if (line.empty()) continue;
        if (line.front() == '[' && line.back() == ']') { section = lower(trim(line.substr(1, line.size() - 2))); continue; }
        const auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        auto key = lower(trim(line.substr(0, eq))), value = lower(trim(line.substr(eq + 1)));
        if (key == "enabled" && section == "framegeneration") {
            if (seen) result.ambiguous = true;
            seen = true;
            result.enabled = (value == "auto" || value == "true" || value == "false") ? value : "unrecognized";
        }
        if (key == "fgoutput") {
            if (outputSeen) result.ambiguous = true;
            outputSeen = true;
            result.fgOutput = "present_uninterpreted";
        }
        if (key == "enableframegeneration" || key == "framegeneration") result.legacy = true;
    }
    return result;
}
}
