#include "OptiMFG/Dx12Interpolator.hpp"
#include "InterpolateCS.h"
#include <cmath>
#include <stdexcept>
namespace omfg {
namespace {
void check(HRESULT hr) { if (FAILED(hr)) throw std::runtime_error("custom_backend_dx12_creation_failed"); }
void barrier(ID3D12GraphicsCommandList* list, ID3D12Resource* resource, D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after) {
    D3D12_RESOURCE_BARRIER b{}; b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    b.Transition = {resource, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, before, after}; list->ResourceBarrier(1, &b);
}
}
void Dx12Interpolator::initialize(ID3D12Device* device, uint32_t width, uint32_t height) {
    if (!device || !width || !height) throw std::invalid_argument("custom_backend_invalid_dimensions");
    *this = Dx12Interpolator{};
    device_ = device; width_ = width; height_ = height;
    D3D12_FEATURE_DATA_FORMAT_SUPPORT support{DXGI_FORMAT_R8G8B8A8_UNORM};
    check(device->CheckFeatureSupport(D3D12_FEATURE_FORMAT_SUPPORT, &support, sizeof(support)));
    if (!(support.Support2 & D3D12_FORMAT_SUPPORT2_UAV_TYPED_STORE)) throw std::runtime_error("custom_backend_rgba8_uav_store_unsupported");
    D3D12_DESCRIPTOR_RANGE ranges[2]{};
    ranges[0] = {D3D12_DESCRIPTOR_RANGE_TYPE_SRV, 5, 0, 0, 0};
    ranges[1] = {D3D12_DESCRIPTOR_RANGE_TYPE_UAV, 1, 0, 0, 5};
    D3D12_ROOT_PARAMETER params[2]{};
    params[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
    params[0].DescriptorTable = {2, ranges};
    params[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
    params[1].Constants = {0, 0, 3};
    D3D12_ROOT_SIGNATURE_DESC root{}; root.NumParameters = 2; root.pParameters = params;
    Microsoft::WRL::ComPtr<ID3DBlob> serialized, errors;
    check(D3D12SerializeRootSignature(&root, D3D_ROOT_SIGNATURE_VERSION_1, &serialized, &errors));
    check(device->CreateRootSignature(0, serialized->GetBufferPointer(), serialized->GetBufferSize(), IID_PPV_ARGS(&root_)));
    D3D12_COMPUTE_PIPELINE_STATE_DESC pipeline{}; pipeline.pRootSignature = root_.Get(); pipeline.CS = {InterpolateCS, sizeof(InterpolateCS)};
    check(device->CreateComputePipelineState(&pipeline, IID_PPV_ARGS(&pipeline_)));
    D3D12_DESCRIPTOR_HEAP_DESC heap{}; heap.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV; heap.NumDescriptors = 6; heap.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    check(device->CreateDescriptorHeap(&heap, IID_PPV_ARGS(&descriptors_)));
    stride_ = device->GetDescriptorHandleIncrementSize(heap.Type);
    D3D12_HEAP_PROPERTIES memory{}; memory.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC texture{}; texture.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    texture.Width = width; texture.Height = height; texture.DepthOrArraySize = 1; texture.MipLevels = 1;
    texture.Format = DXGI_FORMAT_R8G8B8A8_UNORM; texture.SampleDesc.Count = 1; texture.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
    check(device->CreateCommittedResource(&memory, D3D12_HEAP_FLAG_NONE, &texture, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&output_)));
}
void Dx12Interpolator::record(ID3D12GraphicsCommandList* commands, ID3D12Resource* previous,
    ID3D12Resource* current, ID3D12Resource* motion, ID3D12Resource* previousDepth, ID3D12Resource* currentDepth, float alpha) {
    if (!commands || !pipeline_ || !std::isfinite(alpha) || alpha <= 0 || alpha >= 1) throw std::invalid_argument("custom_backend_invalid_request");
    ID3D12Resource* inputs[]{previous, current, motion, previousDepth, currentDepth};
    DXGI_FORMAT formats[]{DXGI_FORMAT_R8G8B8A8_UNORM, DXGI_FORMAT_R8G8B8A8_UNORM, DXGI_FORMAT_R32G32_FLOAT, DXGI_FORMAT_R32_FLOAT, DXGI_FORMAT_R32_FLOAT};
    auto cpu = descriptors_->GetCPUDescriptorHandleForHeapStart();
    for (unsigned i = 0; i < 5; ++i) {
        if (!inputs[i]) throw std::invalid_argument("custom_backend_required_input_missing");
        auto d = inputs[i]->GetDesc();
        if (d.Width != width_ || d.Height != height_ || d.Format != formats[i] || d.SampleDesc.Count != 1 || d.Dimension != D3D12_RESOURCE_DIMENSION_TEXTURE2D || d.DepthOrArraySize != 1)
            throw std::invalid_argument("custom_backend_input_format_mismatch");
        D3D12_SHADER_RESOURCE_VIEW_DESC srv{}; srv.Format = formats[i]; srv.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
        srv.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING; srv.Texture2D.MipLevels = 1;
        device_->CreateShaderResourceView(inputs[i], &srv, cpu); cpu.ptr += stride_;
    }
    D3D12_UNORDERED_ACCESS_VIEW_DESC uav{}; uav.Format = DXGI_FORMAT_R8G8B8A8_UNORM; uav.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
    device_->CreateUnorderedAccessView(output_.Get(), nullptr, &uav, cpu);
    if (used_) barrier(commands, output_.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    ID3D12DescriptorHeap* heaps[]{descriptors_.Get()}; commands->SetDescriptorHeaps(1, heaps);
    commands->SetComputeRootSignature(root_.Get()); commands->SetPipelineState(pipeline_.Get());
    commands->SetComputeRootDescriptorTable(0, descriptors_->GetGPUDescriptorHandleForHeapStart());
    struct { float alpha; uint32_t width, height; } constants{alpha, width_, height_};
    commands->SetComputeRoot32BitConstants(1, 3, &constants, 0);
    commands->Dispatch((width_ + 7) / 8, (height_ + 7) / 8, 1);
    barrier(commands, output_.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
    used_ = true;
}
}
