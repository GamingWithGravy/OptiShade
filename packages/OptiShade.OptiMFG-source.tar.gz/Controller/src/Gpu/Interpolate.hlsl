Texture2D<float4> previousColor : register(t0);
Texture2D<float4> currentColor : register(t1);
Texture2D<float2> currentMotion : register(t2);
Texture2D<float> previousDepth : register(t3);
Texture2D<float> currentDepth : register(t4);
RWTexture2D<float4> destination : register(u0);
cbuffer Parameters : register(b0) { float alpha; uint width; uint height; };
int2 pixel(float2 p) { return clamp(int2(round(p)), int2(0, 0), int2(width - 1, height - 1)); }
[numthreads(8, 8, 1)]
void InterpolateCS(uint3 thread : SV_DispatchThreadID) {
    if (thread.x >= width || thread.y >= height) return;
    float2 p = thread.xy;
    // Fixed-point inverse reprojection using host-provided motion. This first
    // backend intentionally has no optical flow or learned hole filling.
    const int2 offsets[13] = {int2(0,0), int2(-8,0), int2(8,0), int2(-32,0), int2(32,0), int2(-64,0), int2(64,0),
        int2(0,-8), int2(0,8), int2(0,-32), int2(0,32), int2(0,-64), int2(0,64)};
    float bestDepth = 2;
    float zPrevious = previousDepth.Load(int3(thread.xy, 0));
    float zCurrent = currentDepth.Load(int3(thread.xy, 0));
    // Uncovered pixels start with the farther visible source; a consistent
    // foreground correspondence below overrides it at the intermediate pose.
    float4 result = zPrevious > zCurrent ? previousColor.Load(int3(thread.xy, 0)) : currentColor.Load(int3(thread.xy, 0));
    // Nearby motion candidates cover modest disocclusions without an optical-
    // flow dependency. Reject inconsistent depth and motion correspondences.
    for (uint i = 0; i < 13; ++i) {
        float2 velocity = currentMotion.Load(int3(pixel(p + offsets[i]), 0));
        int2 a = pixel(p - alpha * velocity), b = pixel(p + (1 - alpha) * velocity);
        float za = previousDepth.Load(int3(a, 0)), zb = currentDepth.Load(int3(b, 0));
        float2 checkMotion = currentMotion.Load(int3(b, 0));
        if (abs(za - zb) < 0.08 && length(checkMotion - velocity) < 0.5 && zb < bestDepth) {
            bestDepth = zb;
            result = lerp(previousColor.Load(int3(a, 0)), currentColor.Load(int3(b, 0)), alpha);
        }
    }
    destination[thread.xy] = result;
}
