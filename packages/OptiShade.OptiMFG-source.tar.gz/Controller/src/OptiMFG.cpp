#include "OptiMFG/OptiMFG.h"
uint32_t omfgGetAbiVersion(void) { return OMFG_ABI_VERSION; }
int32_t omfgSchedule(int64_t a, int64_t b, uint32_t n, int64_t* out, uint32_t cap) {
    if (a < 0 || b <= a || n < 2 || n > 6 || !out || cap < n - 1) return -1;
    const auto delta = b - a;
    if (delta < n) return -1;
    for (uint32_t i = 1; i < n; ++i)
        out[i - 1] = a + (delta / n) * i + ((delta % n) * i) / n;
    return static_cast<int32_t>(n - 1);
}
