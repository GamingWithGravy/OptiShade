#include <windows.h>
#include <tlhelp32.h>
#include <nvapi.h>
#include <NvApiDriverSettings.h>
#include <nvapi_interface.h>
#include <OptiMFG/DriverController.hpp>
#include <fstream>
#include <iomanip>
#include <memory>
#include <sstream>
#include <stdexcept>

namespace omfg::driver {
namespace fs = std::filesystem;
std::string Utf8(std::wstring const& text) {
    if (text.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()), nullptr, 0, nullptr, nullptr);
    if (!n) throw std::runtime_error("Invalid UTF-16 text");
    std::string r(n, 0); WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), r.data(), n, nullptr, nullptr); return r;
}
std::wstring Wide(std::string const& text) {
    if (text.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()), nullptr, 0);
    if (!n) throw std::runtime_error("Invalid UTF-8 text");
    std::wstring r(n, 0); MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), r.data(), n); return r;
}
std::string Json(std::string const& text) {
    std::string r = "\"";
    for (unsigned char c : text) {
        if (c == '"' || c == '\\') { r += '\\'; r += static_cast<char>(c); }
        else if (c < 32) r += ' '; else r += static_cast<char>(c);
    }
    return r + '"';
}
static constexpr std::array<uint32_t,4> ids = { NGX_DLSSG_MODE_ID, NGX_DLSSG_MULTI_FRAME_COUNT_ID,
    NGX_DLSS_FG_OVERRIDE_ID, NGX_DLSS_FG_OVERRIDE_RENDER_PRESET_SELECTION_ID };
std::array<uint32_t,4> Desired(Mode mode) {
    if (mode == Mode::Application) return {NGX_DLSSG_MODE_DISABLED, 0, 0, 0};
    if (mode == Mode::Off) return {NGX_DLSSG_MODE_OFF, 0, 0, 0};
    if (mode < Mode::X2 || mode > Mode::X6) throw std::runtime_error("Invalid mode");
    // Driver count is generated frames per rendered frame: count 1 requests 2x total.
    return {NGX_DLSSG_MODE_ON, static_cast<uint32_t>(mode) - 1, NGX_DLSS_FG_OVERRIDE_ON,
        NGX_DLSS_FG_OVERRIDE_RENDER_PRESET_SELECTION_RENDER_PRESET_Latest};
}
bool SimulatorRunning() {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) throw std::runtime_error("Could not inspect running processes");
    PROCESSENTRY32W entry{}; entry.dwSize = sizeof(entry); bool found = false;
    if (Process32FirstW(snapshot, &entry)) do {
        if (!_wcsicmp(entry.szExeFile, L"FlightSimulator2024.exe") || !_wcsicmp(entry.szExeFile, L"FlightSimulator.exe")) { found = true; break; }
    } while (Process32NextW(snapshot, &entry));
    CloseHandle(snapshot); return found;
}
static void Unicode(NvAPI_UnicodeString& out, std::wstring const& text) {
    if (text.size() >= NVAPI_UNICODE_STRING_MAX) throw std::runtime_error("Profile or executable name is too long");
    std::copy(text.begin(), text.end(), out); out[text.size()] = 0;
}
struct Api {
    HMODULE library{};
    using Query = void* (__cdecl*)(unsigned int);
    Query query{};
    template<class T> T Bind(char const* name) {
        for (auto const& entry : nvapi_interface_table) if (!strcmp(entry.func, name)) {
            auto p = query(entry.id); if (p) return reinterpret_cast<T>(p);
            break;
        }
        throw std::runtime_error(std::string("NVIDIA driver does not expose ") + name);
    }
#define API_FUNCTION(name) decltype(&NvAPI_##name) name{};
    API_FUNCTION(Initialize) API_FUNCTION(Unload) API_FUNCTION(GetErrorMessage)
    API_FUNCTION(SYS_GetDriverAndBranchVersion) API_FUNCTION(EnumPhysicalGPUs) API_FUNCTION(GPU_GetFullName)
    API_FUNCTION(DRS_CreateSession) API_FUNCTION(DRS_DestroySession) API_FUNCTION(DRS_LoadSettings)
    API_FUNCTION(DRS_SaveSettings) API_FUNCTION(DRS_FindApplicationByName) API_FUNCTION(DRS_GetProfileInfo)
    API_FUNCTION(DRS_GetSetting) API_FUNCTION(DRS_SetSetting) API_FUNCTION(DRS_DeleteProfileSetting)
    API_FUNCTION(DRS_GetSettingNameFromId) API_FUNCTION(DRS_CreateProfile) API_FUNCTION(DRS_DeleteProfile)
    API_FUNCTION(DRS_CreateApplication) API_FUNCTION(DRS_FindProfileByName)
#undef API_FUNCTION
    void Check(NvAPI_Status s, char const* operation) {
        if (s == NVAPI_OK) return;
        NvAPI_ShortString message{}; if (GetErrorMessage) GetErrorMessage(s, message);
        throw std::runtime_error(std::string(operation) + ": " + message + " (NVAPI " + std::to_string(s) + ")");
    }
    Api() {
        // Only load the installed Windows driver, never a DLL beside this executable.
        library = LoadLibraryExW(L"nvapi64.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
        if (!library) throw std::runtime_error("NVIDIA NVAPI driver unavailable. This controller requires an installed NVIDIA driver; AMD/Intel are not supported by this backend.");
        try {
            query = reinterpret_cast<Query>(GetProcAddress(library,"nvapi_QueryInterface"));
            if (!query) throw std::runtime_error("NVIDIA driver query interface missing");
#define LOAD(name) name = Bind<decltype(name)>("NvAPI_" #name);
            LOAD(Initialize) LOAD(Unload) LOAD(GetErrorMessage)
            Check(Initialize(), "Initialize");
            LOAD(SYS_GetDriverAndBranchVersion) LOAD(EnumPhysicalGPUs) LOAD(GPU_GetFullName)
            LOAD(DRS_CreateSession) LOAD(DRS_DestroySession) LOAD(DRS_LoadSettings) LOAD(DRS_SaveSettings)
            LOAD(DRS_FindApplicationByName) LOAD(DRS_GetProfileInfo) LOAD(DRS_GetSetting) LOAD(DRS_SetSetting)
            LOAD(DRS_DeleteProfileSetting) LOAD(DRS_GetSettingNameFromId) LOAD(DRS_CreateProfile)
            LOAD(DRS_DeleteProfile) LOAD(DRS_CreateApplication) LOAD(DRS_FindProfileByName)
#undef LOAD
        } catch (...) { if (Unload) Unload(); FreeLibrary(library); throw; }
    }
    ~Api() { if (Unload) Unload(); if (library) FreeLibrary(library); }
};
struct Session {
    Api& api; NvDRSSessionHandle handle{};
    Session(Api& a) : api(a) {
        api.Check(api.DRS_CreateSession(&handle),"CreateSession");
        try { api.Check(api.DRS_LoadSettings(handle),"LoadSettings"); }
        catch (...) { api.DRS_DestroySession(handle); throw; }
    }
    ~Session() { api.DRS_DestroySession(handle); }
    NvDRSProfileHandle Find(std::wstring const& executable) {
        NvAPI_UnicodeString name{}; Unicode(name, executable);
        auto application = std::make_unique<NVDRS_APPLICATION>(); application->version = NVDRS_APPLICATION_VER;
        NvDRSProfileHandle profile{};
        api.Check(api.DRS_FindApplicationByName(handle,name,&profile,application.get()),"FindApplicationByName (select the full MSFS executable if ambiguous)");
        return profile;
    }
    Snapshot Read(NvDRSProfileHandle profile) {
        auto info = std::make_unique<NVDRS_PROFILE>(); info->version = NVDRS_PROFILE_VER;
        api.Check(api.DRS_GetProfileInfo(handle,profile,info.get()),"GetProfileInfo");
        Snapshot result; result.profile = reinterpret_cast<wchar_t const*>(info->profileName);
        for (size_t i = 0; i < ids.size(); ++i) {
            auto setting = std::make_unique<NVDRS_SETTING>(); setting->version = NVDRS_SETTING_VER;
            auto status = api.DRS_GetSetting(handle,profile,ids[i],setting.get());
            if (status == NVAPI_SETTING_NOT_FOUND) { result.values[i] = {ids[i],0,false}; continue; }
            api.Check(status,"GetSetting");
            if (setting->settingType != NVDRS_DWORD_TYPE) throw std::runtime_error("Driver returned a non-DWORD MFG setting");
            result.values[i] = {ids[i],setting->u32CurrentValue,
                setting->settingLocation == NVDRS_CURRENT_PROFILE_LOCATION && !setting->isCurrentPredefined};
        }
        return result;
    }
    void Write(NvDRSProfileHandle profile, Value value) {
        if (!value.local) {
            auto status = api.DRS_DeleteProfileSetting(handle,profile,value.id);
            if (status != NVAPI_SETTING_NOT_FOUND) api.Check(status,"DeleteProfileSetting");
        } else {
            auto setting = std::make_unique<NVDRS_SETTING>(); setting->version = NVDRS_SETTING_VER;
            setting->settingId = value.id; setting->settingType = NVDRS_DWORD_TYPE;
            setting->u32CurrentValue = value.value;
            api.Check(api.DRS_SetSetting(handle,profile,setting.get()),"SetSetting");
        }
    }
    void Save() { api.Check(api.DRS_SaveSettings(handle),"SaveSettings"); }
};
struct Backup { std::wstring executable; Snapshot before; std::array<uint32_t,4> desired; };
static void SaveBackup(fs::path const& path, Backup const& backup) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out << "OPTIMFG_DRIVER_BACKUP_V1\n" << std::quoted(Utf8(backup.executable)) << '\n' << std::quoted(Utf8(backup.before.profile)) << '\n';
    for (size_t i=0;i<ids.size();++i) {
        auto v = backup.before.values[i]; out << v.id << ' ' << v.value << ' ' << v.local << ' ' << backup.desired[i] << '\n';
    }
    out.flush(); if (!out) throw std::runtime_error("Cannot write backup; driver settings were not saved");
    out.close(); if (!out) throw std::runtime_error("Cannot close backup; driver settings were not saved");
}
static Backup LoadBackup(fs::path const& path) {
    std::ifstream in(path, std::ios::binary); std::string magic, executable, profile; Backup b;
    std::getline(in,magic); in >> std::quoted(executable) >> std::quoted(profile);
    if (magic != "OPTIMFG_DRIVER_BACKUP_V1") throw std::runtime_error("Invalid OptiMFG backup");
    b.executable = Wide(executable); b.before.profile = Wide(profile);
    for (size_t i=0;i<ids.size();++i) {
        auto& v=b.before.values[i]; in >> v.id >> v.value >> v.local >> b.desired[i];
        if (!in || v.id != ids[i]) throw std::runtime_error("Invalid backup setting record");
    }
    std::string extra; if (in >> extra) throw std::runtime_error("Unexpected backup content"); return b;
}
static bool SameLocal(Value a, Value b) { return a.local == b.local && (!a.local || a.value == b.value); }
struct Controller::Impl {
    Api api; fs::path directory; Logger logger;
    Impl(fs::path d, Logger l) : directory(std::move(d)), logger(std::move(l)) { fs::create_directories(directory); }
    void LogSnapshot(Snapshot const& s) {
        std::string fields = ",\"profile\":" + Json(Utf8(s.profile)) + ",\"runtime_mfg_verified\":false,\"settings\":[";
        for (size_t i=0;i<ids.size();++i) { auto v=s.values[i]; if(i) fields+=',';
            fields += "{\"id\":" + std::to_string(v.id) + ",\"value\":" + std::to_string(v.value) + ",\"local_override\":" + (v.local?"true":"false") + "}"; }
        logger("profile_read",fields+"]");
    }
};
Controller::Controller(fs::path d, Logger l) : impl_(new Impl(std::move(d), std::move(l))) {}
Controller::~Controller() { delete impl_; }
std::wstring Controller::Hardware() {
    auto& api = impl_->api; NvU32 version{}; NvAPI_ShortString branch{};
    api.Check(api.SYS_GetDriverAndBranchVersion(&version,branch),"DriverVersion");
    NvPhysicalGpuHandle gpus[NVAPI_MAX_PHYSICAL_GPUS]{}; NvU32 count{};
    api.Check(api.EnumPhysicalGPUs(gpus,&count),"EnumPhysicalGPUs");
    std::wstring result = L"NVIDIA driver " + std::to_wstring(version / 100) + L"." + std::to_wstring(version % 100);
    for (NvU32 i=0;i<count;++i) { NvAPI_ShortString name{}; api.Check(api.GPU_GetFullName(gpus[i],name),"GPU name"); result += L" | " + Wide(name); }
    impl_->logger("hardware",",\"description\":"+Json(Utf8(result))); return result;
}
Snapshot Controller::Read(std::wstring const& exe) {
    Session session(impl_->api); auto s=session.Read(session.Find(exe)); impl_->LogSnapshot(s); return s;
}
fs::path Controller::Apply(std::wstring const& exe, Mode mode, Snapshot const& reviewed) {
    if (SimulatorRunning()) throw std::runtime_error("Close MSFS before applying settings, then relaunch it for the test");
    auto desired=Desired(mode); Session session(impl_->api); auto profile=session.Find(exe); auto before=session.Read(profile);
    if (before.profile != reviewed.profile || before.values != reviewed.values) throw std::runtime_error("Profile changed since Refresh. Refresh and review the current settings before applying");
    for (auto id : ids) { NvAPI_UnicodeString name{}; impl_->api.Check(impl_->api.DRS_GetSettingNameFromId(id,&name),"Driver setting availability"); }
    auto backup = impl_->directory / (L"backup-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64())+L".omfgbackup");
    if(fs::exists(backup)) throw std::runtime_error("Backup name collision; retry Apply");
    SaveBackup(backup,{exe,before,desired});
    impl_->logger("backup_saved",",\"file\":"+Json(Utf8(backup.wstring())));
    impl_->logger("apply_requested",",\"profile\":"+Json(Utf8(before.profile))+",\"mode_index\":"+std::to_string(static_cast<unsigned>(mode)));
    for(size_t i=0;i<ids.size();++i) session.Write(profile,{ids[i],desired[i],true});
    session.Save();
    auto after=Read(exe);
    for(size_t i=0;i<ids.size();++i) if (!after.values[i].local || after.values[i].value!=desired[i])
        throw std::runtime_error("Saved profile did not match requested values. Backup is available; runtime activation is unknown");
    impl_->logger("apply_verified",",\"profile\":"+Json(Utf8(after.profile))+",\"mode_index\":"+std::to_string(static_cast<unsigned>(mode))+",\"verification\":\"fresh_driver_session_readback\",\"runtime_mfg_verified\":false");
    return backup;
}
void Controller::Restore(std::wstring const& exe, fs::path const& path) {
    if (SimulatorRunning()) throw std::runtime_error("Close MSFS before restoring settings");
    auto backup=LoadBackup(path);
    if (backup.executable!=exe) throw std::runtime_error("Backup belongs to a different executable selection");
    Session session(impl_->api); auto profile=session.Find(exe); auto current=session.Read(profile);
    if (current.profile!=backup.before.profile) throw std::runtime_error("Backup belongs to a different driver profile");
    for(size_t i=0;i<ids.size();++i) {
        Value expected{ids[i],backup.desired[i],true};
        if (!SameLocal(current.values[i],expected) && !SameLocal(current.values[i],backup.before.values[i]))
            throw std::runtime_error("An MFG setting was changed outside this operation. Restore stopped to preserve that change");
    }
    for(auto v:backup.before.values) session.Write(profile,v);
    session.Save(); auto after=Read(exe);
    for(size_t i=0;i<ids.size();++i) if(!SameLocal(after.values[i],backup.before.values[i])) throw std::runtime_error("Restore readback did not match backup");
    impl_->logger("restore_verified",",\"profile\":"+Json(Utf8(after.profile)));
}
void Controller::SelfTest() {
    auto suffix=std::to_wstring(GetCurrentProcessId())+L"_"+std::to_wstring(GetTickCount64());
    auto name=L"OptiMFG disposable driver test "+suffix;
    auto exe=L"optimfg_nonexistent_test_"+suffix+L".exe";
    bool created=false;
    auto cleanup=[&] {
        Session s(impl_->api); NvAPI_UnicodeString n{}; Unicode(n,name); NvDRSProfileHandle p{};
        auto result=impl_->api.DRS_FindProfileByName(s.handle,n,&p);
        if(result!=NVAPI_PROFILE_NOT_FOUND) { impl_->api.Check(result,"Find disposable profile"); impl_->api.Check(impl_->api.DRS_DeleteProfile(s.handle,p),"Delete disposable profile"); s.Save(); }
        Session verify(impl_->api); result=impl_->api.DRS_FindProfileByName(verify.handle,n,&p);
        if(result!=NVAPI_PROFILE_NOT_FOUND) throw std::runtime_error("Disposable profile cleanup not verified");
        impl_->logger("test_profile_removed",",\"profile\":"+Json(Utf8(name)));
    };
    try {
        {
            Session s(impl_->api); auto info=std::make_unique<NVDRS_PROFILE>(); info->version=NVDRS_PROFILE_VER; Unicode(info->profileName,name);
            NvDRSProfileHandle profile{}; impl_->api.Check(impl_->api.DRS_CreateProfile(s.handle,info.get(),&profile),"Create disposable profile");
            auto application=std::make_unique<NVDRS_APPLICATION>(); application->version=NVDRS_APPLICATION_VER; Unicode(application->appName,exe);
            impl_->api.Check(impl_->api.DRS_CreateApplication(s.handle,profile,application.get()),"Create disposable application"); s.Save(); created=true;
        }
        auto original=Read(exe);
        for(auto mode:{Mode::Application,Mode::Off,Mode::X2,Mode::X3,Mode::X4,Mode::X5,Mode::X6}) {
            auto backup=Apply(exe,mode,Read(exe)); Restore(exe,backup);
            if(Read(exe).values!=original.values) throw std::runtime_error("Test did not preserve original settings");
        }
        // Exercise restoration of a pre-existing local override, not just removal of new overrides.
        auto first=Apply(exe,Mode::X2,Read(exe)); auto local=Read(exe);
        auto second=Apply(exe,Mode::X4,local); Restore(exe,second);
        if(Read(exe).values!=local.values) throw std::runtime_error("Local override restore failed");
        bool staleBlocked=false; try { Apply(exe,Mode::X3,original); } catch(std::exception const&) { staleBlocked=true; }
        if(!staleBlocked) throw std::runtime_error("Stale reviewed profile accepted");
        {
            Session outside(impl_->api); auto p=outside.Find(exe);
            outside.Write(p,{ids[1],7,true}); outside.Save();
        }
        auto externallyChanged=Read(exe); bool conflictBlocked=false;
        try { Restore(exe,first); } catch(std::exception const&) { conflictBlocked=true; }
        if(!conflictBlocked || Read(exe).values!=externallyChanged.values) throw std::runtime_error("External change was not preserved");
        {
            Session repair(impl_->api); repair.Write(repair.Find(exe),local.values[1]); repair.Save();
        }
        auto badFile=impl_->directory/(L"invalid-"+suffix+L".omfgbackup");
        { std::ofstream bad(badFile); bad << "invalid backup"; }
        bool malformedBlocked=false; try { Restore(exe,badFile); } catch(std::exception const&) { malformedBlocked=true; }
        fs::remove(badFile);
        if(!malformedBlocked || Read(exe).values!=local.values) throw std::runtime_error("Malformed backup changed driver settings");
        Restore(exe,first); cleanup(); created=false;
        impl_->logger("self_test_passed",",\"modes_verified\":7,\"local_restore_verified\":true,\"stale_write_blocked\":true,\"external_change_preserved\":true,\"malformed_backup_blocked\":true,\"game_profile_changed\":false");
    } catch(...) { if(created) { try { cleanup(); } catch(std::exception const& e) { impl_->logger("cleanup_failed",",\"message\":"+Json(e.what())); } } throw; }
}
}
