#include "OptiMFG/HostGpuContract.hpp"
#include <unordered_map>
namespace omfg {
namespace {
std::mutex registryMutex;
std::unordered_map<uint64_t, const HostContract*> registry;
bool validOutput(const Output& o) {
    return o.width && o.height && o.nativeFormat &&
           ((!o.hdr && o.transfer != Transfer::PQ) || (o.hdr && o.transfer != Transfer::SDR_Gamma22));
}
}
std::string_view name(Error e) {
    switch (e) {
    case Error::None: return "ok"; case Error::InvalidState: return "invalid_state";
    case Error::OwnerConflict: return "owner_conflict"; case Error::InvalidFrame: return "invalid_frame";
    case Error::StaleEpoch: return "stale_epoch"; case Error::MissingColor: return "missing_color";
    case Error::InvalidResource: return "invalid_resource"; case Error::SyncFailure: return "sync_failure";
    case Error::Unsupported: return "unsupported";
    }
    return "unknown";
}
HostContract::~HostContract() { releaseOwner(); }
void HostContract::releaseOwner() {
    std::lock_guard lock(registryMutex);
    const auto it = registry.find(owners_.swapchain);
    if (it != registry.end() && it->second == this) registry.erase(it);
    owners_ = {};
}
Result HostContract::initialize(Owners o, GpuOwnership g, Output output) {
    std::lock_guard lock(mutex_);
    if (state_ != Lifecycle::Created && state_ != Lifecycle::Stopped) return {Error::InvalidState};
    if (!o.swapchain || !o.host || o.present != o.host || o.fg != o.host ||
        g.device != o.host || g.queue != o.host || g.commandList != o.host ||
        g.descriptors != o.host || g.fence != o.host) return {Error::OwnerConflict};
    if (!validOutput(output)) return {Error::InvalidResource};
    std::lock_guard ownerLock(registryMutex);
    if (registry.contains(o.swapchain)) return {Error::OwnerConflict};
    registry[o.swapchain] = this;
    owners_ = o; output_ = output; state_ = Lifecycle::Initialized;
    lastId_ = fence_ = 0; timestamp_ = -1;
    return {};
}
Result HostContract::start() {
    std::lock_guard lock(mutex_);
    if (state_ != Lifecycle::Initialized) return {Error::InvalidState};
    state_ = Lifecycle::Running; return {};
}
Result HostContract::accept(const Frame& f) {
    std::lock_guard lock(mutex_);
    auto fail = [&](Error e) { ++rejected_; return Result{e}; };
    if (state_ != Lifecycle::Running) return fail(Error::InvalidState);
    if (f.epoch != epoch_) return fail(Error::StaleEpoch);
    if (f.kind != FrameKind::Real) return fail(Error::Unsupported);
    if (!f.id || f.id != lastId_ + 1 || f.timestampNs < 0 || f.timestampNs <= timestamp_) return fail(Error::InvalidFrame);
    if (!f.completionFence || f.completionFence <= fence_) return fail(Error::SyncFailure);
    if (!f.color.valid) return fail(Error::MissingColor);
    for (const auto* t : {&f.color, &f.depth, &f.motion, &f.hudless, &f.ui}) {
        if ((!t->valid && t->token) || (t->valid && (!t->token || !t->nativeFormat ||
            t->width != output_.width || t->height != output_.height || t->state == ResourceState::Unknown)))
            return fail(Error::InvalidResource);
    }
    if (f.color.nativeFormat != output_.nativeFormat) return fail(Error::InvalidResource);
    lastId_ = f.id; timestamp_ = f.timestampNs; fence_ = f.completionFence;
    ++accepted_; if (f.sceneCut) ++bypassed_;
    return {};
}
Result HostContract::drain() {
    std::lock_guard lock(mutex_);
    if (state_ != Lifecycle::Running && state_ != Lifecycle::Initialized) return {Error::InvalidState};
    state_ = Lifecycle::Draining; return {};
}
Result HostContract::stop(uint64_t completed) {
    std::lock_guard lock(mutex_);
    if (state_ != Lifecycle::Draining) return {Error::InvalidState};
    if (completed < fence_) return {Error::SyncFailure};
    releaseOwner(); state_ = Lifecycle::Stopped; ++epoch_; return {};
}
Result HostContract::recreate(Output output, uint64_t completed) {
    std::lock_guard lock(mutex_);
    if (state_ != Lifecycle::Draining) return {Error::InvalidState};
    if (completed < fence_) return {Error::SyncFailure};
    if (!validOutput(output)) return {Error::InvalidResource};
    output_ = output; ++epoch_; lastId_ = 0; timestamp_ = -1;
    state_ = Lifecycle::Initialized; return {};
}
void HostContract::deviceLost() {
    std::lock_guard lock(mutex_);
    releaseOwner(); ++epoch_; state_ = Lifecycle::Stopped;
}
Snapshot HostContract::snapshot() const {
    std::lock_guard lock(mutex_);
    return {state_, epoch_, accepted_, bypassed_, rejected_, fence_};
}
}
