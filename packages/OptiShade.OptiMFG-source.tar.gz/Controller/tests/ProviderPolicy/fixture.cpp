extern "C" __declspec(dllexport) void NVSDK_NGX_D3D12_PopulateDeviceParameters_Impl() {}
#ifdef SR_SIBLING
extern "C" __declspec(dllexport) void NVSDK_NGX_DirectSR_Create() {}
#endif
