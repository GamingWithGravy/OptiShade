#include "dlssg_provider_policy.h"
#include <iostream>
#include <string>
int wmain(int argc,wchar_t** argv) {
    if(argc!=3)return 1;
    auto module=LoadLibraryExW(argv[1],nullptr,DONT_RESOLVE_DLL_REFERENCES);
    if(!module)return 2;
    using namespace dlssg_provider_policy;
    VersionTriplet loaded{},disk{},missing{};
    const std::wstring kind=argv[2];
    bool expected=kind==L"supported";
    bool resource=kind!=L"unversioned";
    bool ok=ReadLoadedProviderVersion(module,loaded)==resource;
    ok &= ReadProviderVersion(argv[1],disk)==resource;
    if(resource)ok &= loaded.major==disk.major && loaded.minor==disk.minor && loaded.build==disk.build;
    // Simulate a file path which cannot be opened. Admission must still use
    // the mapped image, and must never turn unknown/sibling providers on.
    const wchar_t* inaccessible=L"Z:\\OptiMFG-nonexistent-provider\\missing.dll";
    ok &= !ReadProviderVersion(inaccessible,missing);
    ok &= IsSupportedProvider(module,inaccessible)==expected;
    ok &= IsSupportedProvider(module,argv[1])==expected;
    ok &= !ReadLoadedProviderVersion(nullptr,missing);
    std::wcout<<kind<<L" loaded version "<<loaded.major<<L'.'<<loaded.minor<<L'.'<<loaded.build<<L" result="<<ok<<L'\n';
    FreeLibrary(module);
    return ok?0:3;
}
