// OptiMFG patch engine: a detoured plugin must unload with its loader and a
// reloaded copy (usually at the same base) must be patched again.
#include "patcher.cpp"
#include <iostream>
static int WINAPI HotHook(int x) { return x + 100; }
static int WINAPI RelHook(int x) { return x + 200; }
#define CHECK(c, m) do { if (!(c)) { std::cerr << "FAIL: " << m << " (round " << round << ")\n"; return 1; } } while (0)
int main()
{
    using Fn = int (*)(int);
    uintptr_t firstBase = 0;
    int sameBase = 0;
    for (int round = 0; round < 40; ++round)
    {
        HMODULE plugin = LoadLibraryW(L"FakePlugin.dll");
        CHECK(plugin, "LoadLibrary");
        if (!firstBase) firstBase = reinterpret_cast<uintptr_t>(plugin);
        else if (reinterpret_cast<uintptr_t>(plugin) == firstBase) ++sameBase;
        auto hot = reinterpret_cast<Fn>(GetProcAddress(plugin, "HotTarget"));
        auto rel = reinterpret_cast<Fn>(GetProcAddress(plugin, "RelTarget"));
        CHECK(hot && rel && hot(1) == 2 && rel(1) == 2, "fresh copy runs unpatched");

        entry_detour::InstallOptions strict{}; strict.generation = 1000 + round;
        entry_detour::InstallOptions relocated{}; relocated.generation = 1000 + round; relocated.allowRelocated = true;
        void* hotOriginal = nullptr; void* relOriginal = nullptr;
        entry_detour::Handle hotHandle{}, relHandle{};
        CHECK(entry_detour::Install(entry_detour::Kind::eDlssgSetOptions, plugin, reinterpret_cast<void*>(hot),
            reinterpret_cast<void*>(&HotHook), hotOriginal, strict, &hotHandle), "hotpatch install on this copy");
        CHECK(entry_detour::Install(entry_detour::Kind::eSlGetData, plugin, reinterpret_cast<void*>(rel),
            reinterpret_cast<void*>(&RelHook), relOriginal, relocated, &relHandle), "relocated install on this copy");
        CHECK(hot(1) == 101 && rel(1) == 201, "both entries route to the hooks");
        CHECK(reinterpret_cast<Fn>(hotOriginal)(1) == 2 && reinterpret_cast<Fn>(relOriginal)(1) == 2, "trampolines call the originals");
        CHECK(entry_detour::ReadSnapshot(hotHandle).current && entry_detour::ReadSnapshot(relHandle).current, "snapshots current");
        if (round == 0)
            std::cout << "methods: " << entry_detour::MethodName(entry_detour::ReadSnapshot(hotHandle).method)
                      << " / " << entry_detour::MethodName(entry_detour::ReadSnapshot(relHandle).method) << "\n";

        // Control routes for this wrapper copy, then Windows reports it unloaded.
        const uint32_t route = EnsureControlRoute(plugin, L"FakePlugin.dll", 1000 + round, true, 3);
        CHECK(route != UINT32_MAX, "control route available (routes recycled)");
        MfgLdrDllNotificationData unloaded{}; unloaded.unloaded.dllBase = plugin;

        FreeLibrary(plugin);
        CHECK(!GetModuleHandleW(L"FakePlugin.dll"), "plugin unloads with its loader (no permanent pin)");
        OnDllNotification(2, &unloaded, nullptr);
        ForgetUnloadedModules();
        CHECK(!gControlRoutes[route].claimed.load(), "unloaded wrapper's control route released");
        // Reading the patch state of an unmapped copy must be safe and report stale.
        CHECK(!entry_detour::ReadSnapshot(hotHandle).current && !entry_detour::ReadSnapshot(relHandle).current,
            "unloaded copy reported not current");
    }
    std::cout << "PASS: 40 unload/reload rounds (" << sameBase << " reloaded at the same base), hotpatch + relocated re-patched each time, "
              << "plugin not pinned, control routes recycled, stale entries safe to read\n";
    return 0;
}
