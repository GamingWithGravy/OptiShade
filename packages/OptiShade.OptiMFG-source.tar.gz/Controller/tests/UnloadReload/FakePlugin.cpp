// Stand-in for a Streamline plugin that the patch engine detours and that
// Streamline later unloads and reloads (OSD-ASBJ/PC48/Q5MS).
#include <Windows.h>
extern "C" __declspec(dllexport) __declspec(noinline) int RelTarget(int x)
{
    volatile int value = x;
    volatile int other = value * 3;
    return value + other - value * 3 + 1;
}
BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID) { return TRUE; }
