; Entry with the DLSS-G public prologue (sub rsp,58h) and 0xCC padding before it,
; the shape OptiMFG hotpatches in NVIDIA's frame-generation plugin.
_TEXT SEGMENT ALIGN(16) 'CODE'
ALIGN 16
    db 16 dup (0CCh)
HotTarget PROC
    sub rsp, 58h
    lea eax, [rcx+1]
    add rsp, 58h
    ret
HotTarget ENDP
_TEXT ENDS
END
