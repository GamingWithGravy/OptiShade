#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vulkan/vulkan.h>
#include <mutex>
#include <string>
#include <cstring>
#include <cassert>
#include <iostream>
static std::string captured;
static void Log(const std::string& s){captured+=s;}
#include "../tools/Xp12Runtime/FrameTrace.h"
#include "../tools/Xp12Runtime/ShaderTrace.h"
#include <vector>
#include <fstream>
#include <filesystem>
static VkResult nextResult=VK_SUCCESS;
static uint64_t nextImage=100;
static unsigned creates=0,destroys=0;
static VkResult VKAPI_CALL Make(VkDevice,const VkImageCreateInfo*,const VkAllocationCallbacks*,VkImage* out){++creates;if(nextResult==VK_SUCCESS)*out=(VkImage)++nextImage;return nextResult;}
static void VKAPI_CALL Drop(VkDevice,VkImage,const VkAllocationCallbacks*){++destroys;}
static unsigned dispatches=0,templateWrites=0;
static VkResult VKAPI_CALL FakeCreateTemplate(VkDevice,const VkDescriptorUpdateTemplateCreateInfo*,const VkAllocationCallbacks*,VkDescriptorUpdateTemplate* out){*out=(VkDescriptorUpdateTemplate)555;return VK_SUCCESS;}
static void VKAPI_CALL FakeUpdateTemplate(VkDevice,VkDescriptorSet,VkDescriptorUpdateTemplate,const void*){++templateWrites;}
static void VKAPI_CALL FakeDestroyTemplate(VkDevice,VkDescriptorUpdateTemplate,const VkAllocationCallbacks*){}
static void VKAPI_CALL FakeIndirect(VkCommandBuffer,VkBuffer,VkDeviceSize){++dispatches;}
static void VKAPI_CALL FakeDispatch(VkCommandBuffer,uint32_t,uint32_t,uint32_t){++dispatches;}
int main(){
 using namespace xpframe;
 imageCreate=Make;imageDestroy=Drop;
 VkDevice device=(VkDevice)1;VkSwapchainKHR chain=(VkSwapchainKHR)2;
 VkSwapchainCreateInfoKHR ci{};ci.imageExtent={3840,2160};ci.imageFormat=VK_FORMAT_B8G8R8A8_UNORM;
 Swapchain(device,&ci,chain);
 VkImageCreateInfo ii{};ii.format=VK_FORMAT_R16G16B16A16_SFLOAT;ii.extent={1920,1080,1};ii.usage=VK_IMAGE_USAGE_STORAGE_BIT;ii.arrayLayers=2;ii.samples=VK_SAMPLE_COUNT_1_BIT;
 VkImage a{};assert(CreateImage(device,&ii,nullptr,&a)==VK_SUCCESS);
 VkImage b{};assert(CreateImage((VkDevice)3,&ii,nullptr,&b)==VK_SUCCESS);
 nextResult=VK_ERROR_OUT_OF_DEVICE_MEMORY;VkImage unused{};
 assert(CreateImage(device,&ii,nullptr,&unused)==nextResult&&images.size()==2&&creates==3);
 Acquired(chain,VK_SUCCESS,0,VK_NULL_HANDLE,VK_NULL_HANDLE);
 uint32_t index=0;VkPresentInfoKHR pi{};pi.swapchainCount=1;pi.pSwapchains=&chain;pi.pImageIndices=&index;
 BeforePresent((VkQueue)4,&pi);
 assert(captured.find("extent=1920x1080x1")!=std::string::npos);
 assert(captured.find("layers=2")!=std::string::npos);
 assert(captured.find("shapes=1")!=std::string::npos);
 assert(captured.find("count=2]")==std::string::npos); // foreign device excluded
 captured.clear();chains[Key(chain)].presents=299;
 Acquired(chain,VK_SUCCESS,0,VK_NULL_HANDLE,VK_NULL_HANDLE);BeforePresent((VkQueue)4,&pi);
 assert(captured.find("image_inventory")==std::string::npos); // unchanged inventory suppressed
 DestroyImage(device,a,nullptr);assert(destroys==1&&images.size()==1);
 captured.clear();chains[Key(chain)].presents=599;
 Acquired(chain,VK_SUCCESS,0,VK_NULL_HANDLE,VK_NULL_HANDLE);BeforePresent((VkQueue)4,&pi);
 assert(captured.find("shapes=0")!=std::string::npos);
 std::vector<uint32_t> spv={0x07230203,0x10000,0,10,0,(5u<<16)|5,7,0,0,0,(4u<<16)|71,7,34,0,(4u<<16)|71,7,33,4};
 std::memcpy(spv.data()+7,"gbuffer_vel",12);
 assert(ClassifyVelocityInput(spv.data(),spv.size()*4)==VelocityInputKind::Unknown);
 const std::vector<uint32_t> typeWords={(3u<<16)|22,1,32,(9u<<16)|25,2,1,1,0,0,0,1,0,(3u<<16)|27,3,2,(4u<<16)|32,4,0,3,(4u<<16)|59,4,7,0};
 spv.insert(spv.end(),typeWords.begin(),typeWords.end());
 assert(HasVelocityBinding(spv.data(),spv.size()*4));
 auto integerSpv=spv;
 integerSpv[18]=(4u<<16)|21;integerSpv.insert(integerSpv.begin()+21,0);
 assert(ClassifyVelocityInput(integerSpv.data(),integerSpv.size()*4)==VelocityInputKind::IntegerImage);
 assert(!HasVelocityBinding(integerSpv.data(),integerSpv.size()*4));
 spv[17]=5;assert(!HasVelocityBinding(spv.data(),spv.size()*4));spv[17]=4;
 assert(!HasVelocityBinding(spv.data(),spv.size()*4-4));
 auto broken=spv;broken[5]=0;assert(!HasVelocityBinding(broken.data(),broken.size()*4));
 dispatch=FakeDispatch;
 images[999]={1,VK_FORMAT_R16G16_SFLOAT,{1920,1080,1},VK_IMAGE_USAGE_SAMPLED_BIT,1,1};
 views[111]={999,1};descriptorImages[222]={111,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
 commands[333]={444,222,777};computeLayouts[444]=777;pipelineSetLayouts[777]=888;descriptorImages[222].setLayout=888;velocityPipelines.insert(444);captured.clear();
 Dispatch((VkCommandBuffer)333,1,1,1);
 assert(dispatches==1&&captured.find("velocity_binding_observation image=999")!=std::string::npos);
 assert(captured.find("stage=RECORDED_ONLY")!=std::string::npos);
 captured.clear();Dispatch((VkCommandBuffer)333,1,1,1);assert(dispatches==2&&captured.empty());
 reportedImages.clear();views[111].device=2;Dispatch((VkCommandBuffer)333,1,1,1);assert(dispatches==3&&captured.empty());
 createTemplate=FakeCreateTemplate;updateTemplate=FakeUpdateTemplate;destroyTemplate=FakeDestroyTemplate;dispatchIndirect=FakeIndirect;
 VkDescriptorUpdateTemplateEntry entry{};entry.dstBinding=4;entry.descriptorCount=1;entry.descriptorType=VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;entry.offset=3;
 VkDescriptorUpdateTemplateCreateInfo tci{};tci.descriptorSetLayout=(VkDescriptorSetLayout)888;tci.templateType=VK_DESCRIPTOR_UPDATE_TEMPLATE_TYPE_DESCRIPTOR_SET;tci.descriptorUpdateEntryCount=1;tci.pDescriptorUpdateEntries=&entry;
 VkDescriptorUpdateTemplate tmpl{};assert(CreateTemplate(device,&tci,nullptr,&tmpl)==VK_SUCCESS);
 unsigned char payload[3+sizeof(VkDescriptorImageInfo)]{};VkDescriptorImageInfo imageInfo{};imageInfo.imageView=(VkImageView)111;imageInfo.imageLayout=VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
 std::memcpy(payload+3,&imageInfo,sizeof(imageInfo));UpdateTemplate(device,(VkDescriptorSet)222,tmpl,payload);
 assert(templateWrites==1&&descriptorImages.at(222).view==111);
 views[111].device=1;captured.clear();DispatchIndirect((VkCommandBuffer)333,(VkBuffer)99,64);
 assert(dispatches==4&&captured.find("image=999")!=std::string::npos);
 DestroyTemplate(device,tmpl,nullptr);UpdateTemplate(device,(VkDescriptorSet)222,tmpl,payload);
 assert(templateWrites==2&&!descriptorImages.count(222));
 reportedImages.clear();descriptorImages[222]={111,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,999};captured.clear();
 Dispatch((VkCommandBuffer)333,1,1,1);
 assert(captured.find("layout_provenance_unverified")!=std::string::npos&&captured.find("velocity_binding_observation")==std::string::npos);
 assert(dispatches==5); // Unqualified metadata must never suppress the real dispatch.
 unsigned realShaders=0;
 for(const auto& entry:std::filesystem::directory_iterator("shader-classification-fixture")){
  std::ifstream file(entry.path(),std::ios::binary|std::ios::ate);auto size=file.tellg();file.seekg(0);
  std::vector<uint32_t> words(static_cast<size_t>(size)/4);file.read(reinterpret_cast<char*>(words.data()),size);
  assert(ClassifyVelocityInput(words.data(),static_cast<size_t>(size))==VelocityInputKind::IntegerImage);++realShaders;
 }
 assert(realShaders==24);
 std::cout<<"PASS: all 24 installed SSR shaders rejected as integer images;  mismatched descriptor layout rejected with dispatch preserved;  descriptor template offset decoding, destroy invalidation, indirect forwarding;  shader binding recognition, malformed input rejection, recorded image observation, device mismatch, dispatch forwarding;  scaled/packed/array inventory, device isolation, failed creation, destruction, unchanged suppression\n";
}
