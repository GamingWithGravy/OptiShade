#include "DiagnosticsZip.hpp"
#include <iostream>
int wmain(int argc,wchar_t** argv){try{if(argc!=3)return 2;ZipDiagnostics(argv[1],argv[2]);std::cout<<"ZIP created\n";return 0;}catch(std::exception const& e){std::cerr<<e.what();return 1;}}
