#include "OptiMfgPreferences.h"
#include <filesystem>
#include <iostream>
int main(){
    wchar_t temp[MAX_PATH]{};if(!GetTempPathW(MAX_PATH,temp))return 1;
    auto folder=std::filesystem::path(temp)/(L"OptiMfgPreferences-"+std::to_wstring(GetCurrentProcessId()));
    auto file=folder/L"controls.ini";
    using namespace optishade::optimfg;
    if(LoadPreference(file.wstring())!=-1)return 2;
    for(LONG value:{2,3,6,0,-1})if(!SavePreference(file.wstring(),value)||LoadPreference(file.wstring())!=value)return 3;
    if(SavePreference(file.wstring(),7)||LoadPreference(file.wstring())!=-1)return 4;
    // The parent is an existing file: saving must fail, not claim persistence.
    if(SavePreference((file/L"blocked.ini").wstring(),3))return 5;
    if(!DeleteFileW(file.c_str())||!RemoveDirectoryW(folder.c_str()))return 6;
    std::cout<<"Preference write/readback, restart load, invalid value and access failure passed\n";
}
