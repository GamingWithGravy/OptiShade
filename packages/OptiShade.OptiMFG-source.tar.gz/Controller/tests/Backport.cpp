#include "Backport.hpp"
#include <iostream>
using omfg::live::Backport;
static void Require(bool value,char const* why){if(!value)throw std::runtime_error(why);}
template<class F> void Reject(F f){bool rejected=false;try{f();}catch(...){rejected=true;}Require(rejected,"Invalid input accepted");}
int main(){try{
    auto now=Backport::Now();Backport::Json j={{"version",41},{"pid",123},{"processBirth",456},{"heartbeat",now},{"safeMaximumMultiplier",6},{"gpuFamily",1},{"bridgeReady",true},{"gameFrameGenerationOn",true},{"appliedFrameGenerationOn",true},{"followGame",true},{"setOptionsAccepted",true},{"pending",false}};
    for(int family:{1,2,4,5}){j["gpuFamily"]=family;Backport::Validate(j,123,456,now);}
    for(int family:{1,2,4}){j["gpuFamily"]=family;Backport::ValidateRouteFamily(Backport::Route::MfgUnlocker,j);}
    for(int family:{0,5}){j["gpuFamily"]=family;Reject([&]{Backport::ValidateRouteFamily(Backport::Route::MfgUnlocker,j);});}
    for(int family:{2,4}){j["gpuFamily"]=family;Backport::ValidateRouteFamily(Backport::Route::Headless,j);}
    for(int family:{1,5}){j["gpuFamily"]=family;Reject([&]{Backport::ValidateRouteFamily(Backport::Route::Headless,j);});}
    Reject([&]{Backport::Validate(j,124,456,now);});Reject([&]{Backport::Validate(j,123,457,now);});Reject([&]{Backport::Validate(j,123,456,now+6);});Reject([&]{Backport::Validate(j,123,456,now-1);});
    auto bad=j;bad["version"]=42;Reject([&]{Backport::Validate(bad,123,456,now);});
    bad=j;bad["gpuFamily"]=3;Reject([&]{Backport::Validate(bad,123,456,now);});
    bad=j;bad["safeMaximumMultiplier"]=7;Reject([&]{Backport::Validate(bad,123,456,now);});
    bad=j;bad.erase("bridgeReady");Reject([&]{Backport::Validate(bad,123,456,now);});
    auto h=j;h["version"]=1801;h["externalUiOnly"]=true;h.erase("gpuFamily");h.erase("appliedFrameGenerationOn");
    auto oldSession=h;oldSession["pid"]=999;
    bool retryable=false;try{Backport::ValidateHeadless(oldSession,123,456,now);}catch(std::exception const& e){retryable=omfg::live::RetryAutoConnect(e.what());}
    Require(retryable,"Old headless session permanently stops auto-connect");
    Backport::ValidateHeadless(h,123,456,now);

    Backport::ValidateHeadless(h,123,456,now);
    Reject([&]{Backport::ValidateHeadless(h,123,457,now);});Reject([&]{Backport::ValidateHeadless(h,123,456,now+6);});
    auto wrong=h;wrong["externalUiOnly"]=false;Reject([&]{Backport::ValidateHeadless(wrong,123,456,now);});
    auto folder=std::filesystem::temp_directory_path()/(L"OptiMFG-backport-test-"+std::to_wstring(GetCurrentProcessId()));std::filesystem::create_directory(folder);
    // A deployed MFG Unlocker can predate OptiMFG's provider marker. Verify
    // that its validated proxy/config pair selects the unlocked route rather
    // than falling through to native Streamline (which is 2x-only on RTX 40).
    auto routeFolder=folder/L"route";std::filesystem::create_directory(routeFolder);
    {std::ofstream proxy(routeFolder/L"version.dll",std::ios::binary);proxy<<"fixture";}
    auto fixtureHash=Backport::Sha256(routeFolder/L"version.dll");
    Backport::Json unlockerConfig={{"version",13},{"followGame",true},{"mode","follow"},{"multiplier",2},{"intervalLogging",true}};
    Backport::Save(routeFolder/L"RTXMFG-Universal.json",unlockerConfig);
    Require(Backport::DetectRoute(routeFolder,fixtureHash)==Backport::Route::MfgUnlocker,"Unmarked pinned MFG Unlocker install selected native Streamline");
    Reject([&]{Backport::DetectRoute(routeFolder);}); // Never mistake an old version.dll for the current MFG provider.
    Backport::Save(routeFolder/L"OptiMFGTest-backend.json",Backport::Json{{"providerVersion","1.7.0"},{"proxy","version.dll"}});
    Require(Backport::DetectRoute(routeFolder,fixtureHash)==Backport::Route::MfgUnlocker,"Valid marked MFG Unlocker route was rejected");
    Reject([&]{Backport::DetectRoute(routeFolder);});
    // OptiShade's own unlocker runs with its UI hidden and follows the game's DLSS-G request,
    // so OptiShade's controls use the native route. Both the marker and its settings must say so.
    Backport::Save(routeFolder/L"OptiMFGTest-backend.json",Backport::Json{{"providerVersion","1.7.0"},{"proxy","version.dll"},{"optiScalerUi","optiscaler"}});
    Require(Backport::DetectRoute(routeFolder,fixtureHash)==Backport::Route::MfgUnlocker,"Marker alone must not assume the unlocker's UI is hidden");
    auto hiddenConfig=unlockerConfig;hiddenConfig["optiScalerUi"]="optiscaler";Backport::Save(routeFolder/L"RTXMFG-Universal.json",hiddenConfig);
    Require(Backport::DetectRoute(routeFolder,fixtureHash)==Backport::Route::Native,"OptiShade's hidden-UI unlocker did not select native control");
    Reject([&]{Backport::DetectRoute(routeFolder);}); // Still only the pinned unlocker.
    Backport::Save(routeFolder/L"RTXMFG-Universal.json",unlockerConfig);
    Backport::Save(routeFolder/L"OptiMFGTest-backend.json",Backport::Json{{"providerVersion","1.7.0"},{"proxy","version.dll"}});
    std::filesystem::remove(routeFolder/L"OptiMFGTest-backend.json");
    std::filesystem::remove(routeFolder/L"version.dll");
    Reject([&]{Backport::DetectRoute(routeFolder);}); // A leftover provider config must not silently select native.
    {std::ofstream proxy(routeFolder/L"version.dll",std::ios::binary);proxy<<"fixture";}
    auto incomplete=unlockerConfig;incomplete.erase("intervalLogging");Backport::Save(routeFolder/L"RTXMFG-Universal.json",incomplete);
    Reject([&]{Backport::DetectRoute(routeFolder);}); // Unknown proxy/config pairs must not fall through to native.
    std::filesystem::remove(routeFolder/L"RTXMFG-Universal.json");
    Reject([&]{Backport::DetectRoute(routeFolder);}); // Proxy only is ambiguous too.
    std::filesystem::remove(routeFolder/L"version.dll");
    Require(Backport::DetectRoute(routeFolder)==Backport::Route::Native,"Clean game folder did not select native Streamline");
    std::filesystem::remove_all(routeFolder);
    Backport b;b.folder=folder;b.pid=123;b.birth=456;j["gpuFamily"]=2;
    Backport::Save(folder/L"RTXMFG-Universal.status.json",j);
    Backport::Json config={{"version",13},{"followGame",true},{"mode","follow"},{"multiplier",2},{"dlssSrPreset",12},{"futureSetting",{{"preserve",true}}}};
    Backport::Save(folder/L"RTXMFG-Universal.json",config);
    j["gpuFamily"]=1;Backport::Save(folder/L"RTXMFG-Universal.status.json",j);
    for(int n:{2,3,4,5,6,-1}){b.Request(n);auto saved=Backport::ReadFile(folder/L"RTXMFG-Universal.json");Require(saved["multiplier"]==(n<0?2:n),"Release/multiplier mapping wrong");Require(saved["followGame"]==(n==-1),"Follow-game mapping wrong");Require(saved["futureSetting"]==config["futureSetting"]&&saved["dlssSrPreset"]==12,"Unrelated settings changed");}
    Reject([&]{b.Request(0);});
    j["gpuFamily"]=2;Backport::Save(folder/L"RTXMFG-Universal.status.json",j);b.Request(3); // RTX 30 is on the unlocker route
    j["gpuFamily"]=5;Backport::Save(folder/L"RTXMFG-Universal.status.json",j);Reject([&]{b.Request(2);}); // RTX 50 stays native
    j["gpuFamily"]=1;Backport::Save(folder/L"RTXMFG-Universal.status.json",j);
    j["bridgeReady"]=false;Backport::Save(folder/L"RTXMFG-Universal.status.json",j);Reject([&]{b.Request(2);});b.Request(-1);
    j["bridgeReady"]=true;j["safeMaximumMultiplier"]=2;Backport::Save(folder/L"RTXMFG-Universal.status.json",j);Reject([&]{b.Request(4);});
    j["heartbeat"]=now-10;Backport::Save(folder/L"RTXMFG-Universal.status.json",j);Reject([&]{b.Request(2);});b.Request(-1); // release remains available with stale status
    auto path=folder/L"RTXMFG-Universal.json";auto before=Backport::ReadFile(path);auto big=before;big["large"]=std::string(5000,'x');Reject([&]{Backport::Save(path,big);});Require(Backport::ReadFile(path)==before,"Oversize write damaged settings");
    b.headless=true;Backport::Save(b.ConfigPath(),config);Backport::Save(b.StatusPath(),h);
    h["bridgeReady"]=false;h["universalRouteFailureReason"]="provider Evaluate not covered";Backport::Save(b.StatusPath(),h);
    bool explained=false;try{b.Request(4);}catch(std::exception const& e){explained=std::string(e.what()).find("provider Evaluate not covered")!=std::string::npos;}
    Require(explained,"Backend refusal hides the specific provider failure");
    h["bridgeReady"]=true;Backport::Save(b.StatusPath(),h);
    b.Request(4);Require(Backport::ReadFile(b.ConfigPath())["multiplier"]==4,"Menu-free request not written");Reject([&]{b.Request(0);});b.Request(-1);
    Require(Backport::ReadFile(b.ConfigPath())["followGame"]==true,"Menu-free release failed");
    Require(Backport::ReadFile(path)==before,"Menu-free request changed other backend");
    std::filesystem::remove(b.ConfigPath());std::filesystem::remove(b.StatusPath());
    std::filesystem::remove(path);std::filesystem::remove(folder/L"RTXMFG-Universal.status.json");std::filesystem::remove(folder);
    std::cout<<"Backport transport passed: RTX families, process identity, freshness, protocol, limits, atomic config, preservation and release. No GPU execution tested.\n";return 0;
}catch(std::exception const& e){std::cerr<<e.what()<<'\n';return 1;}}
