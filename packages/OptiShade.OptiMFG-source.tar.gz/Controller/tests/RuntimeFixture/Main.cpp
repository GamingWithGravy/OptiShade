#include <windows.h>
#include <sl.h>
#include <sl_dlss_g.h>
#include <iostream>
extern "C" __declspec(dllimport) void FixtureMaximum(unsigned);
extern "C" __declspec(dllimport) void FixtureDelay(unsigned);
struct Token:sl::FrameToken {operator uint32_t()const override{return 1;}};
int main(int argc,char** argv){
    FixtureMaximum(argc>1?static_cast<unsigned>(std::stoul(argv[1])):5);
    void* set{},*state{};slGetFeatureFunction(sl::kFeatureDLSS_G,"slDLSSGSetOptions",set);slGetFeatureFunction(sl::kFeatureDLSS_G,"slDLSSGGetState",state);
    if(argc>2)FixtureDelay(static_cast<unsigned>(std::stoul(argv[2])));
    sl::ViewportHandle vp(17);sl::DLSSGOptions options;sl::DLSSGOptions extension;
    options.mode=sl::DLSSGMode::eOn;options.colorWidth=1920;options.colorHeight=1080;options.dynamicTargetFrameRate=120;options.next=&extension;
    std::cout<<"Controlled test fixture; PID "<<GetCurrentProcessId()<<std::endl;
    Token token;int fakeNative{};sl::Resource resource(sl::ResourceType::eTex2d,&fakeNative);
    sl::ResourceTag tag(&resource,sl::kBufferTypeMotionVectors,sl::eValidUntilPresent);
    for(int i=0;i<3000;++i){if(slSetTagForFrame(token,vp,&tag,1,nullptr)!=sl::Result::eOk)return 3;
        sl::DLSSGState s;reinterpret_cast<PFun_slDLSSGGetState*>(state)(vp,s,nullptr);
        sl::DLSSGState failed;reinterpret_cast<PFun_slDLSSGGetState*>(state)(vp,failed,&options);
        reinterpret_cast<PFun_slDLSSGGetState*>(state)(vp,failed,&options);
        if(reinterpret_cast<PFun_slDLSSGSetOptions*>(set)(vp,options)!=sl::Result::eOk)return 2;Sleep(16);}
    return 0;
}
