#include <sl.h>
#include <sl_dlss_g.h>
#include <cstring>
#include <atomic>
static std::atomic<unsigned> delayedLookups{0};
extern "C" __declspec(dllexport) void FixtureDelay(unsigned value){delayedLookups=value;}
static std::atomic<unsigned> maximum{5},mode{1},count{1};
extern "C" __declspec(dllexport) sl::Result slSetTagForFrame(sl::FrameToken const&,sl::ViewportHandle const& viewport,sl::ResourceTag const* tags,uint32_t number,sl::CommandBuffer*){
    if(static_cast<uint32_t>(viewport)!=17||number!=1||!tags||tags[0].type!=sl::kBufferTypeMotionVectors)return sl::Result::eErrorInvalidParameter;
    return sl::Result::eOk;
}
extern "C" __declspec(dllexport) void FixtureMaximum(unsigned value){maximum=value;}
static __declspec(noinline) sl::Result Set(sl::ViewportHandle const& viewport,sl::DLSSGOptions const& o){
    if(static_cast<uint32_t>(viewport)!=17||o.colorWidth!=1920||o.colorHeight!=1080||o.dynamicTargetFrameRate!=120.0f||!o.next)return sl::Result::eErrorInvalidParameter;
    mode=static_cast<unsigned>(o.mode);count=o.numFramesToGenerate;return sl::Result::eOk;
}
static __declspec(noinline) sl::Result State(sl::ViewportHandle const&,sl::DLSSGState& s,sl::DLSSGOptions const* options){if(options)return sl::Result::eErrorInvalidParameter;s.status=sl::DLSSGStatus::eOk;s.numFramesToGenerateMax=maximum;s.numFramesActuallyPresented=mode==1?count+1:1;return sl::Result::eOk;}
extern "C" __declspec(dllexport) sl::Result slGetFeatureFunction(sl::Feature feature,char const* name,void*& function){
    if(delayedLookups.load()>0){--delayedLookups;function=nullptr;return sl::Result::eErrorNotInitialized;}
    if(feature!=sl::kFeatureDLSS_G)return sl::Result::eErrorInvalidParameter;
    if(!strcmp(name,"slDLSSGSetOptions"))function=reinterpret_cast<void*>(&Set);
    else if(!strcmp(name,"slDLSSGGetState"))function=reinterpret_cast<void*>(&State);else return sl::Result::eErrorInvalidParameter;
    return sl::Result::eOk;
}
