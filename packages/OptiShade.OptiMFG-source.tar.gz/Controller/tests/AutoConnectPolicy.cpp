﻿#include "../tools/LiveRuntime/AutoConnectPolicy.hpp"
#include "../tools/LiveRuntime/SimReadinessPolicy.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>

int main() {
    using omfg::live::BackendOutputWarning;
    assert(BackendOutputWarning(true,false,false,false,true,false,-1,0,0,0,0,0)==300);
    assert(BackendOutputWarning(false,true,true,true,false,true,3,40000,41000,4,1000,100)==301);
    assert(BackendOutputWarning(false,true,true,true,false,true,3,40000,120000,4,1000,100)==0);
    assert(BackendOutputWarning(false,false,true,true,false,true,3,40000,41000,4,1000,100)==0);
    assert(BackendOutputWarning(false,true,true,true,true,true,3,40000,41000,4,1000,100)==0);
    assert(BackendOutputWarning(false,true,true,true,false,false,3,40000,41000,4,1000,100)==0);
    assert(BackendOutputWarning(false,true,true,true,false,true,-1,40000,41000,4,1000,100)==0);
    assert(BackendOutputWarning(false,true,true,true,false,true,3,40000,0,4,1000,100)==0);
    assert(BackendOutputWarning(false,true,true,true,false,true,3,40000,41000,3,1000,100)==0);
    assert(BackendOutputWarning(false,true,true,true,false,true,3,40000,41000,4,1000,3000)==0);
    assert(BackendOutputWarning(false,true,true,true,false,true,3,40000,41000,4,100,100)==0);
    using omfg::live::UniqueRenderingProcess;
    assert(UniqueRenderingProcess({})==0);
    assert(UniqueRenderingProcess({123})==123);
    assert(UniqueRenderingProcess({123,456})==0);

    using omfg::live::RetryAutoConnect;
    using omfg::live::ProviderRoute;
    using omfg::live::SelectProviderRoute;
    using omfg::live::ModeIndexForRequest;
    using omfg::live::RequestForModeIndex;
    assert(SelectProviderRoute(false, "", "") == ProviderRoute::Native);
    assert(SelectProviderRoute(true, "1.7.0", "version.dll") == ProviderRoute::MfgUnlocker);
    assert(SelectProviderRoute(true, "1.2.2-optimfg.1", "version.dll") == ProviderRoute::Headless);
    assert(SelectProviderRoute(true, "1.7.0", "other.dll") == ProviderRoute::Unsupported);
    assert(SelectProviderRoute(true, "unknown", "version.dll") == ProviderRoute::Unsupported);
    for (bool supportsOff : {false, true}) {
        for (int request : {-1, 2, 3, 4, 5, 6}) {
            assert(RequestForModeIndex(ModeIndexForRequest(request, supportsOff), supportsOff) == request);
        }
        if (!supportsOff) {
            bool blocked = false;
            try { (void)ModeIndexForRequest(0, false); } catch (std::out_of_range const&) { blocked = true; }
            assert(blocked);
        } else {
            assert(ModeIndexForRequest(0, true) == 1);
            assert(RequestForModeIndex(1, true) == 0);
        }
    }
    assert(RetryAutoConnect("Streamline is not loaded yet. Wait for MSFS to initialize"));
    assert(RetryAutoConnect("Waiting for menu-free backend to load"));
    assert(RetryAutoConnect("Backend status is stale; waiting for the game"));
    assert(RetryAutoConnect("Backend status is not ready; waiting for the game"));
    assert(RetryAutoConnect("Cannot read backend JSON"));
    assert(RetryAutoConnect("Backend status belongs to an earlier game session; waiting for the game"));
    assert(RetryAutoConnect("Menu-free backend status is stale"));
    assert(!RetryAutoConnect("Unsupported menu-free backend protocol"));
    assert(!RetryAutoConnect("Helper already present but not ready. Inspect helper log; restart the game before retrying"));
    assert(!RetryAutoConnect("Cannot open simulator for helper attachment"));
    using omfg::live::StableSimulationRunning;
    assert(!StableSimulationRunning(false, 1000, 7000));
    assert(!StableSimulationRunning(true, 1000, 5999));
    assert(StableSimulationRunning(true, 1000, 6000));
    assert(!StableSimulationRunning(true, 7000, 6000));
}
