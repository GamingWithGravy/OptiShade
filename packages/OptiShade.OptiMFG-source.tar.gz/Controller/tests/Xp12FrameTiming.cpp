#include "../tools/Xp12Runtime/FrameTiming.h"
#include <cassert>
#include <iostream>
int main(){
 xpframe::Timing t;t.Reset(10);
 assert(t.Acquire(2,100,9,0));assert(t.Acquire(0,101,8,0));
 auto b=t.Present(0),a=t.Present(2);assert(b.frame==2&&a.frame==1&&a.semaphore==9);
 assert(!t.Present(2).frame&&t.invalid);
 t.Reset(11);assert(!t.invalid&&!t.Present(0).frame);
 t.Reset(12);assert(t.Acquire(1,200,3,4));assert(!t.Acquire(1,201,3,4)&&t.invalid);
 t.Reset(13);assert(!t.Acquire(16,200,3,4)&&t.invalid);
 t.Reset(14);assert(t.Acquire(1,300,3,4));assert(t.Present(1).frame>2);
 std::cout<<"PASS: image identity, reordering, duplicate/stale rejection, resize reset and bounds\n";
}
