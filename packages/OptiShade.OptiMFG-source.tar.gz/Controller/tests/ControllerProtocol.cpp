#include <OptiMFG/ControllerProtocol.hpp>
#include <iostream>
#include <stdexcept>
using namespace omfg::controller;
static void Require(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
int main(){try{
    const auto pid=GetCurrentProcessId();Channel server,client;State s;
    Require(!client.Open(pid),"No controller must mean waiting");
    Require(server.Open(pid,true)&&client.Open(pid),"Open controller channel");
    Require(client.Snapshot(s)&&!s.connected,"Not connected before helper ready");
    Require(!client.Request(4),"Reject requests before connected");
    server.Update([](auto& x){x.connected=1;x.maximumGenerated=5;});
    Require(client.Request(4),"Send request");
    Require(!client.Request(2),"Do not overwrite unconsumed command");
    Require(server.Snapshot(s)&&s.request==4&&s.appliedSequence==0,"Queue is not application acknowledgement");
    server.Update([](auto& x){x.receivedSequence=x.commandSequence;x.commandResult=1;});
    Require(client.Snapshot(s)&&s.appliedSequence!=s.commandSequence,"EXE acceptance is not provider acknowledgement");
    server.Update([](auto& x){x.appliedSequence=x.commandSequence;});
    Require(client.Snapshot(s)&&s.appliedSequence==s.commandSequence,"Provider acknowledgement propagates");
    Require(!client.Request(7),"Reject invalid multiplier");
    s.heartbeat=0xfffffff0;Require(Fresh(s,pid,0x10),"Tick wrap remains fresh");Require(!Fresh(s,pid,3000),"Expired lease disconnects");
    server.Close();Sleep(LeaseMs+20);
    Require(!client.Snapshot(s)&&!client.Request(2),"Dead controller must disconnect even if mapping survives");
    Require(server.Open(pid,true),"Restart reclaims expired mapping");
    Require(client.Snapshot(s)&&!s.connected&&s.commandSequence==0,"Restart discards stale pending commands");
    std::cout<<"Controller IPC lifecycle, request/ack separation and expiry passed\n";return 0;
}catch(std::exception const& e){std::cerr<<e.what()<<'\n';return 1;}}
