#include "patcher.cpp"
#include <iostream>
static int setters=0,queries=0;
static sl::Result SetStub(const sl::ViewportHandle&,const sl::DLSSGOptions&){++setters;return sl::Result::eOk;}
static sl::Result GetStub(const sl::ViewportHandle&,sl::DLSSGState&,const sl::DLSSGOptions*){++queries;return sl::Result::eOk;}
__declspec(noinline) static int EvaluateFixture(int x){volatile int value=x;return value+1;}
__declspec(noinline) static int EvaluateHook(int x){return x+2;}
static bool MixedEvaluateCoverage(){
    auto owner=GetModuleHandleW(nullptr);void* original=nullptr;
    entry_detour::InstallOptions options{};options.generation=17;options.allowRelocated=true;
    entry_detour::Handle handle{};
    if(!entry_detour::Install(entry_detour::Kind::eNgxD3D12EvaluateFeature,owner,
        reinterpret_cast<void*>(&EvaluateFixture),reinterpret_cast<void*>(&EvaluateHook),original,options,&handle))return false;
    gActiveNgxDispatchRoute=static_cast<uint32_t>(NgxDispatchRoute::eRuntime);
    gActiveNgxGraphicsApi=static_cast<uint32_t>(NgxGraphicsApi::eD3D12);
    gActiveNgxProviderBase=reinterpret_cast<uintptr_t>(owner);
    gActiveNgxEvaluateHandle=0;gActiveNgxProviderGeneration=18;
    if(EffectiveNgxEvaluateDetour().current)return false; // stale generation
    gActiveNgxProviderGeneration=17;
    const auto covered=EffectiveNgxEvaluateDetour();
    if(!covered.current || !(covered.handle==handle))return false;
    if(!CanObserveNgxEvaluateEntry(NgxDispatchRoute::eProvider,NgxGraphicsApi::eD3D12,handle))return false;
    if(CanObserveNgxEvaluateEntry(NgxDispatchRoute::eProvider,NgxGraphicsApi::eVulkan,handle))return false;
    if(CanObserveNgxEvaluateEntry(NgxDispatchRoute::eProvider,NgxGraphicsApi::eD3D12,{}))return false;
    gActiveNgxProviderGeneration=18;
    if(CanObserveNgxEvaluateEntry(NgxDispatchRoute::eProvider,NgxGraphicsApi::eD3D12,handle))return false;
    gActiveNgxEvaluateHandle=0;gActiveNgxProviderBase=reinterpret_cast<uintptr_t>(GetModuleHandleW(L"kernel32.dll"));
    if(EffectiveNgxEvaluateDetour().current)return false; // another loaded provider cannot borrow coverage
    return true;
}
int main(){
    if(!MixedEvaluateCoverage()){std::cerr<<"Mixed Evaluate coverage failed\n";return 10;}
    std::cout<<"PASS: mixed runtime Create/provider Evaluate coverage, generation/module/API isolation\n";
    const auto tls=TlsAlloc();if(tls==TLS_OUT_OF_INDEXES)return 1;
    gInternalControlBypassTlsIndex.store(tls);
    auto& route=gControlRoutes[0];route.claimed=true;route.wrapperPatched=true;
    route.lifecycleInstallAttempted=true;route.publicSetOriginal=&SetStub;route.publicGetOriginal=&GetStub;
    gActiveControlRouteSlot=0;
    sl::ViewportHandle vp{0u};sl::DLSSGOptions options{};sl::DLSSGState state{};
    {
        // An outer setter owns this lock while a forwarded wrapper re-enters.
        std::lock_guard lock(gStreamlineCallMutex);
        {ScopedInternalControlBypass bypass;
         if(HandlePublicSetOptions(0,ControlEntryPath::ePublic,vp,options)!=sl::Result::eOk)return 2;
         if(HandlePublicGetState(0,ControlEntryPath::ePublic,vp,state,&options)!=sl::Result::eOk)return 3;}
        // Normal status queries must also run without taking the setter lock,
        // submitting a setting, or consuming a pending revision.
        gDesiredRevision=99;gAppliedRevision=3;
        if(HandlePublicGetState(0,ControlEntryPath::ePublic,vp,state,&options)!=sl::Result::eOk)return 4;
        if(setters!=1 || queries!=2 || gAppliedRevision.load()!=3)return 5;
    }
    if(InternalControlBypassDepth()!=0)return 6;
    TlsFree(tls);gInternalControlBypassTlsIndex=TLS_OUT_OF_INDEXES;
    std::cout<<"PASS: public setter/getter re-entry, query during setter lock, no query-driven apply, bypass restoration\n";
}
