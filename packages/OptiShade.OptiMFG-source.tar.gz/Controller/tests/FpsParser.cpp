#include "Fps.hpp"
#include <iostream>
int main(){FpsCapture capture;capture.target=42;
    if(FpsCapture::FailureMessage(5,"error: failed to start trace session: Access denied.").find("administrator")==std::string::npos)return 10;
    if(FpsCapture::FailureMessage(2,"unrelated failure").find("exit 2")==std::string::npos)return 11;
    std::string utf16;for(char c:std::string("error: access denied")){utf16+=c;utf16+='\0';}
    if(FpsCapture::FailureMessage(6,utf16).find("permission denied")==std::string::npos)return 12;
    capture.Line("Application,ProcessID,SwapChainAddress,FrameType,CPUStartTime,FrameTime");
    for(int i=0;i<100;++i)capture.Line("game,42,0x1,Application,"+std::to_string(i*25)+",25");
    if(std::abs(capture.fps-40)>0.001)return 1;
    for(int i=0;i<100;++i)capture.Line("other,99,0x2,Application,"+std::to_string(i*1)+",1");
    if(std::abs(capture.fps-40)>0.001)return 2;
    capture.Line("game,42,0x1,Application,NaN,0");capture.Line("broken");
    if(std::abs(capture.fps-40)>0.001)return 3;
    for(int i=0;i<200;++i)capture.Line("game,42,0x1,Application,"+std::to_string(3000+i*10)+",10");
    if(std::abs(capture.fps-100)>0.001)return 4;
    capture.Stop();if(capture.fps!=0)return 5;
    std::cout<<"FPS parser passed: rates, target filtering, malformed input, rolling window, reset\n";
}
