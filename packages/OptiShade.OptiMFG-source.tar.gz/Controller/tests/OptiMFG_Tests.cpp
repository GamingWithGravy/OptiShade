#include "OptiMFG/OptiMFG.h"
#include "OptiMFG/HostGpuContract.hpp"
#include "OptiMFG/ConfigProbe.hpp"
#include <atomic>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <vector>
using namespace omfg;
namespace {
unsigned checks = 0;
void expect(bool condition, const char* label) { ++checks; if (!condition) throw std::runtime_error(label); }
void good(Result r, const char* label) { expect(static_cast<bool>(r), label); }
Output output{640, 480, 28, Transfer::SDR_Gamma22, false};
Frame frame(uint64_t id, uint64_t epoch = 1) {
    Frame f{}; f.id = id; f.epoch = epoch; f.timestampNs = static_cast<int64_t>(id * 1000); f.completionFence = id;
    f.color = {true, 1, 28, 640, 480, ResourceState::CopySource}; return f;
}
void initialize(HostContract& h, uint64_t swap = 1) {
    good(h.initialize({swap, 1, 1, 1}, {1, 1, 1, 1, 1}, output), "initialize"); good(h.start(), "start");
}
void scheduler() {
    expect(omfgGetAbiVersion() == OMFG_ABI_VERSION, "ABI version");
    int64_t times[5]{};
    for (uint32_t n = 2; n <= 6; ++n) {
        expect(omfgSchedule(100, 100000103, n, times, 5) == static_cast<int>(n - 1), "schedule count");
        int64_t prev = 100;
        for (uint32_t i = 0; i < n - 1; ++i) { expect(times[i] > prev && times[i] < 100000103, "strict timestamp order"); prev = times[i]; }
    }
    expect(omfgSchedule(0, std::numeric_limits<int64_t>::max(), 6, times, 5) == 5, "overflow safe");
    times[0] = 999;
    expect(omfgSchedule(0, 2, 6, times, 5) == -1 && times[0] == 999, "reject short interval atomically");
    expect(omfgSchedule(-1, 3, 2, times, 5) == -1, "negative time");
    expect(omfgSchedule(3, 3, 2, times, 5) == -1, "same time");
    expect(omfgSchedule(0, 60, 7, times, 5) == -1, "unsupported multiplier");
    expect(omfgSchedule(0, 60, 6, times, 4) == -1, "capacity");
    expect(omfgSchedule(0, 60, 6, nullptr, 5) == -1, "null destination");
}
void lifecycle() {
    HostContract h, conflicting;
    expect(h.start().error == Error::InvalidState, "start before init");
    expect(h.initialize({1, 1, 2, 1}, {1, 1, 1, 1, 1}, output).error == Error::OwnerConflict, "foreign presenter rejected");
    expect(h.initialize({1, 1, 1, 2}, {1, 1, 1, 1, 1}, output).error == Error::OwnerConflict, "foreign FG owner rejected");
    initialize(h);
    expect(conflicting.initialize({1, 2, 2, 2}, {2, 2, 2, 2, 2}, output).error == Error::OwnerConflict, "duplicate swapchain rejected");
    auto f = frame(1); f.kind = FrameKind::Generated;
    expect(h.accept(f).error == Error::Unsupported, "no fake generation"); f.kind = FrameKind::Real;
    f.color.valid = false; expect(h.accept(f).error == Error::MissingColor, "missing color"); f.color.valid = true;
    f.motion.token = 20; expect(h.accept(f).error == Error::InvalidResource, "invalid resource token"); f.motion.token = 0;
    f.color.width = 800; expect(h.accept(f).error == Error::InvalidResource, "wrong resolution"); f.color.width = 640;
    f.epoch = 0; expect(h.accept(f).error == Error::StaleEpoch, "old epoch"); f.epoch = 1;
    f.id = 2; expect(h.accept(f).error == Error::InvalidFrame, "skipped ID"); f.id = 1;
    f.sceneCut = true; good(h.accept(f), "scene cut preserves real frame");
    expect(h.snapshot().bypassed == 1, "scene cut bypass counter");
    expect(h.accept(f).error == Error::InvalidFrame, "duplicate ID");
    f = frame(2); f.completionFence = 1;
    expect(h.accept(f).error == Error::SyncFailure, "nonmonotonic fence");
    f = frame(2); f.timestampNs = 1000;
    expect(h.accept(f).error == Error::InvalidFrame, "nonmonotonic timestamp");
    good(h.drain(), "drain");
    expect(h.accept(frame(2)).error == Error::InvalidState, "no delivery while draining");
    expect(h.recreate(output, 0).error == Error::SyncFailure, "resize before fence");
    good(h.recreate(output, 1), "resize after fence"); good(h.start(), "restart");
    expect(h.accept(frame(1)).error == Error::StaleEpoch, "resize invalidates epoch");
    f = frame(1, 2); f.completionFence = 2; good(h.accept(f), "new epoch frame");
    good(h.drain(), "second drain");
    expect(h.stop(1).error == Error::SyncFailure, "stop before completion"); good(h.stop(2), "stop");
    initialize(conflicting); conflicting.deviceLost();
    expect(conflicting.snapshot().state == Lifecycle::Stopped && conflicting.snapshot().epoch == 2, "device loss stops and invalidates");
    initialize(h); expect(h.snapshot().epoch == 3, "stop invalidates epoch");
}
void stressAndRaces() {
    HostContract h; initialize(h);
    for (uint64_t i = 1; i <= 12000; ++i) good(h.accept(frame(i)), "12000 frame sequence");
    expect(h.snapshot().accepted == 12000, "frame count");
    good(h.drain(), "stress drain"); good(h.stop(12000), "stress stop");
    for (unsigned cycle = 0; cycle < 100; ++cycle) {
        HostContract race; initialize(race);
        std::atomic<bool> go{false};
        std::atomic<unsigned> accepted{0}, invalid{0};
        std::thread writer([&] { while (!go.load()) std::this_thread::yield();
            auto r = race.accept(frame(1)); if (r) ++accepted; else if (r.error == Error::InvalidState) ++invalid;
        });
        std::thread stopper([&] { while (!go.load()) std::this_thread::yield(); race.drain(); });
        go = true; writer.join(); stopper.join();
        expect(accepted + invalid == 1, "linearizable submit/drain race");
        good(race.stop(1), "race shutdown");
    }
    for (unsigned cycle = 0; cycle < 100; ++cycle) {
        HostContract a, b; std::atomic<bool> go{false}; Result ra, rb;
        auto init = [&](HostContract& c, Result& r) { while (!go.load()) std::this_thread::yield(); r = c.initialize({1, 1, 1, 1}, {1, 1, 1, 1, 1}, output); };
        std::thread t1(init, std::ref(a), std::ref(ra)), t2(init, std::ref(b), std::ref(rb));
        go = true; t1.join(); t2.join();
        expect(static_cast<bool>(ra) != static_cast<bool>(rb), "exactly one owner wins race");
        expect((ra ? rb : ra).error == Error::OwnerConflict, "losing owner fails closed");
    }
}
void configs() {
    for (const auto* file : {"auto", "true", "absent", "legacy"}) {
        const auto path = std::string(FIXTURE_DIR) + "/" + file + ".ini";
        std::ifstream input(path); expect(input.good(), "fixture exists"); auto p = probeConfig(input);
        expect(p.enabled == ((std::string(file) == "auto" || std::string(file) == "true") ? file : "absent"), "fixture enabled");
        expect(p.legacy == (std::string(file) == "legacy"), "legacy observation");
    }
    std::istringstream duplicate("[FrameGeneration]\nEnabled=auto\nEnabled=true\n");
    expect(probeConfig(duplicate).ambiguous, "duplicates marked ambiguous");
    std::istringstream bom("\xef\xbb\xbf[FrameGeneration]\n Enabled = FALSE ; comment\n");
    expect(probeConfig(bom).enabled == "false", "BOM case whitespace comments");
    std::istringstream unknown("[FrameGeneration]\nEnabled=maybe\nFGOutput=gravy\n");
    auto p = probeConfig(unknown);
    expect(p.enabled == "unrecognized" && p.fgOutput == "present_uninterpreted", "no invented config support");
}
}
int main() {
    try { scheduler(); lifecycle(); stressAndRaces(); configs();
        std::cout << "PASS " << checks << " checks; 12000 frames; 100 lifecycle races; 100 owner races; config fixtures\n"; return 0;
    } catch (const std::exception& e) { std::cerr << "FAIL after " << checks << " checks: " << e.what() << '\n'; return 1; }
}
