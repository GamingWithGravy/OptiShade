#include "OptiMFG/OptiMFG.h"
int main(void) {
    int64_t times[5] = {0};
    return omfgGetAbiVersion() == 1 && omfgSchedule(0, 60, 6, times, 5) == 5 && times[4] == 50 ? 0 : 1;
}
