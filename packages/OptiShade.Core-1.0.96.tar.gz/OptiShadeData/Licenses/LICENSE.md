# OptiShade licence map

This repository contains separately licensed components. This map does not
replace their licences or change previously granted rights.

| Component | Applicable licence |
| --- | --- |
| OptiScaler-derived runtime, its OptiShade additions and other GPL-covered work | [GPL-3.0](LICENSES/GPL-3.0.txt); see also the unchanged root LICENSE and optiscaler/LICENSE |
| ReShade and its BSD-covered modifications | [ReShade BSD 3-Clause](LICENSES/ReShade-BSD-3-Clause.txt); reshade/LICENSE.md remains authoritative |
| Explicitly designated, verified standalone OptiShade / Fusion Engine code and assets | [OptiShade Proprietary Licence](LICENSES/OPTISHADE-PROPRIETARY.txt), only for validly designated revisions |
| Dependencies, shaders, vendor files and other third-party material | Their own file/component licences and notices |
| Official OptiShade / Fusion Engine names, logos and identity | [BRANDING.md](BRANDING.md), subject to existing artwork licences and legally permitted references |

The proprietary designation register is in [OPTISHADE_LICENSING.md](OPTISHADE_LICENSING.md).
It designates installer/main.go, installer/FusionSetup.cs and the three original
logo/icon assets listed there, for the new distribution only. The presence of
a proprietary licence does not relicense unlisted files, embedded payloads or
hosted scripts. Earlier GPL copies retain their existing permissions.

Specific file-level notices and applicable third-party licences take precedence.
Previously released GPL versions retain their GPL rights. The root GPL text is
preserved for existing references and tooling; this map does not turn the runtime
into proprietary software. See [LICENSING.md](LICENSING.md) and [NOTICE.md](NOTICE.md).
