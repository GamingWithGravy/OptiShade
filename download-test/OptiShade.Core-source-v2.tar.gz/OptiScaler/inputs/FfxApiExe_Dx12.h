#pragma once

void HookFfxExeInputs();
