#pragma once

#include "SysUtils.h"
#include <vulkan/vulkan.hpp>

namespace MenuOverlayVk
{
void CreateSwapchain(VkDevice device, VkPhysicalDevice pd, VkInstance instance, HWND hwnd,
                     const VkSwapchainCreateInfoKHR* pCreateInfo, const VkAllocationCallbacks* pAllocator,
                     VkSwapchainKHR* pSwapchain, VkQueue queue, uint32_t queueFamily);
bool CanDrawAfterEffects(VkQueue queue, const VkPresentInfoKHR* pPresentInfo);
void PreparePresent(VkQueue queue, const VkPresentInfoKHR* pPresentInfo);
bool QueuePresent(VkQueue queue, VkPresentInfoKHR* pPresentInfo, PFN_vkQueueSubmit submit = nullptr);
uint64_t DrawOwner();
void PresentProgress(uint64_t owner, VkResult result, uint32_t image);
void DestroyVulkanObjects(bool shutdown);
} // namespace MenuOverlayVk
