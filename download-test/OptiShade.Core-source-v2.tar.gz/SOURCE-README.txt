OptiShade Core corresponding source for the download candidate

This archive contains build-relevant source, project files, shaders, notices, and the source modifications present in the local Beta/optiscaler tree used for this candidate. Generated build outputs and vendor runtime/model binaries are excluded. The upstream base revision is recorded in optiscaler-revision.txt.

Vendor runtime and model binaries are not included in Core. Existing official dependency download methods obtain those files separately.

The archive is provided as corresponding source for GPL-covered OptiScaler-derived portions. This candidate is not marked installable or hardware-qualified.
